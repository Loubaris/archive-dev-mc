title @a[tag=InRaid2] subtitle §9Raid successfully defeated.
title @a[tag=InRaid2] title §aCongratulations!
playsound random.levelup @a[tag=InRaid2] ~ ~ ~ 1 1 1
effect @a village_hero 300 1
tag @a[tag=InRaid2] remove InRaid2
scoreboard players set @e[type=armor_stand,tag=Game] RaidStarted 0
scoreboard players set @e[type=armor_stand,tag=Game] RaidTimer 0
event entity @e[type=cs:raid2] cs:despawn