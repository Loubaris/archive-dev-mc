###################################################################
# Function Name: init_bedrock
#
# Function Activate: called manually by users on bedrock
#
# Functionality: Used for things that we want to happen right on bedrock start world
###################################################################


# Activate the command block
setblock 145 4 453 minecraft:redstone_block

# Tag the armor stand
execute @e[type=armor_stand,x=145,y=4,z=453,r=5] ~ ~ ~ tag @s add Game

# tp player
tp 130 90 438 90 0
gamemode survival @s

# Objectives setup
scoreboard objectives add RaidersAlive dummy
scoreboard objectives add RaidStarted dummy
scoreboard objectives add RaidTimer dummy
scoreboard objectives add RandomValue dummy
scoreboard objectives add VillagersAround dummy
scoreboard objectives add GolemsAround dummy

# Initial objectives values
scoreboard players set @e[type=armor_stand,tag=Game] RaidTimer 0

scoreboard players set @e[type=armor_stand,tag=Game] RaidStarted 0