###################################################################
# Function Name: go_away
#
# Activated By:  activated by furniture npc
#
# Functionality: despawn npc
###################################################################
execute @s ~ ~ ~ playsound info @p ~ ~ ~ 4 1 1
event entity @s cs:despawn
