execute @e[type=armor_stand,tag=Game] ~ ~ ~ tag @s add RaidActive

# Villager summon
execute @s[tag=villager] ~ ~ ~ summon cs:op_trader ~ ~ ~