execute @e[type=cs:raid2] ~ ~ ~ scoreboard players set @s RaidersAlive 0

execute @e[type=cs:raid2] ~ ~ ~ execute @e[family=raid,r=30] ~ ~ ~ scoreboard players add @e[type=cs:raid2,r=30] RaidersAlive 1

execute @e[type=cs:raid2,scores={RaidersAlive=0,RaidTimer=60..}] ~ ~ ~ function raid2/victory

scoreboard players add @e[type=cs:raid2] RaidTimer 1

# # First wave
# execute @e[type=cs:raid2,scores={RaidTimer=10}] ~ ~ ~ title @a[tag=InRaid2,r=30] title §4Wave 1
execute @e[type=cs:raid2,scores={RaidTimer=5}] ~ ~ ~ execute @e[type=cs:raid2] ~ ~ ~ summon zombie ~5 ~ ~-5 cs:raid
execute @e[type=cs:raid2,scores={RaidTimer=10}] ~ ~ ~ execute @e[type=cs:raid2] ~ ~ ~ summon zombie ~3 ~ ~7 cs:raid
execute @e[type=cs:raid2,scores={RaidTimer=15}] ~ ~ ~ execute @e[type=cs:raid2] ~ ~ ~ summon skeleton ~2 ~ ~-3 cs:raid
execute @e[type=cs:raid2,scores={RaidTimer=20}] ~ ~ ~ execute @e[type=cs:raid2] ~ ~ ~ summon skeleton ~4 ~ ~1 cs:raid
execute @e[type=cs:raid2,scores={RaidTimer=25}] ~ ~ ~ execute @e[type=cs:raid2] ~ ~ ~ summon creeper ~-6 ~ ~-3 cs:raid
execute @e[type=cs:raid2,scores={RaidTimer=30}] ~ ~ ~ execute @e[type=cs:raid2] ~ ~ ~ summon spider ~-2 ~ ~-1 cs:raid
execute @e[type=cs:raid2,scores={RaidTimer=35}] ~ ~ ~ execute @e[type=cs:raid2] ~ ~ ~ summon pillager ~ ~ ~-6 cs:raid
execute @e[type=cs:raid2,scores={RaidTimer=40}] ~ ~ ~ execute @e[type=cs:raid2] ~ ~ ~ summon evocation_illager ~-4 ~ ~ cs:raid
execute @e[type=cs:raid2,scores={RaidTimer=45}] ~ ~ ~ execute @e[type=cs:raid2] ~ ~ ~ summon ravager ~-2 ~ ~-1 cs:raid
execute @e[type=cs:raid2,scores={RaidTimer=50}] ~ ~ ~ execute @e[type=cs:raid2] ~ ~ ~ summon cs:giant_spider ~-10 ~ ~4 cs:raid
execute @e[type=cs:raid2,scores={RaidTimer=55}] ~ ~ ~ execute @e[type=cs:raid2] ~ ~ ~ summon cs:giant_zombie ~7 ~ ~3 cs:raid

# # Second wave
# execute @e[type=cs:raid2,scores={RaidTimer=610}] ~ ~ ~ title @a[tag=InRaid2,r=30] title §4Wave 2
# execute @e[type=cs:raid2,scores={RaidTimer=610}] ~ ~ ~ playsound creepy_sound @a[tag=InRaid2,r=30] ~ ~ ~ 1 1 1
# execute @e[type=cs:raid2,scores={RaidTimer=610}] ~ ~ ~ execute @e[type=cs:raid2] ~ ~ ~ summon pillager ~5 ~ ~-5 cs:raid
# execute @e[type=cs:raid2,scores={RaidTimer=610}] ~ ~ ~ execute @e[type=cs:raid2] ~ ~ ~ summon creeper ~3 ~ ~7 cs:raid
# execute @e[type=cs:raid2,scores={RaidTimer=610}] ~ ~ ~ execute @e[type=cs:raid2] ~ ~ ~ summon zombie ~2 ~ ~-3 cs:raid
# execute @e[type=cs:raid2,scores={RaidTimer=610}] ~ ~ ~ execute @e[type=cs:raid2] ~ ~ ~ summon spider ~4 ~ ~1 cs:raid
# execute @e[type=cs:raid2,scores={RaidTimer=610}] ~ ~ ~ execute @e[type=cs:raid2] ~ ~ ~ summon skeleton ~-6 ~ ~-3 cs:raid
# execute @e[type=cs:raid2,scores={RaidTimer=610}] ~ ~ ~ execute @e[type=cs:raid2] ~ ~ ~ summon ravager ~-2 ~ ~-1 cs:raid
# execute @e[type=cs:raid2,scores={RaidTimer=610}] ~ ~ ~ execute @e[type=cs:raid2] ~ ~ ~ summon cs:giant_spider ~ ~ ~-6 cs:raid
# execute @e[type=cs:raid2,scores={RaidTimer=610}] ~ ~ ~ execute @e[type=cs:raid2] ~ ~ ~ summon zombie ~-4 ~ ~ cs:raid
# execute @e[type=cs:raid2,scores={RaidTimer=610}] ~ ~ ~ execute @e[type=cs:raid2] ~ ~ ~ summon skeleton ~-2 ~ ~-1 cs:raid
# execute @e[type=cs:raid2,scores={RaidTimer=610}] ~ ~ ~ execute @e[type=cs:raid2] ~ ~ ~ summon cs:giant_zombie ~-10 ~ ~4 cs:raid
# execute @e[type=cs:raid2,scores={RaidTimer=610}] ~ ~ ~ execute @e[type=cs:raid2] ~ ~ ~ summon evocation_illager ~7 ~ ~3 cs:raid

# # Third wave
# execute @e[type=cs:raid2,scores={RaidTimer=1210}] ~ ~ ~ title @a[tag=InRaid2,r=30] title §4Wave 3
# execute @e[type=cs:raid2,scores={RaidTimer=1210}] ~ ~ ~ playsound creepy_sound @a[tag=InRaid2,r=30] ~ ~ ~ 1 1 1
# execute @e[type=cs:raid2,scores={RaidTimer=1210}] ~ ~ ~ execute @e[type=cs:raid2] ~ ~ ~ summon creeper ~5 ~ ~-5 cs:raid
# execute @e[type=cs:raid2,scores={RaidTimer=1210}] ~ ~ ~ execute @e[type=cs:raid2] ~ ~ ~ summon spider ~3 ~ ~7 cs:raid
# execute @e[type=cs:raid2,scores={RaidTimer=1210}] ~ ~ ~ execute @e[type=cs:raid2] ~ ~ ~ summon zombie ~2 ~ ~-3 cs:raid
# execute @e[type=cs:raid2,scores={RaidTimer=1210}] ~ ~ ~ execute @e[type=cs:raid2] ~ ~ ~ summon skeleton ~4 ~ ~1 cs:raid
# execute @e[type=cs:raid2,scores={RaidTimer=1210}] ~ ~ ~ execute @e[type=cs:raid2] ~ ~ ~ summon skeleton ~-6 ~ ~-3 cs:raid
# execute @e[type=cs:raid2,scores={RaidTimer=1210}] ~ ~ ~ execute @e[type=cs:raid2] ~ ~ ~ summon zombie ~-2 ~ ~-1 cs:raid
# execute @e[type=cs:raid2,scores={RaidTimer=1210}] ~ ~ ~ execute @e[type=cs:raid2] ~ ~ ~ summon pillager ~ ~ ~-6 cs:raid
# execute @e[type=cs:raid2,scores={RaidTimer=1210}] ~ ~ ~ execute @e[type=cs:raid2] ~ ~ ~ summon cs:giant_zombie ~-4 ~ ~ cs:raid
# execute @e[type=cs:raid2,scores={RaidTimer=1210}] ~ ~ ~ execute @e[type=cs:raid2] ~ ~ ~ summon cs:giant_spider ~-2 ~ ~-1 cs:raid
# execute @e[type=cs:raid2,scores={RaidTimer=1210}] ~ ~ ~ execute @e[type=cs:raid2] ~ ~ ~ summon evocation_illager ~-10 ~ ~4 cs:raid
# execute @e[type=cs:raid2,scores={RaidTimer=1210}] ~ ~ ~ execute @e[type=cs:raid2] ~ ~ ~ summon ravager ~7 ~ ~3 cs:raid