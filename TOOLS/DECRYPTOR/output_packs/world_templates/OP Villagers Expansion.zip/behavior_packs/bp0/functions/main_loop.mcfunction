execute @e[type=cs:raid1] ~ ~ ~ function raid1/loop
execute @e[type=cs:raid2] ~ ~ ~ function raid2/loop
execute @e[type=cs:raid3] ~ ~ ~ function raid3/loop
execute @e[type=cs:raid4] ~ ~ ~ function raid4/loop

clear @a cs:invisible

# Detect if player is near a border entity, and if so, teleport back to the spot
execute @e[type=cs:village_border] ~ ~ ~ execute @e[type=cs:op_trader,r=10] ~ ~ ~ tp @s @r[type=cs:villager_spot]
execute @e[type=cs:village_border] ~ ~ ~ execute @e[type=cs:op_golem,r=10] ~ ~ ~ tp @s @r[type=cs:villager_spot]

# If villager falls into the fountain, tp back to the spot
execute @e[type=cs:op_trader,x=87,y=75,z=457,r=5] ~ ~ ~ tp @s @r[type=cs:villager_spot]