execute @s ~ ~ ~ playsound block.bamboo.break @p ~ ~ ~ 1.00 0.1
execute @s ~ ~ ~ camerashake add @p[r=15] 0.40 0.3