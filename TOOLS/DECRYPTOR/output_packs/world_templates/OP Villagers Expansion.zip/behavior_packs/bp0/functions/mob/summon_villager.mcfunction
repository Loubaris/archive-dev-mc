scoreboard players random @s RandomValue 1 13

execute @s[scores={RandomValue=1}] ~ ~ ~ summon minecraft:villager ~ ~ ~ minecraft:spawn_farmer
execute @s[scores={RandomValue=2}] ~ ~ ~ summon minecraft:villager ~ ~ ~ minecraft:spawn_librarian
execute @s[scores={RandomValue=3}] ~ ~ ~ summon minecraft:villager ~ ~ ~ minecraft:spawn_cleric
execute @s[scores={RandomValue=4}] ~ ~ ~ summon minecraft:villager ~ ~ ~ minecraft:spawn_butcher
execute @s[scores={RandomValue=5}] ~ ~ ~ summon minecraft:villager ~ ~ ~ minecraft:spawn_armorer
execute @s[scores={RandomValue=6}] ~ ~ ~ summon minecraft:villager ~ ~ ~ minecraft:spawn_armorer
execute @s[scores={RandomValue=7}] ~ ~ ~ summon minecraft:villager ~ ~ ~ minecraft:spawn_armorer
execute @s[scores={RandomValue=8}] ~ ~ ~ summon minecraft:villager ~ ~ ~ minecraft:spawn_armorer
execute @s[scores={RandomValue=9}] ~ ~ ~ summon minecraft:villager ~ ~ ~ minecraft:spawn_armorer
execute @s[scores={RandomValue=10}] ~ ~ ~ summon minecraft:villager ~ ~ ~ minecraft:spawn_armorer
execute @s[scores={RandomValue=11}] ~ ~ ~ summon minecraft:villager ~ ~ ~ minecraft:spawn_armorer
execute @s[scores={RandomValue=12}] ~ ~ ~ summon minecraft:villager ~ ~ ~ minecraft:spawn_armorer
execute @s[scores={RandomValue=13}] ~ ~ ~ summon minecraft:villager ~ ~ ~ minecraft:spawn_armorer
