title @a[tag=InRaid4] subtitle §9Raid successfully defeated.
title @a[tag=InRaid4] title §aCongratulations!
playsound random.levelup @a[tag=InRaid4] ~ ~ ~ 1 1 1
effect @a village_hero 300 1
tag @a[tag=InRaid4] remove InRaid4
scoreboard players set @e[type=armor_stand,tag=Game] RaidStarted 0
scoreboard players set @e[type=armor_stand,tag=Game] RaidTimer 0
event entity @e[type=cs:raid4] cs:despawn