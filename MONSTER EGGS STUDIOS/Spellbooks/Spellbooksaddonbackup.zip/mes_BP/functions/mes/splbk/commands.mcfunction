


scoreboard players add @p[r=1,tag=mes_sb_fireswrd] mes_splbk_ft 1
execute @p[tag=mes_sb_fireswrd,scores={mes_splbk_ft=1}] ~ ~ ~ tag @s add mes_sb_td
execute @p[tag=mes_sb_fireswrd,scores={mes_splbk_ft=1}] ~ ~ ~ tag @s add mes_sb_fb
execute @p[tag=mes_sb_fireswrd,scores={mes_splbk_ft=1}] ~ ~ ~ effect @p fire_resistance 5 255 true
execute @p[tag=mes_sb_fireswrd,scores={mes_splbk_ft=1}] ~ ~ ~ playsound sw.music.fire_ability @a[r=20]
execute @p[tag=mes_sb_fireswrd,scores={mes_splbk_ft=6},tag=mes_sb_small] ~ ~ ~ playanimation @e[type=mes_splbk:boulder_toss] animation.mes_splbk.boulder.small f 1000
execute @p[tag=mes_sb_fireswrd,scores={mes_splbk_ft=6},tag=mes_sb_small] ~ ~ ~ tag @e[type=mes_splbk:boulder_toss] add mes_sb_smallfire
execute @p[tag=mes_sb_fireswrd,scores={mes_splbk_ft=6},tag=mes_sb_medium] ~ ~ ~ playanimation @e[type=mes_splbk:boulder_toss] animation.mes_splbk.boulder.medium f 1000
execute @p[tag=mes_sb_fireswrd,scores={mes_splbk_ft=6},tag=mes_sb_big] ~ ~ ~ playanimation @e[type=mes_splbk:boulder_toss] animation.mes_splbk.boulder.big f 1000
tag @p[tag=mes_sb_fireswrd,scores={mes_splbk_ft=24}] remove mes_sb_small
tag @p[tag=mes_sb_fireswrd,scores={mes_splbk_ft=24}] remove mes_sb_medium
tag @p[tag=mes_sb_fireswrd,scores={mes_splbk_ft=24}] remove mes_sb_big
tag @p[tag=mes_sb_fireswrd,scores={mes_splbk_ft=25}] remove mes_sb_fireswrd
scoreboard players set @p[r=1,scores={mes_splbk_ft=25}] mes_splbk_ft 0

scoreboard players add @e[type=mes_splbk:boulder_toss] mes_splbk_ft 1
execute @e[type=mes_splbk:boulder_toss,tag=mes_sb_smallfire] ~ ~ ~ particle minecraft:mobflame_single ~ ~0.5 ~
execute @e[type=mes_splbk:boulder_toss,tag=!mes_sb_smallfire] ~ ~ ~ particle minecraft:mobflame_single ~ ~ ~0.5
execute @e[type=mes_splbk:boulder_toss,tag=!mes_sb_smallfire] ~ ~ ~ particle minecraft:mobflame_single ~0.5 ~ ~
execute @e[type=mes_splbk:boulder_toss,scores={mes_splbk_ft=50}] ~ ~ ~ playsound random.explode @a[r=30]
execute @e[type=mes_splbk:boulder_toss,scores={mes_splbk_ft=50}] ~ ~ ~ summon mes_splbk:instanttnt
execute @e[type=mes_splbk:boulder_toss,scores={mes_splbk_ft=50},tag=!mes_sb_smallfire] ~ ~ ~ summon mes_splbk:instanttnt
execute @e[type=mes_splbk:boulder_toss,scores={mes_splbk_ft=50}] ~ ~ ~ particle mes_splbk:boulder ~ ~ ~
execute @e[type=mes_splbk:boulder_toss,scores={mes_splbk_ft=47}] ~ ~ ~ effect @a resistance 2 255 true
execute @e[type=mes_splbk:boulder_toss,scores={mes_splbk_ft=50}] ~ ~ ~ effect @e[r=8,family=mob,family=!inac] instant_damage 3 1 true
execute @e[type=mes_splbk:boulder_toss,scores={mes_splbk_ft=51}] ~ ~ ~ kill @s


scoreboard players add @p[r=1,tag=mes_sb_inferno] mes_splbk_ift 1
execute @a[tag=mes_sb_inferno,scores={mes_splbk_ift=16..80,book=3}] ~ ~ ~ event entity @s mes_splbk:cooldown_on
execute @a[tag=mes_sb_inferno,scores={mes_splbk_ift=1}] ~ ~ ~ playsound sw.music.inferno_ability @a[r=10]
execute @a[tag=mes_sb_inferno,scores={mes_splbk_ift=1..40}] ~ ~ ~ particle mes_splbk:inferno_ring ~ ~ ~
execute @a[tag=mes_sb_inferno,scores={mes_splbk_ift=1}] ~ ~ ~ effect @s fire_resistance 10 255 true
execute @a[tag=mes_sb_inferno,scores={mes_splbk_ift=81}] ~ ~ ~ event entity @s mes_splbk:cooldown_off
execute @a[tag=mes_sb_inferno,scores={mes_splbk_ift=81}] ~ ~ ~ fill ~-10 ~-1 ~-10 ~10 ~2 ~10 air 0 replace fire
tag @a[tag=mes_sb_inferno,scores={mes_splbk_ift=81}] remove mes_sb_inferno
scoreboard players set @p[r=1,scores={mes_splbk_ift=81}] mes_splbk_ift 0


scoreboard players add @p[r=1,tag=mes_sb_geyser] mes_splbk_gsrt 1
execute @a[tag=mes_sb_geyser,scores={mes_splbk_gsrt=16..109,book=2}] ~ ~ ~ event entity @s mes_splbk:cooldown_on
execute @p[tag=mes_sb_geyser,scores={mes_splbk_gsrt=1}] ~ ~ ~ effect @p fire_resistance 5 255 true
execute @p[tag=mes_sb_geyser,scores={mes_splbk_gsrt=1}] ~ ~ ~ playsound sw.music.fire_ability @a[r=20]
execute @p[tag=mes_sb_geyser,scores={mes_splbk_gsrt=1}] ~ ~ ~ summon mes_splbk:geyser ~ ~-100 ~
execute @p[tag=mes_sb_geyser,scores={mes_splbk_gsrt=1}] ~ ~ ~ summon mes_splbk:geyser ~ ~-100 ~
execute @p[tag=mes_sb_geyser,scores={mes_splbk_gsrt=1}] ~ ~ ~ summon mes_splbk:geyser ~ ~-100 ~
execute @p[tag=mes_sb_geyser,scores={mes_splbk_gsrt=1}] ~ ~ ~ tp @e[type=mes_splbk:geyser,c=1,rm=5] ^ ^1 ^2 facing @p[tag=mes_sb_geyser]
execute @p[tag=mes_sb_geyser,scores={mes_splbk_gsrt=1}] ~ ~ ~ tp @e[type=mes_splbk:geyser,c=1,rm=5] ^1.5 ^1 ^2 facing @p[tag=mes_sb_geyser]
execute @p[tag=mes_sb_geyser,scores={mes_splbk_gsrt=1}] ~ ~ ~ tp @e[type=mes_splbk:geyser,c=1,rm=5] ^-1.5 ^1 ^2 facing @p[tag=mes_sb_geyser]
execute @p[tag=mes_sb_geyser,scores={mes_splbk_gsrt=1}] ~ ~ ~ execute @e[type=mes_splbk:geyser] ~ ~ ~ tp @s ^ ^ ^-1
execute @p[tag=mes_sb_geyser,scores={mes_splbk_gsrt=1}] ~ ~ ~ execute @e[type=mes_splbk:geyser] ~ ~ ~ effect @e[family=mob,family=!inac,r=2] fatal_poison 4 255 true
execute @p[tag=mes_sb_geyser,scores={mes_splbk_gsrt=1}] ~ ~ ~ execute @e[type=mes_splbk:geyser] ~ ~ ~ execute @e[family=mob,family=!inac,r=2] ~ ~ ~ fill ~ ~ ~ ~ ~ ~ fire 0 replace air
execute @p[tag=mes_sb_geyser,scores={mes_splbk_gsrt=1}] ~ ~ ~ execute @e[type=mes_splbk:geyser] ~ ~ ~ fill ^1 ^ ^ ^2 ^ ^ fire 0 replace air
execute @p[tag=mes_sb_geyser,scores={mes_splbk_gsrt=1}] ~ ~ ~ execute @e[type=mes_splbk:geyser] ~ ~ ~ fill ^-1 ^ ^ ^-2 ^ ^ fire 0 replace air
execute @p[tag=mes_sb_geyser,scores={mes_splbk_gsrt=1}] ~ ~ ~ execute @e[type=mes_splbk:geyser] ~ ~ ~ playanimation @e[type=mes_splbk:geyser] animation.mes_splbk.geyser.monte
execute @p[tag=mes_sb_geyser,scores={mes_splbk_gsrt=15}] ~ ~ ~ execute @e[type=mes_splbk:geyser] ~ ~ ~ tp @s ^ ^ ^-1
execute @p[tag=mes_sb_geyser,scores={mes_splbk_gsrt=15}] ~ ~ ~ execute @e[type=mes_splbk:geyser] ~ ~ ~ effect @e[family=mob,family=!inac,r=2] fatal_poison 4 255 true
execute @p[tag=mes_sb_geyser,scores={mes_splbk_gsrt=15}] ~ ~ ~ execute @e[type=mes_splbk:geyser] ~ ~ ~ execute @e[family=mob,family=!inac,r=2] ~ ~ ~ fill ~ ~ ~ ~ ~ ~ fire 0 replace air
execute @p[tag=mes_sb_geyser,scores={mes_splbk_gsrt=15}] ~ ~ ~ execute @e[type=mes_splbk:geyser] ~ ~ ~ fill ^1 ^ ^ ^2 ^ ^ fire 0 replace air
execute @p[tag=mes_sb_geyser,scores={mes_splbk_gsrt=15}] ~ ~ ~ execute @e[type=mes_splbk:geyser] ~ ~ ~ fill ^-1 ^ ^ ^-2 ^ ^ fire 0 replace air
execute @p[tag=mes_sb_geyser,scores={mes_splbk_gsrt=15}] ~ ~ ~ execute @e[type=mes_splbk:geyser] ~ ~ ~ playanimation @e[type=mes_splbk:geyser] animation.mes_splbk.geyser.monte
execute @p[tag=mes_sb_geyser,scores={mes_splbk_gsrt=30}] ~ ~ ~ execute @e[type=mes_splbk:geyser] ~ ~ ~ tp @s ^ ^ ^-1
execute @p[tag=mes_sb_geyser,scores={mes_splbk_gsrt=30}] ~ ~ ~ execute @e[type=mes_splbk:geyser] ~ ~ ~ effect @e[family=mob,family=!inac,r=2] fatal_poison 4 255 true
execute @p[tag=mes_sb_geyser,scores={mes_splbk_gsrt=30}] ~ ~ ~ execute @e[type=mes_splbk:geyser] ~ ~ ~ execute @e[family=mob,family=!inac,r=2] ~ ~ ~ fill ~ ~ ~ ~ ~ ~ fire 0 replace air
execute @p[tag=mes_sb_geyser,scores={mes_splbk_gsrt=30}] ~ ~ ~ execute @e[type=mes_splbk:geyser] ~ ~ ~ fill ^1 ^ ^ ^2 ^ ^ fire 0 replace air
execute @p[tag=mes_sb_geyser,scores={mes_splbk_gsrt=30}] ~ ~ ~ execute @e[type=mes_splbk:geyser] ~ ~ ~ fill ^-1 ^ ^ ^-2 ^ ^ fire 0 replace air
execute @p[tag=mes_sb_geyser,scores={mes_splbk_gsrt=30}] ~ ~ ~ execute @e[type=mes_splbk:geyser] ~ ~ ~ playanimation @e[type=mes_splbk:geyser] animation.mes_splbk.geyser.monte
execute @p[tag=mes_sb_geyser,scores={mes_splbk_gsrt=45}] ~ ~ ~ execute @e[type=mes_splbk:geyser] ~ ~ ~ tp @s ^ ^ ^-1
execute @p[tag=mes_sb_geyser,scores={mes_splbk_gsrt=45}] ~ ~ ~ execute @e[type=mes_splbk:geyser] ~ ~ ~ effect @e[family=mob,family=!inac,r=2] fatal_poison 4 255 true
execute @p[tag=mes_sb_geyser,scores={mes_splbk_gsrt=45}] ~ ~ ~ execute @e[type=mes_splbk:geyser] ~ ~ ~ execute @e[family=mob,family=!inac,r=2] ~ ~ ~ fill ~ ~ ~ ~ ~ ~ fire 0 replace air
execute @p[tag=mes_sb_geyser,scores={mes_splbk_gsrt=45}] ~ ~ ~ execute @e[type=mes_splbk:geyser] ~ ~ ~ fill ^1 ^ ^ ^2 ^ ^ fire 0 replace air
execute @p[tag=mes_sb_geyser,scores={mes_splbk_gsrt=45}] ~ ~ ~ execute @e[type=mes_splbk:geyser] ~ ~ ~ fill ^-1 ^ ^ ^-2 ^ ^ fire 0 replace air
execute @p[tag=mes_sb_geyser,scores={mes_splbk_gsrt=45}] ~ ~ ~ execute @e[type=mes_splbk:geyser] ~ ~ ~ playanimation @e[type=mes_splbk:geyser] animation.mes_splbk.geyser.monte
execute @p[tag=mes_sb_geyser,scores={mes_splbk_gsrt=60}] ~ ~ ~ execute @e[type=mes_splbk:geyser] ~ ~ ~ tp @s ^ ^ ^-1
execute @p[tag=mes_sb_geyser,scores={mes_splbk_gsrt=60}] ~ ~ ~ execute @e[type=mes_splbk:geyser] ~ ~ ~ effect @e[family=mob,family=!inac,r=2] fatal_poison 4 255 true
execute @p[tag=mes_sb_geyser,scores={mes_splbk_gsrt=60}] ~ ~ ~ execute @e[type=mes_splbk:geyser] ~ ~ ~ execute @e[family=mob,family=!inac,r=2] ~ ~ ~ fill ~ ~ ~ ~ ~ ~ fire 0 replace air
execute @p[tag=mes_sb_geyser,scores={mes_splbk_gsrt=60}] ~ ~ ~ execute @e[type=mes_splbk:geyser] ~ ~ ~ fill ^1 ^ ^ ^2 ^ ^ fire 0 replace air
execute @p[tag=mes_sb_geyser,scores={mes_splbk_gsrt=60}] ~ ~ ~ execute @e[type=mes_splbk:geyser] ~ ~ ~ fill ^-1 ^ ^ ^-2 ^ ^ fire 0 replace air
execute @p[tag=mes_sb_geyser,scores={mes_splbk_gsrt=60}] ~ ~ ~ execute @e[type=mes_splbk:geyser] ~ ~ ~ playanimation @e[type=mes_splbk:geyser] animation.mes_splbk.geyser.monte
execute @p[tag=mes_sb_geyser,scores={mes_splbk_gsrt=75}] ~ ~ ~ execute @e[type=mes_splbk:geyser] ~ ~ ~ tp @s ^ ^ ^-1
execute @p[tag=mes_sb_geyser,scores={mes_splbk_gsrt=75}] ~ ~ ~ execute @e[type=mes_splbk:geyser] ~ ~ ~ effect @e[family=mob,family=!inac,r=2] fatal_poison 4 255 true
execute @p[tag=mes_sb_geyser,scores={mes_splbk_gsrt=75}] ~ ~ ~ execute @e[type=mes_splbk:geyser] ~ ~ ~ execute @e[family=mob,family=!inac,r=2] ~ ~ ~ fill ~ ~ ~ ~ ~ ~ fire 0 replace air
execute @p[tag=mes_sb_geyser,scores={mes_splbk_gsrt=75}] ~ ~ ~ execute @e[type=mes_splbk:geyser] ~ ~ ~ fill ^1 ^ ^ ^2 ^ ^ fire 0 replace air
execute @p[tag=mes_sb_geyser,scores={mes_splbk_gsrt=75}] ~ ~ ~ execute @e[type=mes_splbk:geyser] ~ ~ ~ fill ^-1 ^ ^ ^-2 ^ ^ fire 0 replace air
execute @p[tag=mes_sb_geyser,scores={mes_splbk_gsrt=75}] ~ ~ ~ execute @e[type=mes_splbk:geyser] ~ ~ ~ playanimation @e[type=mes_splbk:geyser] animation.mes_splbk.geyser.monte
execute @p[tag=mes_sb_geyser,scores={mes_splbk_gsrt=90}] ~ ~ ~ execute @e[type=mes_splbk:geyser] ~ ~ ~ tp @s ^ ^ ^-1
execute @p[tag=mes_sb_geyser,scores={mes_splbk_gsrt=90}] ~ ~ ~ execute @e[type=mes_splbk:geyser] ~ ~ ~ effect @e[family=mob,family=!inac,r=2] fatal_poison 4 255 true
execute @p[tag=mes_sb_geyser,scores={mes_splbk_gsrt=90}] ~ ~ ~ execute @e[type=mes_splbk:geyser] ~ ~ ~ execute @e[family=mob,family=!inac,r=2] ~ ~ ~ fill ~ ~ ~ ~ ~ ~ fire 0 replace air
execute @p[tag=mes_sb_geyser,scores={mes_splbk_gsrt=90}] ~ ~ ~ execute @e[type=mes_splbk:geyser] ~ ~ ~ fill ^1 ^ ^ ^2 ^ ^ fire 0 replace air
execute @p[tag=mes_sb_geyser,scores={mes_splbk_gsrt=90}] ~ ~ ~ execute @e[type=mes_splbk:geyser] ~ ~ ~ fill ^-1 ^ ^ ^-2 ^ ^ fire 0 replace air
execute @p[tag=mes_sb_geyser,scores={mes_splbk_gsrt=90}] ~ ~ ~ execute @e[type=mes_splbk:geyser] ~ ~ ~ playanimation @e[type=mes_splbk:geyser] animation.mes_splbk.geyser.monte
execute @p[tag=mes_sb_geyser,scores={mes_splbk_gsrt=107}] ~ ~ ~ particle mes_splbk:volcano_explode ~ ~1 ~
execute @p[tag=mes_sb_geyser,scores={mes_splbk_gsrt=107}] ~ ~ ~ execute @e[type=mes_splbk:geyser] ~ ~ ~ fill ~-10 ~-1 ~-10 ~10 ~2 ~10 air 0 replace fire
execute @p[tag=mes_sb_geyser,scores={mes_splbk_gsrt=107}] ~ ~ ~ playsound cauldron.explode @a[r=10]
execute @p[tag=mes_sb_geyser,scores={mes_splbk_gsrt=108}] ~ ~ ~ execute @e[type=mes_splbk:geyser] ~ ~ ~ tp @s ~ ~-100 ~
execute @p[tag=mes_sb_geyser,scores={mes_splbk_gsrt=110}] ~ ~ ~ execute @e[type=mes_splbk:geyser] ~ ~ ~ kill @s
execute @p[tag=mes_sb_geyser,scores={mes_splbk_gsrt=110}] ~ ~ ~ event entity @s mes_splbk:cooldown_off
tag @p[tag=mes_sb_geyser,scores={mes_splbk_gsrt=110}] remove mes_sb_geyser
scoreboard players set @p[r=1,scores={mes_splbk_gsrt=110}] mes_splbk_gsrt 0



scoreboard players add @p[r=1,tag=mes_sb_lava] mes_splbk_lvt 1
execute @a[tag=mes_sb_lava,scores={mes_splbk_lvt=1}] ~ ~ ~ playsound sw.music.fire_ability_2 @a[r=10]
execute @a[tag=mes_sb_lava,scores={mes_splbk_lvt=16..240,book=1}] ~ ~ ~ event entity @s mes_splbk:cooldown_on
execute @a[tag=mes_sb_lava,scores={mes_splbk_lvt=1}] ~ ~ ~ summon mes_splbk:lava ~ ~-100 ~
execute @a[tag=mes_sb_lava,scores={mes_splbk_lvt=1}] ~ ~ ~ execute @e[family=mob,family=!inac,r=10] ~ ~ ~ fill ~ ~ ~ ~ ~ ~ fire 0 replace air
execute @a[tag=mes_sb_lava,scores={mes_splbk_lvt=1}] ~ ~ ~ effect @e[family=mob,r=4] slowness 2 255 true
execute @a[tag=mes_sb_lava,scores={mes_splbk_lvt=1}] ~ ~ ~ effect @e[type=mes_splbk:lava] invisibility 100 255 true
execute @a[tag=mes_sb_lava,scores={mes_splbk_lvt=1}] ~ ~ ~ tp @e[type=mes_splbk:lava] ^ ^1 ^2.8 facing @p[tag=mes_sb_lava]
execute @a[tag=mes_sb_lava,scores={mes_splbk_lvt=4}] ~ ~ ~ effect @e[type=mes_splbk:lava] clear
execute @a[tag=mes_sb_lava,scores={mes_splbk_lvt=5}] ~ ~ ~ playanimation @e[type=mes_splbk:lava] animation.mes_splbk.lava.spawn
execute @a[tag=mes_sb_lava,scores={mes_splbk_lvt=80}] ~ ~ ~ playanimation @e[type=mes_splbk:lava] animation.mes_splbk.lava.break1 f 1000
execute @a[tag=mes_sb_lava,scores={mes_splbk_lvt=87}] ~ ~ ~ execute @e[family=mob,family=!inac,r=10] ~ ~ ~ fill ~ ~ ~ ~ ~ ~ fire 0 replace air
execute @a[tag=mes_sb_lava,scores={mes_splbk_lvt=87}] ~ ~ ~ execute @e[type=mes_splbk:lava] ~ ~ ~ particle minecraft:large_explosion ~ ~2 ~
execute @a[tag=mes_sb_lava,scores={mes_splbk_lvt=87}] ~ ~ ~ playsound cauldron.explode @a[r=10]
execute @a[tag=mes_sb_lava,scores={mes_splbk_lvt=160}] ~ ~ ~ playanimation @e[type=mes_splbk:lava] animation.mes_splbk.lava.break2 f 1000
execute @a[tag=mes_sb_lava,scores={mes_splbk_lvt=167}] ~ ~ ~ execute @e[type=mes_splbk:lava] ~ ~ ~ particle minecraft:large_explosion ~ ~1 ~
execute @a[tag=mes_sb_lava,scores={mes_splbk_lvt=167}] ~ ~ ~ playsound cauldron.explode @a[r=10]
execute @a[tag=mes_sb_lava,scores={mes_splbk_lvt=167}] ~ ~ ~ execute @e[family=mob,family=!inac,r=10] ~ ~ ~ fill ~ ~ ~ ~ ~ ~ fire 0 replace air
execute @a[tag=mes_sb_lava,scores={mes_splbk_lvt=229}] ~ ~ ~ playanimation @e[type=mes_splbk:lava] animation.mes_splbk.lava.break3 f 1000
execute @a[tag=mes_sb_lava,scores={mes_splbk_lvt=238}] ~ ~ ~ particle mes_splbk:volcano_explode ~ ~1 ~
execute @a[tag=mes_sb_lava,scores={mes_splbk_lvt=238}] ~ ~ ~ playsound cauldron.explode @a[r=10]
execute @a[tag=mes_sb_lava,scores={mes_splbk_lvt=238}] ~ ~ ~ execute @e[family=mob,family=!inac,r=10] ~ ~ ~ fill ~ ~ ~ ~ ~ ~ fire 0 replace air
execute @a[tag=mes_sb_lava,scores={mes_splbk_lvt=240}] ~ ~ ~ tp @e[type=mes_splbk:lava] ~ ~-100 ~
execute @a[tag=mes_sb_lava,scores={mes_splbk_lvt=241}] ~ ~ ~ kill @e[type=mes_splbk:lava]
execute @a[tag=mes_sb_lava,scores={mes_splbk_lvt=241}] ~ ~ ~ event entity @s mes_splbk:cooldown_off
execute @a[tag=mes_sb_lava,scores={mes_splbk_lvt=241}] ~ ~ ~ fill ~-10 ~-1 ~-10 ~10 ~2 ~10 air 0 replace fire
tag @a[tag=mes_sb_lava,scores={mes_splbk_lvt=241}] remove mes_sb_lava
scoreboard players set @p[r=1,scores={mes_splbk_lvt=241}] mes_splbk_lvt 0

execute @a[tag=mes_sb_lava,scores={mes_splbk_lvt=1..87}] ~ ~ ~ execute @e[type=mes_splbk:lava] ~ ~ ~ particle minecraft:basic_flame_particle ^1.3 ^3.3 ^
execute @a[tag=mes_sb_lava,scores={mes_splbk_lvt=1..87}] ~ ~ ~ execute @e[type=mes_splbk:lava] ~ ~ ~ particle minecraft:basic_flame_particle ^ ^3.3 ^
execute @a[tag=mes_sb_lava,scores={mes_splbk_lvt=1..87}] ~ ~ ~ execute @e[type=mes_splbk:lava] ~ ~ ~ particle minecraft:basic_flame_particle ^-1.3 ^3.3 ^
execute @a[tag=mes_sb_lava,scores={mes_splbk_lvt=87..167}] ~ ~ ~ execute @e[type=mes_splbk:lava] ~ ~ ~ particle minecraft:basic_flame_particle ^1.3 ^2.3 ^
execute @a[tag=mes_sb_lava,scores={mes_splbk_lvt=87..167}] ~ ~ ~ execute @e[type=mes_splbk:lava] ~ ~ ~ particle minecraft:basic_flame_particle ^ ^2.3 ^
execute @a[tag=mes_sb_lava,scores={mes_splbk_lvt=87..167}] ~ ~ ~ execute @e[type=mes_splbk:lava] ~ ~ ~ particle minecraft:basic_flame_particle ^-1.3 ^2.3 ^
execute @a[tag=mes_sb_lava,scores={mes_splbk_lvt=167..229}] ~ ~ ~ execute @e[type=mes_splbk:lava] ~ ~ ~ particle minecraft:basic_flame_particle ^1.3 ^1.3 ^
execute @a[tag=mes_sb_lava,scores={mes_splbk_lvt=167..229}] ~ ~ ~ execute @e[type=mes_splbk:lava] ~ ~ ~ particle minecraft:basic_flame_particle ^ ^1.3 ^
execute @a[tag=mes_sb_lava,scores={mes_splbk_lvt=167..229}] ~ ~ ~ execute @e[type=mes_splbk:lava] ~ ~ ~ particle minecraft:basic_flame_particle ^-1.3 ^1.3 ^



scoreboard players add @p[r=1,tag=mes_sb_volcano] mes_splbk_vcnt 1
execute @a[tag=mes_sb_volcano,scores={mes_splbk_vcnt=1}] ~ ~ ~ playsound sw.music.fire_ability @a[r=20]
execute @a[tag=mes_sb_volcano,scores={mes_splbk_vcnt=16..100,book=4}] ~ ~ ~ event entity @s mes_splbk:cooldown_on
execute @a[tag=mes_sb_volcano,scores={mes_splbk_vcnt=1}] ~ ~ ~ summon mes_splbk:volcano ^ ^1.8 ^5 
execute @a[tag=mes_sb_volcano,scores={mes_splbk_vcnt=1..5}] ~ ~ ~ execute @e[type=mes_splbk:volcano] ~ ~ ~ detect ~ ~-0.5 ~ air 0 tp @s ~ ~-0.5 ~
execute @a[tag=mes_sb_volcano,scores={mes_splbk_vcnt=1}] ~ ~ ~ effect @e[type=mes_splbk:volcano] invisibility 1 255 true
execute @a[tag=mes_sb_volcano,scores={mes_splbk_vcnt=3}] ~ ~ ~ effect @e[type=mes_splbk:volcano] invisibility 0
execute @a[tag=mes_sb_volcano,scores={mes_splbk_vcnt=3}] ~ ~ ~ playanimation @e[type=mes_splbk:volcano] animation.mes_splbk.volcano.start f 100
execute @a[tag=mes_sb_volcano,scores={mes_splbk_vcnt=1..94}] ~ ~ ~ execute @e[type=mes_splbk:volcano] ~ ~ ~ execute @e[type=!player,family=!inac,family=!npc,type=!item,r=15,family=mob,type=!mes_splbk:volcano] ~ ~ ~ fill ~ ~ ~ ~ ~ ~ fire 0 replace air 0
execute @a[tag=mes_sb_volcano,scores={mes_splbk_vcnt=1..85}] ~ ~ ~ execute @e[type=mes_splbk:volcano] ~ ~ ~ particle mes_splbk:volcano ~ ~2 ~
execute @a[tag=mes_sb_volcano,scores={mes_splbk_vcnt=24}] ~ ~ ~ execute @e[type=mes_splbk:volcano] ~ ~ ~ particle mes_splbk:volcano_explode ~ ~2 ~
execute @a[tag=mes_sb_volcano,scores={mes_splbk_vcnt=44}] ~ ~ ~ execute @e[type=mes_splbk:volcano] ~ ~ ~ particle mes_splbk:volcano_explode ~ ~2 ~
execute @a[tag=mes_sb_volcano,scores={mes_splbk_vcnt=64}] ~ ~ ~ execute @e[type=mes_splbk:volcano] ~ ~ ~ particle mes_splbk:volcano_explode ~ ~2 ~
execute @a[tag=mes_sb_volcano,scores={mes_splbk_vcnt=94}] ~ ~ ~ execute @e[type=mes_splbk:volcano] ~ ~ ~ particle mes_splbk:volcano_explode ~ ~2 ~
execute @a[tag=mes_sb_volcano,scores={mes_splbk_vcnt=24}] ~ ~ ~ execute @e[type=mes_splbk:volcano] ~ ~ ~ playsound cauldron.explode @a[r=15]
execute @a[tag=mes_sb_volcano,scores={mes_splbk_vcnt=44}] ~ ~ ~ execute @e[type=mes_splbk:volcano] ~ ~ ~ playsound cauldron.explode @a[r=15]
execute @a[tag=mes_sb_volcano,scores={mes_splbk_vcnt=64}] ~ ~ ~ execute @e[type=mes_splbk:volcano] ~ ~ ~ playsound cauldron.explode @a[r=15]
execute @a[tag=mes_sb_volcano,scores={mes_splbk_vcnt=94}] ~ ~ ~ execute @e[type=mes_splbk:volcano] ~ ~ ~ playsound cauldron.explode @a[r=15]
execute @a[tag=mes_sb_volcano,scores={mes_splbk_vcnt=24}] ~ ~ ~ execute @e[type=mes_splbk:volcano] ~ ~ ~ execute @e[type=!player,family=!inac,family=!npc,type=!item,r=15,family=mob,type=!mes_splbk:volcano] ~ ~ ~ summon mes_splbk:miniinstanttnt
execute @a[tag=mes_sb_volcano,scores={mes_splbk_vcnt=44}] ~ ~ ~ execute @e[type=mes_splbk:volcano] ~ ~ ~ execute @e[type=!player,family=!inac,family=!npc,type=!item,r=15,family=mob,type=!mes_splbk:volcano] ~ ~ ~ summon mes_splbk:miniinstanttnt
execute @a[tag=mes_sb_volcano,scores={mes_splbk_vcnt=64}] ~ ~ ~ execute @e[type=mes_splbk:volcano] ~ ~ ~ execute @e[type=!player,family=!inac,family=!npc,type=!item,r=15,family=mob,type=!mes_splbk:volcano] ~ ~ ~ summon mes_splbk:miniinstanttnt
execute @a[tag=mes_sb_volcano,scores={mes_splbk_vcnt=94}] ~ ~ ~ execute @e[type=mes_splbk:volcano] ~ ~ ~ execute @e[type=!player,family=!inac,family=!npc,type=!item,r=15,family=mob,type=!mes_splbk:volcano] ~ ~ ~ summon mes_splbk:miniinstanttnt
execute @a[tag=mes_sb_volcano,scores={mes_splbk_vcnt=94}] ~ ~ ~ execute @e[type=mes_splbk:volcano] ~ ~ ~ tp @s ~ ~-100 ~
execute @a[tag=mes_sb_volcano,scores={mes_splbk_vcnt=94}] ~ ~ ~ fill ~-10 ~-1 ~-10 ~10 ~2 ~10 air 0 replace fire
execute @a[tag=mes_sb_volcano,scores={mes_splbk_vcnt=100}] ~ ~ ~ kill @e[type=mes_splbk:volcano]
execute @a[tag=mes_sb_volcano,scores={mes_splbk_vcnt=101}] ~ ~ ~ event entity @s mes_splbk:cooldown_off
tag @a[tag=mes_sb_volcano,scores={mes_splbk_vcnt=101}] remove mes_sb_volcano
scoreboard players set @p[r=1,scores={mes_splbk_vcnt=101}] mes_splbk_vcnt 0

execute @e[type=mes_splbk:volcano,tag=!playanim] ~ ~ ~ playanimation @s animation.mes_splbk.volcano.spawn
execute @e[type=mes_splbk:volcano,tag=!playanim] ~ ~ ~ tag @s add playanim


scoreboard players add @p[r=1,tag=mes_sb_snow] mes_splbk_mlt 1
execute @a[tag=mes_sb_snow,scores={mes_splbk_mlt=16..148,book=1}] ~ ~ ~ event entity @s mes_splbk:cooldown_on
execute @p[tag=mes_sb_snow,scores={mes_splbk_mlt=1}] ~ ~ ~ summon minecraft:snow_golem
execute @p[tag=mes_sb_snow,scores={mes_splbk_mlt=1..}] ~ ~ ~ execute @e[type=minecraft:snow_golem,r=10] ~ ~ ~ particle mes_splbk:snowman ~ ~ ~
execute @p[tag=mes_sb_snow,scores={mes_splbk_mlt=1}] ~ ~ ~ spreadplayers ~ ~ 7 10 @p
execute @p[tag=mes_sb_snow,scores={mes_splbk_mlt=2}] ~ ~ ~ tp @s ~ ~ ~ facing @e[type=snow_golem]
execute @p[tag=mes_sb_snow,scores={mes_splbk_mlt=2}] ~ ~ ~ particle mes_splbk:frost_poof ~ ~ ~
execute @p[tag=mes_sb_snow,scores={mes_splbk_mlt=2}] ~ ~ ~ effect @e[type=snow_golem] slowness 7 255 true
execute @p[tag=mes_sb_snow,scores={mes_splbk_mlt=2}] ~ ~ ~ effect @e[type=snow_golem] resistance 7 5 true
execute @p[tag=mes_sb_snow,scores={mes_splbk_mlt=1}] ~ ~ ~ playsound mob.snowgolem.death @a[r=20]
execute @p[tag=mes_sb_snow,scores={mes_splbk_mlt=150}] ~ ~ ~ tp @e[type=minecraft:snow_golem] ~ ~-100 ~
execute @p[tag=mes_sb_snow,scores={mes_splbk_mlt=150}] ~ ~ ~ playsound mob.snowgolem.death @a[r=20]
execute @a[tag=mes_sb_snow,scores={mes_splbk_mlt=150}] ~ ~ ~ event entity @s mes_splbk:cooldown_off
tag @p[tag=mes_sb_snow,scores={mes_splbk_mlt=150}] add revmsnow
tag @p[tag=mes_sb_snow,scores={mes_splbk_mlt=150}] remove mes_sb_snow
scoreboard players set @p[tag=revmsnow,scores={mes_splbk_mlt=150}] mes_splbk_mlt 0
tag @p remove revmsnow


scoreboard players add @p[r=1,tag=mes_sb_hdblt] mes_splbk_mlt 1
execute @p[tag=mes_sb_hdblt,scores={mes_splbk_mlt=1}] ~ ~ ~ execute @e[r=10,type=!mes_splbk:maelstrom,type=!item,type=!player,family=!inac,family=!npc,family=mob] ~ ~ ~ tag @p[tag=mes_sb_hdblt] add yes
execute @p[tag=mes_sb_hdblt,scores={mes_splbk_mlt=1}] ~ ~ ~ titleraw @p[tag=mes_sb_hdblt,tag=!yes] actionbar { "rawtext" : [ { "translate" : "noone.text" } ] }
execute @p[tag=mes_sb_hdblt,scores={mes_splbk_mlt=1}] ~ ~ ~ scoreboard players set @p[tag=mes_sb_hdblt,tag=!yes] mes_splbk_mlt 49
execute @p[tag=mes_sb_hdblt,scores={mes_splbk_mlt=1}] ~ ~ ~ execute @e[r=10,type=!mes_splbk:maelstrom,type=!item,type=!player,family=!inac,family=!npc,family=mob] ~ ~ ~ particle mes_splbk:hydroblast
execute @p[tag=mes_sb_hdblt,scores={mes_splbk_mlt=1}] ~ ~ ~ execute @e[r=10,type=!mes_splbk:maelstrom,type=!item,type=!player,family=!inac,family=!npc,family=mob] ~ ~ ~ particle mes_splbk:hydroblast_bubble
execute @p[tag=mes_sb_hdblt,scores={mes_splbk_mlt=1}] ~ ~ ~ execute @e[r=10,type=!mes_splbk:maelstrom,type=!item,type=!player,family=!inac,family=!npc,family=mob] ~ ~ ~ effect @s levitation 1 25 true
execute @p[tag=mes_sb_hdblt,scores={mes_splbk_mlt=1}] ~ ~ ~ playsound mob.breeze.charge @a[r=20]
execute @p[tag=mes_sb_hdblt,scores={mes_splbk_mlt=5}] ~ ~ ~ tag @a[tag=mes_sb_hdblt] remove yes
tag @p[tag=mes_sb_hdblt,scores={mes_splbk_mlt=50}] add removetimeblde
tag @p[tag=mes_sb_hdblt,scores={mes_splbk_mlt=50}] remove mes_sb_hdblt
scoreboard players set @p[tag=removetimeblde,scores={mes_splbk_mlt=50}] mes_splbk_mlt 0
tag @p remove removetimeblde

scoreboard players add @p[r=1,tag=mes_sb_mlstrm] mes_splbk_mlt 1
execute @p[r=1,scores={mes_splbk_mlt=16..99,book=1},tag=mes_sb_mlstrm] ~ ~ ~ event entity @s mes_splbk:cooldown_on
execute @p[r=1,scores={mes_splbk_mlt=1},tag=mes_sb_mlstrm] ~ ~ ~ summon mes_splbk:maelstrom ^ ^2 ^5
execute @p[r=1,scores={mes_splbk_mlt=1},tag=mes_sb_mlstrm] ~ ~ ~ playsound firework.shoot @p[r=10]
execute @p[r=1,scores={mes_splbk_mlt=13},tag=mes_sb_mlstrm] ~ ~ ~ playsound mob.breeze.idle_ground @a[r=10]
execute @p[r=1,scores={mes_splbk_mlt=80},tag=mes_sb_mlstrm] ~ ~ ~ playsound mob.breeze.inhale @a[r=10]
execute @e[type=mes_splbk:maelstrom] ~ ~ ~ particle mes_splbk:maelstrom ~ ~ ~
execute @e[type=mes_splbk:maelstrom] ~ ~ ~ execute @e[r=16,family=mob,type=!mes_splbk:maelstrom,type=!item,tag=!maelstrom,type=!player,family=!inac,family=!npc,type=!armor_stand] ~ ~ ~ tp @s ^ ^0.15 ^0.35 facing @e[type=mes_splbk:maelstrom]
execute @p[r=1,scores={mes_splbk_mlt=100..},tag=mes_sb_mlstrm] ~ ~ ~ execute @e[type=mes_splbk:maelstrom] ~ ~ ~ effect @e[r=16,type=!mes_splbk:maelstrom,family=mob,type=!item,tag=!maelstrom] instant_damage 2 255 true
execute @p[r=1,scores={mes_splbk_mlt=100..},tag=mes_sb_mlstrm] ~ ~ ~ execute @e[type=mes_splbk:maelstrom] ~ ~ ~ particle mes_splbk:bubble_air ~ ~2 ~
execute @p[r=1,scores={mes_splbk_mlt=100..},tag=mes_sb_mlstrm] ~ ~ ~ execute @e[type=mes_splbk:maelstrom] ~ ~ ~ particle mes_splbk:bubble_air ~ ~3 ~
execute @p[r=1,scores={mes_splbk_mlt=100..},tag=mes_sb_mlstrm] ~ ~ ~ playsound cauldron.explode @a[r=20]
execute @p[r=1,scores={mes_splbk_mlt=100..},tag=mes_sb_mlstrm] ~ ~ ~ execute @e[type=mes_splbk:maelstrom] ~ ~ ~ kill @s
execute @p[r=1,scores={mes_splbk_mlt=100..},tag=mes_sb_mlstrm] ~ ~ ~ event entity @s mes_splbk:cooldown_off
tag @p[r=1,scores={mes_splbk_mlt=100..},tag=mes_sb_mlstrm] add removetimec
tag @p[r=1,scores={mes_splbk_mlt=100..},tag=mes_sb_mlstrm] remove mes_sb_mlstrm
scoreboard players set @p[r=1,tag=removetimec,scores={mes_splbk_mlt=100..}] mes_splbk_mlt 0
tag @p remove removetimec


scoreboard players add @p[r=1,tag=mes_sb_bble] mes_splbk_bt 1
execute @a[tag=mes_sb_bble,scores={mes_splbk_bt=16..34,book=2}] ~ ~ ~ event entity @s mes_splbk:cooldown_on
execute @p[tag=mes_sb_bble,scores={mes_splbk_bt=1}] ~ ~ ~ particle mes_splbk:bubble_launch ^ ^1 ^1.2
execute @p[tag=mes_sb_bble,scores={mes_splbk_bt=1}] ~ ~ ~ playsound mob.breeze.slide @a[r=5]
execute @p[tag=mes_sb_bble,scores={mes_splbk_bt=1}] ~ ~ ~ tag @s add mes_sb_bbll
execute @p[tag=mes_sb_bble,scores={mes_splbk_bt=35}] ~ ~ ~ particle mes_splbk:bubble ~ ~1.5 ~
execute @p[tag=mes_sb_bble,scores={mes_splbk_bt=35}] ~ ~ ~ kill @e[type=mes_splbk:bubble_shoot]
execute @p[tag=mes_sb_bble,scores={mes_splbk_bt=35}] ~ ~ ~ event entity @s mes_splbk:cooldown_off
tag @p[tag=mes_sb_bble,scores={mes_splbk_bt=35}] remove mes_sb_bble
scoreboard players set @p[r=1,scores={mes_splbk_bt=35}] mes_splbk_bt 0

execute @e[type=mes_splbk:bubble_shoot] ~ ~ ~ particle mes_splbk:bubble_launch ~ ~ ~
execute @e[type=mes_splbk:bubble_shoot] ~ ~ ~ tp @e[family=mob,type=!player,r=4] ~ ~ ~
execute @e[type=mes_splbk:bubble_shoot] ~ ~ ~ effect @e[family=mob,type=!player,r=4] fatal_poison 3 255 true

scoreboard players add @p[r=1,tag=mes_sb_water] mes_splbk_mlt 1
execute @a[tag=mes_sb_water,scores={mes_splbk_mlt=16..99,book=4}] ~ ~ ~ event entity @p[tag=mes_sb_water] mes_splbk:cooldown_on
execute @p[tag=mes_sb_water,scores={mes_splbk_mlt=1}] ~ ~ ~ effect @p fire_resistance 5 255 true
execute @p[tag=mes_sb_water,scores={mes_splbk_mlt=1}] ~ ~ ~ playsound cauldron.takewater @a[r=10]
execute @p[tag=mes_sb_water,scores={mes_splbk_mlt=75}] ~ ~ ~ playsound mob.breeze.idle_air @a[r=10]
execute @p[tag=mes_sb_water,scores={mes_splbk_mlt=1}] ~ ~ ~ summon mes_splbk:water ~ ~ ~
execute @p[tag=mes_sb_water,scores={mes_splbk_mlt=1..}] ~ ~ ~ execute @e[type=mes_splbk:water] ~ ~ ~ particle mes_splbk:water ~ ~ ~
execute @p[tag=mes_sb_water,scores={mes_splbk_mlt=1..}] ~ ~ ~ execute @e[type=mes_splbk:water] ~ ~ ~ execute @e[family=mob,type=!mes_splbk:water,r=10] ~ ~ ~ tp @s ^ ^0.5 ^-0.4 facing @e[type=mes_splbk:water]
execute @p[tag=mes_sb_water,scores={mes_splbk_mlt=97}] ~ ~ ~ execute @e[type=mes_splbk:water] ~ ~ ~ particle mes_splbk:bubble ~ ~3 ~
execute @p[tag=mes_sb_water,scores={mes_splbk_mlt=97}] ~ ~ ~ execute @e[type=mes_splbk:water] ~ ~ ~ playsound cauldron.explode @a[r=15]
execute @p[tag=mes_sb_water,scores={mes_splbk_mlt=98}] ~ ~ ~ tp @e[type=mes_splbk:water] ~ ~-100 ~
execute @p[tag=mes_sb_water,scores={mes_splbk_mlt=100}] ~ ~ ~ kill @e[type=mes_splbk:water]
execute @p[tag=mes_sb_water,scores={mes_splbk_mlt=100}] ~ ~ ~ event entity @p[tag=mes_sb_water] mes_splbk:cooldown_off
tag @p[tag=mes_sb_water,scores={mes_splbk_mlt=100}] add revww
tag @p[tag=mes_sb_water,scores={mes_splbk_mlt=100}] remove mes_sb_water
scoreboard players set @p[tag=revww,scores={mes_splbk_mlt=100}] mes_splbk_mlt 0
tag @p[r=1] remove revww


scoreboard players add @p[r=1,tag=mes_sb_iclce] mes_splbk_iclt 1
execute @p[tag=mes_sb_iclce,scores={mes_splbk_iclt=1}] ~ ~ ~ tag @s add mes_sb_td
execute @p[tag=mes_sb_iclce,scores={mes_splbk_iclt=1}] ~ ~ ~ particle mes_splbk:icelance_launch ^ ^1 ^1.2
execute @p[tag=mes_sb_iclce,scores={mes_splbk_iclt=1}] ~ ~ ~ effect @a[r=5,tag=mes_sb_small] speed 5 1 true
execute @p[tag=mes_sb_iclce,scores={mes_splbk_iclt=1}] ~ ~ ~ effect @a[r=5,tag=mes_sb_medium] speed 5 2 true
execute @p[tag=mes_sb_iclce,scores={mes_splbk_iclt=1}] ~ ~ ~ effect @a[r=5,tag=mes_sb_big] speed 5 4 true
execute @p[tag=mes_sb_iclce,scores={mes_splbk_iclt=1}] ~ ~ ~ playsound sw.music.banished_ability @a[r=5] 
execute @p[tag=mes_sb_iclce,scores={mes_splbk_iclt=1}] ~ ~ ~ tag @s add mes_sb_icel
execute @p[tag=mes_sb_iclce,scores={mes_splbk_iclt=6},tag=mes_sb_small] ~ ~ ~ playanimation @e[type=mes_splbk:icelance_shoot] animation.mes_splbk.icelance.small
execute @p[tag=mes_sb_iclce,scores={mes_splbk_iclt=6},tag=mes_sb_medium] ~ ~ ~ playanimation @e[type=mes_splbk:icelance_shoot] animation.mes_splbk.icelance.medium
execute @p[tag=mes_sb_iclce,scores={mes_splbk_iclt=6},tag=mes_sb_big] ~ ~ ~ playanimation @e[type=mes_splbk:icelance_shoot] animation.mes_splbk.icelance.big
execute @p[tag=mes_sb_iclce,scores={mes_splbk_iclt=1..}] ~ ~ ~ effect @e[family=mob,type=!player,r=6] slowness 5 255 true
execute @p[tag=mes_sb_iclce,scores={mes_splbk_iclt=35}] ~ ~ ~ execute @e[type=mes_splbk:icelance_shoot] ~ ~ ~ particle mes_splbk:icelance_explode
execute @p[tag=mes_sb_iclce,scores={mes_splbk_iclt=35}] ~ ~ ~ execute @e[type=mes_splbk:icelance_shoot] ~ ~ ~ particle mes_splbk:icelance_explode
execute @p[tag=mes_sb_iclce,scores={mes_splbk_iclt=35}] ~ ~ ~ execute @e[type=mes_splbk:icelance_shoot] ~ ~ ~ summon mes_splbk:miniinstanttnt
execute @p[tag=mes_sb_iclce,scores={mes_splbk_iclt=35},tag=mes_sb_big] ~ ~ ~ execute @e[type=mes_splbk:icelance_shoot] ~ ~ ~ summon mes_splbk:instanttnt
execute @p[tag=mes_sb_iclce,scores={mes_splbk_iclt=35}] ~ ~ ~ playsound block.glass.break @a[r=20]
execute @p[tag=mes_sb_iclce,scores={mes_splbk_iclt=35}] ~ ~ ~ kill @e[type=mes_splbk:icelance_shoot]
tag @p[tag=mes_sb_iclce,scores={mes_splbk_iclt=35}] remove mes_sb_small
tag @p[tag=mes_sb_iclce,scores={mes_splbk_iclt=35}] remove mes_sb_medium
tag @p[tag=mes_sb_iclce,scores={mes_splbk_iclt=35}] remove mes_sb_big
tag @p[tag=mes_sb_iclce,scores={mes_splbk_iclt=35}] remove mes_sb_iclce
scoreboard players set @p[r=1,scores={mes_splbk_iclt=35}] mes_splbk_iclt 0

execute @e[type=mes_splbk:icelance_shoot] ~ ~ ~ particle minecraft:falling_dust_top_snow_particle ~ ~ ~

scoreboard players add @p[r=1,tag=mes_sb_wave] mes_splbk_mlt 1
execute @a[tag=mes_sb_wave,scores={mes_splbk_mlt=16..110,book=0}] ~ ~ ~ event entity @s mes_splbk:cooldown_on
execute @a[tag=mes_sb_wave,scores={mes_splbk_mlt=1}] ~ ~ ~ playsound bucket.fill_water @a[r=10]
execute @a[tag=mes_sb_wave,scores={mes_splbk_mlt=1}] ~ ~ ~ summon mes_splbk:nothing ~ ~ ~
execute @a[tag=mes_sb_wave,scores={mes_splbk_mlt=1}] ~ ~ ~ summon mes_splbk:wave ~ ~-100 ~
execute @a[tag=mes_sb_wave,scores={mes_splbk_mlt=2}] ~ ~ ~ particle mes_splbk:wave_launch ^ ^1 ^1
execute @a[tag=mes_sb_wave,scores={mes_splbk_mlt=1}] ~ ~ ~ effect @e[family=mob,r=4] slowness 2 255 true
execute @a[tag=mes_sb_wave,scores={mes_splbk_mlt=1}] ~ ~ ~ effect @e[type=mes_splbk:wave] invisibility 100 255 true
execute @a[tag=mes_sb_wave,scores={mes_splbk_mlt=1}] ~ ~ ~ tp @e[type=mes_splbk:wave] ^ ^1 ^2 facing @p[tag=mes_sb_wave]
execute @a[tag=mes_sb_wave,scores={mes_splbk_mlt=1..7}] ~ ~ ~ execute @e[type=mes_splbk:wave] ~ ~ ~ detect ~ ~-0.3 ~ air 0 tp @s ~ ~-0.3 ~
execute @a[tag=mes_sb_wave,scores={mes_splbk_mlt=8..}] ~ ~ ~ execute @e[type=mes_splbk:wave] ~ ~ ~ detect ~ ~-0.1 ~ air 0 tp @s ~ ~-0.1 ~
execute @a[tag=mes_sb_wave,scores={mes_splbk_mlt=6}] ~ ~ ~ effect @e[type=mes_splbk:wave] clear
execute @a[tag=mes_sb_wave,scores={mes_splbk_mlt=6}] ~ ~ ~ playanimation @e[type=mes_splbk:wave] animation.mes_splbk.wave.start
execute @a[tag=mes_sb_wave,scores={mes_splbk_mlt=8}] ~ ~ ~ playsound liquid.water @a[r=10]
execute @a[tag=mes_sb_wave,scores={mes_splbk_mlt=30}] ~ ~ ~ playsound liquid.water @a[r=10]
execute @a[tag=mes_sb_wave,scores={mes_splbk_mlt=70}] ~ ~ ~ playsound liquid.water @a[r=10]
execute @a[tag=mes_sb_wave,scores={mes_splbk_mlt=8..}] ~ ~ ~ execute @e[type=mes_splbk:wave] ~ ~ ~ tp @s ^ ^ ^-0.42 facing @e[type=mes_splbk:nothing]
execute @a[tag=mes_sb_wave,scores={mes_splbk_mlt=8..}] ~ ~ ~ execute @e[type=mes_splbk:wave] ~ ~ ~ tp @e[family=mob,family=!inac,family=!npc,r=3] ^ ^ ^-0.80
execute @a[tag=mes_sb_wave,scores={mes_splbk_mlt=108}] ~ ~ ~ tp @e[type=mes_splbk:nothing] ~ ~-100 ~
execute @a[tag=mes_sb_wave,scores={mes_splbk_mlt=108}] ~ ~ ~ execute @e[type=mes_splbk:wave] ~ ~ ~ playsound cauldron.explode @a ~ ~ ~
execute @a[tag=mes_sb_wave,scores={mes_splbk_mlt=108}] ~ ~ ~ execute @e[type=mes_splbk:wave] ~ ~ ~ particle mes_splbk:bubble ~ ~2 ~
execute @a[tag=mes_sb_wave,scores={mes_splbk_mlt=108}] ~ ~ ~ execute @e[type=mes_splbk:wave] ~ ~ ~ tp @s ~ ~-100 ~
execute @a[tag=mes_sb_wave,scores={mes_splbk_mlt=112}] ~ ~ ~ kill @e[type=mes_splbk:wave]
execute @a[tag=mes_sb_wave,scores={mes_splbk_mlt=112}] ~ ~ ~ kill @e[type=mes_splbk:nothing]
execute @a[tag=mes_sb_wave,scores={mes_splbk_mlt=112}] ~ ~ ~ event entity @s mes_splbk:cooldown_off
tag @a[tag=mes_sb_wave,scores={mes_splbk_mlt=112}] add revww
tag @a[tag=mes_sb_wave,scores={mes_splbk_mlt=112}] remove mes_sb_wave
scoreboard players set @p[tag=revww,scores={mes_splbk_mlt=112}] mes_splbk_mlt 0
tag @p remove revww

execute @a[tag=mes_sb_wave,scores={mes_splbk_mlt=1..111}] ~ ~ ~ execute @e[type=mes_splbk:wave] ~ ~ ~ particle mes_splbk:wave
execute @a[tag=mes_sb_wave,scores={mes_splbk_mlt=8..111}] ~ ~ ~ execute @e[type=mes_splbk:wave] ~ ~ ~ particle mes_splbk:wave_launch ^ ^ ^1






scoreboard players add @p[r=1,tag=mes_sb_stnfsts] mes_splbk_stnt 1
execute @p[tag=mes_sb_stnfsts,scores={mes_splbk_stnt=16..120,book=0}] ~ ~ ~ event entity @s mes_splbk:cooldown_on
execute @p[tag=mes_sb_stnfsts,scores={mes_splbk_stnt=1}] ~ ~ ~ playsound sw.music.fire_ability @a[r=20]
execute @p[tag=mes_sb_stnfsts,scores={mes_splbk_stnt=1}] ~ ~ ~ summon mes_splbk:stone_boulder ^1 ^1.5 ^2
execute @p[tag=mes_sb_stnfsts,scores={mes_splbk_stnt=1}] ~ ~ ~ summon mes_splbk:stone_boulder ^-1 ^1.5 ^2
execute @p[tag=mes_sb_stnfsts,scores={mes_splbk_stnt=1}] ~ ~ ~ titleraw @p[tag=mes_sb_stnfsts] actionbar { "rawtext" : [ { "translate" : "stoneboulder.punch" } ] }
execute @p[tag=mes_sb_stnfsts,scores={mes_splbk_stnt=120}] ~ ~ ~ event entity @s mes_splbk:cooldown_off
tag @p[tag=mes_sb_stnfsts,scores={mes_splbk_stnt=120}] remove mes_sb_stnfsts
scoreboard players set @p[r=1,scores={mes_splbk_stnt=120}] mes_splbk_stnt 0

scoreboard players add @e[type=mes_splbk:stone_boulder] mes_splbk_stnt 1
execute @e[type=mes_splbk:stone_boulder] ~ ~ ~ particle mes_splbk:stone_boulder_ambient ~ ~ ~
execute @e[type=mes_splbk:stone_boulder,scores={mes_splbk_stnt=116}] ~ ~ ~ effect @a resistance 2 255 true
execute @e[type=mes_splbk:stone_boulder,scores={mes_splbk_stnt=120}] ~ ~ ~ playsound random.explode @a[r=30]
execute @e[type=mes_splbk:stone_boulder,scores={mes_splbk_stnt=120}] ~ ~ ~ summon mes_splbk:instanttnt
execute @e[type=mes_splbk:stone_boulder,scores={mes_splbk_stnt=120}] ~ ~ ~ summon mes_splbk:instanttnt
execute @e[type=mes_splbk:stone_boulder,scores={mes_splbk_stnt=120}] ~ ~ ~ particle mes_splbk:stone_boulder_explode ~ ~ ~
execute @e[type=mes_splbk:stone_boulder,scores={mes_splbk_stnt=120}] ~ ~ ~ effect @e[r=8] instant_damage 3 1 true
execute @e[type=mes_splbk:stone_boulder,scores={mes_splbk_stnt=121}] ~ ~ ~ kill @s

scoreboard players add @p[r=1,tag=mes_sb_stnbdy] mes_splbk_stnbt 1
execute @p[tag=mes_sb_stnbdy,scores={mes_splbk_stnbt=16..1000,book=2}] ~ ~ ~ event entity @s mes_splbk:cooldown_on
execute @p[tag=mes_sb_stnbdy,scores={mes_splbk_stnbt=1}] ~ ~ ~ effect @p health_boost 30 4 true
execute @p[tag=mes_sb_stnbdy,scores={mes_splbk_stnbt=2}] ~ ~ ~ effect @p instant_health 1 255 true
execute @p[tag=mes_sb_stnbdy,scores={mes_splbk_stnbt=2}] ~ ~ ~ effect @p jump_boost 30 2 true
execute @p[tag=mes_sb_stnbdy,scores={mes_splbk_stnbt=1}] ~ ~ ~ playsound sw.music.heart_ability @a[r=20]
execute @p[tag=mes_sb_stnbdy,scores={mes_splbk_stnbt=1001}] ~ ~ ~ event entity @s mes_splbk:cooldown_off
tag @p[tag=mes_sb_stnbdy,scores={mes_splbk_stnbt=1001}] add revstb
tag @p[tag=mes_sb_stnbdy,scores={mes_splbk_stnbt=1001}] remove mes_sb_stnbdy
scoreboard players set @p[tag=revstb,scores={mes_splbk_stnbt=1001}] mes_splbk_stnbt 0
tag @p remove revstb

scoreboard players add @p[r=1,tag=mes_sb_aval] mes_splbk_avlt 1
execute @p[tag=mes_sb_aval,scores={mes_splbk_avlt=16..99,book=3}] ~ ~ ~ event entity @s mes_splbk:cooldown_on
execute @p[tag=mes_sb_aval,scores={mes_splbk_avlt=1}] ~ ~ ~ playsound sw.music.boulder_ability @a[r=20] 
execute @p[tag=mes_sb_aval,scores={mes_splbk_avlt=1}] ~ ~ ~ execute @e[r=15,family=mob,type=!mes_splbk:avalanche] ~ ~ ~ summon mes_splbk:avalanche ~ ~20 ~
execute @p[tag=mes_sb_aval,scores={mes_splbk_avlt=1}] ~ ~ ~ execute @e[r=15,family=mob,type=!mes_splbk:avalanche] ~ ~ ~ tag @p[tag=mes_sb_aval] add yes
execute @p[tag=mes_sb_aval,scores={mes_splbk_avlt=1}] ~ ~ ~ titleraw @p[tag=mes_sb_aval,tag=!yes] actionbar { "rawtext" : [ { "translate" : "noone.text" } ] }
execute @p[tag=mes_sb_aval,scores={mes_splbk_avlt=1}] ~ ~ ~ scoreboard players set @p[tag=mes_sb_aval,tag=!yes] mes_splbk_avlt 80
execute @p[tag=mes_sb_aval,scores={mes_splbk_avlt=1}] ~ ~ ~ effect @e[r=18,family=mob,type=!mes_splbk:avalanche] slowness 5 255 true
execute @p[tag=mes_sb_aval,scores={mes_splbk_avlt=2}] ~ ~ ~ playanimation @e[type=mes_splbk:avalanche] animation.mes_splbk.avalanche.start
execute @p[tag=mes_sb_aval,scores={mes_splbk_avlt=1..}] ~ ~ ~ execute @e[r=15,family=mob,type=!mes_splbk:avalanche] ~ ~ ~ execute @e[type=mes_splbk:avalanche,r=1.5] ~ ~ ~ summon mes_splbk:miniinstanttnt ~ ~-1.5 ~
execute @p[tag=mes_sb_aval,scores={mes_splbk_avlt=1..}] ~ ~ ~ execute @e[r=15,family=mob,type=!mes_splbk:avalanche] ~ ~ ~ execute @e[type=mes_splbk:avalanche,r=1.5] ~ ~ ~ particle mes_splbk:avalanche_explode
execute @p[tag=mes_sb_aval,scores={mes_splbk_avlt=1..}] ~ ~ ~ execute @e[r=15,family=mob,type=!mes_splbk:avalanche] ~ ~ ~ execute @e[type=mes_splbk:avalanche,r=1.5] ~ ~ ~ effect @e[r=2,family=mob,type=!mes_splbk:avalanche] instant_damage 1 1 true
execute @p[tag=mes_sb_aval,scores={mes_splbk_avlt=1..}] ~ ~ ~ execute @e[r=15,family=mob,type=!mes_splbk:avalanche] ~ ~ ~ tp @e[type=mes_splbk:avalanche,r=1.5] ~ ~-100 ~
execute @p[tag=mes_sb_aval,scores={mes_splbk_avlt=80}] ~ ~ ~ tp @e[type=mes_splbk:avalanche] ~ ~-100 ~
execute @p[tag=mes_sb_aval,scores={mes_splbk_avlt=82}] ~ ~ ~ kill @e[type=mes_splbk:avalanche]
execute @p[tag=mes_sb_aval,scores={mes_splbk_avlt=5}] ~ ~ ~ tag @p[tag=mes_sb_aval] remove yes
execute @p[tag=mes_sb_aval,scores={mes_splbk_avlt=99}] ~ ~ ~ event entity @s mes_splbk:cooldown_off
tag @p[tag=mes_sb_aval,scores={mes_splbk_avlt=100}] remove mes_sb_aval
scoreboard players set @p[r=1,scores={mes_splbk_avlt=100}] mes_splbk_avlt 0

scoreboard players add @p[r=1,tag=mes_sb_entomb] mes_splbk_etbt 1
execute @p[tag=mes_sb_entomb,scores={mes_splbk_etbt=16..99,book=1}] ~ ~ ~ event entity @s mes_splbk:cooldown_on
execute @p[tag=mes_sb_entomb,scores={mes_splbk_etbt=1}] ~ ~ ~ playsound sw.music.boulder_ability @a[r=20]
execute @p[tag=mes_sb_entomb,scores={mes_splbk_etbt=1}] ~ ~ ~ execute @e[r=12,family=mob,rm=1] ~ ~ ~ summon mes_splbk:entomb
execute @p[tag=mes_sb_entomb,scores={mes_splbk_etbt=1}] ~ ~ ~ execute @e[r=12,family=mob,rm=1] ~ ~ ~ tag @p[tag=mes_sb_entomb] add yes
execute @p[tag=mes_sb_entomb,scores={mes_splbk_etbt=1}] ~ ~ ~ titleraw @p[tag=mes_sb_entomb,tag=!yes] actionbar { "rawtext" : [ { "translate" : "noone.text" } ] }
execute @p[tag=mes_sb_entomb,scores={mes_splbk_etbt=1}] ~ ~ ~ scoreboard players set @p[tag=mes_sb_entomb,tag=!yes] mes_splbk_etbt 80
execute @p[tag=mes_sb_entomb,scores={mes_splbk_etbt=1}] ~ ~ ~ effect @e[r=12,family=mob] slowness 6 255 true
execute @p[tag=mes_sb_entomb,scores={mes_splbk_etbt=3}] ~ ~ ~ playanimation @e[type=mes_splbk:entomb] animation.mes_splbk.entomb.start
execute @p[tag=mes_sb_entomb,scores={mes_splbk_etbt=80}] ~ ~ ~ execute @e[r=12,family=mob] ~ ~ ~ summon mes_splbk:miniinstanttnt
execute @p[tag=mes_sb_entomb,scores={mes_splbk_etbt=80}] ~ ~ ~ execute @e[r=12,family=mob] ~ ~ ~ particle mes_splbk:stone_boulder_explode
execute @p[tag=mes_sb_entomb,scores={mes_splbk_etbt=81}] ~ ~ ~ tp @e[type=mes_splbk:entomb] ~ ~-100 ~
execute @p[tag=mes_sb_entomb,scores={mes_splbk_etbt=82}] ~ ~ ~ kill @e[type=mes_splbk:entomb]
execute @p[tag=mes_sb_entomb,scores={mes_splbk_etbt=5}] ~ ~ ~ tag @p[tag=mes_sb_entomb] remove yes
execute @p[tag=mes_sb_entomb,scores={mes_splbk_etbt=99}] ~ ~ ~ event entity @s mes_splbk:cooldown_off 
tag @p[tag=mes_sb_entomb,scores={mes_splbk_etbt=100}] remove mes_sb_entomb
scoreboard players set @p[r=1,scores={mes_splbk_etbt=100}] mes_splbk_etbt 0

scoreboard players add @p[r=1,tag=mes_sb_earqke] mes_splbk_erqt 1
execute @p[tag=mes_sb_earqke,scores={mes_splbk_erqt=16..99,book=4}] ~ ~ ~ event entity @s mes_splbk:cooldown_on
execute @p[tag=mes_sb_earqke,scores={mes_splbk_erqt=1}] ~ ~ ~ effect @p resistance 5 255 true
execute @p[tag=mes_sb_earqke,scores={mes_splbk_erqt=1}] ~ ~ ~ playsound sw.music.mes_sb_inferno_ability @a[r=20]
execute @p[tag=mes_sb_earqke,scores={mes_splbk_erqt=1}] ~ ~ ~ particle mes_splbk:earthquake_launch ~ ~ ~
execute @p[tag=mes_sb_earqke,scores={mes_splbk_erqt=9..40}] ~ ~ ~ particle mes_splbk:earthquake ~ ~ ~
execute @p[tag=mes_sb_earqke,scores={mes_splbk_erqt=10}] ~ ~ ~ camerashake add @a[r=15] 1 1 positional
execute @p[tag=mes_sb_earqke,scores={mes_splbk_erqt=10}] ~ ~ ~ effect @e[family=mob,family=!npc,type=!player,r=15] fatal_poison 4 255 true
execute @p[tag=mes_sb_earqke,scores={mes_splbk_erqt=10}] ~ ~ ~ effect @e[family=mob,family=!npc,type=!player,r=15] slowness 4 255 true
execute @p[tag=mes_sb_earqke,scores={mes_splbk_erqt=99}] ~ ~ ~ event entity @s mes_splbk:cooldown_off
tag @p[tag=mes_sb_earqke,scores={mes_splbk_erqt=100}] remove mes_sb_earqke
scoreboard players set @p[r=1,scores={mes_splbk_erqt=100}] mes_splbk_erqt 0

scoreboard players add @p[r=1,tag=mes_sb_skltn] mes_splbk_ncrt 1
execute @p[tag=mes_sb_skltn,scores={mes_splbk_ncrt=16..262,book=0}] ~ ~ ~ event entity @s mes_splbk:cooldown_on
execute @p[tag=mes_sb_skltn,scores={mes_splbk_ncrt=5}] ~ ~ ~ playsound mob.skeleton.say @a[r=15]
execute @p[tag=mes_sb_skltn,scores={mes_splbk_ncrt=1}] ~ ~ ~ tag @s add mes_sb_td
execute @p[tag=mes_sb_skltn,scores={mes_splbk_ncrt=1}] ~ ~ ~ playsound sw.music.mes_sb_inferno_ability @a[r=15]
execute @p[tag=mes_sb_skltn,scores={mes_splbk_ncrt=1}] ~ ~ ~ summon mes_splbk:nskeleton ~ ~-2.1 ~2
execute @p[tag=mes_sb_skltn,scores={mes_splbk_ncrt=1}] ~ ~ ~ summon mes_splbk:nskeleton ~ ~-2.1 ~-2
execute @p[tag=mes_sb_skltn,scores={mes_splbk_ncrt=1}] ~ ~ ~ summon mes_splbk:nskeleton ~2 ~-2.1 ~
execute @p[tag=mes_sb_skltn,scores={mes_splbk_ncrt=1},tag=mes_sb_medium] ~ ~ ~ summon mes_splbk:nskeleton ~2 ~-2.1 ~2
execute @p[tag=mes_sb_skltn,scores={mes_splbk_ncrt=1},tag=mes_sb_big] ~ ~ ~ summon mes_splbk:nskeleton ~2 ~-2.1 ~2
execute @p[tag=mes_sb_skltn,scores={mes_splbk_ncrt=1},tag=mes_sb_big] ~ ~ ~ summon mes_splbk:nskeleton ~-2 ~-2.1 ~-2
execute @p[tag=mes_sb_skltn,scores={mes_splbk_ncrt=3}] ~ ~ ~ playanimation @e[type=mes_splbk:nskeleton] animation.evoker.casting f 3
execute @p[tag=mes_sb_skltn,scores={mes_splbk_ncrt=3..26}] ~ ~ ~ execute @e[type=mes_splbk:nskeleton,r=10] ~ ~ ~ tp @s ~ ~0.1 ~ 
execute @p[tag=mes_sb_skltn,scores={mes_splbk_ncrt=2..5}] ~ ~ ~ execute @e[type=mes_splbk:nskeleton] ~ ~ ~ particle mes_splbk:ground ~ ~2.0 ~
execute @p[tag=mes_sb_skltn,scores={mes_splbk_ncrt=258}] ~ ~ ~ execute @e[type=mes_splbk:nskeleton] ~ ~ ~ particle mes_splbk:poof ~ ~ ~
execute @p[tag=mes_sb_skltn,scores={mes_splbk_ncrt=259}] ~ ~ ~ execute @e[type=mes_splbk:nskeleton] ~ ~ ~ tp @s ~ ~-100 ~
execute @p[tag=mes_sb_skltn,scores={mes_splbk_ncrt=262}] ~ ~ ~ kill @e[type=mes_splbk:nskeleton] 
execute @p[tag=mes_sb_skltn,scores={mes_splbk_ncrt=262}] ~ ~ ~ event entity @s mes_splbk:cooldown_off
tag @p[tag=mes_sb_skltn,scores={mes_splbk_ncrt=263}] remove mes_sb_medium
tag @p[tag=mes_sb_skltn,scores={mes_splbk_ncrt=263}] remove mes_sb_big
tag @p[tag=mes_sb_skltn,scores={mes_splbk_ncrt=263}] add revns
tag @p[tag=mes_sb_skltn,scores={mes_splbk_ncrt=263}] remove mes_sb_skltn
scoreboard players set @p[tag=revns,scores={mes_splbk_ncrt=263}] mes_splbk_ncrt 0
tag @p remove revns

scoreboard players add @p[r=1,tag=mes_sb_zmbie] mes_splbk_ncrt 1
execute @p[tag=mes_sb_zmbie,scores={mes_splbk_ncrt=16..262,book=1}] ~ ~ ~ event entity @s mes_splbk:cooldown_on
execute @p[tag=mes_sb_zmbie,scores={mes_splbk_ncrt=5}] ~ ~ ~ playsound mob.zombie.say @a[r=15]
execute @p[tag=mes_sb_zmbie,scores={mes_splbk_ncrt=1}] ~ ~ ~ playsound sw.music.mes_sb_inferno_ability @a[r=15]
execute @p[tag=mes_sb_zmbie,scores={mes_splbk_ncrt=1}] ~ ~ ~ tag @s add mes_sb_td
execute @p[tag=mes_sb_zmbie,scores={mes_splbk_ncrt=1}] ~ ~ ~ summon mes_splbk:nzombie ~ ~-2.1 ~2
execute @p[tag=mes_sb_zmbie,scores={mes_splbk_ncrt=1}] ~ ~ ~ summon mes_splbk:nzombie ~ ~-2.1 ~-2
execute @p[tag=mes_sb_zmbie,scores={mes_splbk_ncrt=1}] ~ ~ ~ summon mes_splbk:nzombie ~2 ~-2.1 ~
execute @p[tag=mes_sb_zmbie,scores={mes_splbk_ncrt=1},tag=mes_sb_medium] ~ ~ ~ summon mes_splbk:nzombie ~-2 ~-2.1 ~
execute @p[tag=mes_sb_zmbie,scores={mes_splbk_ncrt=1},tag=mes_sb_big] ~ ~ ~ summon mes_splbk:nzombie ~-2 ~-2.1 ~
execute @p[tag=mes_sb_zmbie,scores={mes_splbk_ncrt=1},tag=mes_sb_big] ~ ~ ~ summon mes_splbk:nzombie ~2 ~-2.1 ~2
execute @p[tag=mes_sb_zmbie,scores={mes_splbk_ncrt=3}] ~ ~ ~ playanimation @e[type=mes_splbk:nzombie] animation.evoker.casting f 3
execute @p[tag=mes_sb_zmbie,scores={mes_splbk_ncrt=3..26}] ~ ~ ~ execute @e[type=mes_splbk:nzombie,r=10] ~ ~ ~ tp @s ~ ~0.1 ~ 
execute @p[tag=mes_sb_zmbie,scores={mes_splbk_ncrt=2..5}] ~ ~ ~ execute @e[type=mes_splbk:nzombie] ~ ~ ~ particle mes_splbk:ground ~ ~2.0 ~
execute @p[tag=mes_sb_zmbie,scores={mes_splbk_ncrt=258}] ~ ~ ~ execute @e[type=mes_splbk:nzombie] ~ ~ ~ particle mes_splbk:poof ~ ~ ~
execute @p[tag=mes_sb_zmbie,scores={mes_splbk_ncrt=259}] ~ ~ ~ execute @e[type=mes_splbk:nzombie] ~ ~ ~ tp @s ~ ~-1000 ~
execute @p[tag=mes_sb_zmbie,scores={mes_splbk_ncrt=262}] ~ ~ ~ kill @e[type=mes_splbk:nzombie] 
execute @p[tag=mes_sb_zmbie,scores={mes_splbk_ncrt=262}] ~ ~ ~ event entity @s mes_splbk:cooldown_off
tag @p[tag=mes_sb_zmbie,scores={mes_splbk_ncrt=263}] remove mes_sb_medium
tag @p[tag=mes_sb_zmbie,scores={mes_splbk_ncrt=263}] remove mes_sb_big
tag @p[tag=mes_sb_zmbie,scores={mes_splbk_ncrt=263}] add revnz
tag @p[tag=mes_sb_zmbie,scores={mes_splbk_ncrt=263}] remove mes_sb_zmbie
scoreboard players set @p[tag=revnz,scores={mes_splbk_ncrt=263}] mes_splbk_ncrt 0
tag @p remove revnz

scoreboard players add @p[r=1,tag=mes_sb_mnion] mes_splbk_mnt 1
execute @p[tag=mes_sb_mnion,scores={mes_splbk_mnt=16..49,book=2}] ~ ~ ~ event entity @s mes_splbk:cooldown_on 
execute @p[tag=mes_sb_mnion,scores={mes_splbk_mnt=1}] ~ ~ ~ playsound sw.music.fire_ability @a[r=20]
execute @p[tag=mes_sb_mnion,scores={mes_splbk_mnt=1}] ~ ~ ~ tag @e[type=mes_splbk:nskeleton,c=1,r=10] add minionanim
execute @p[tag=mes_sb_mnion,scores={mes_splbk_mnt=1}] ~ ~ ~ tag @e[type=mes_splbk:nzombie,c=1,r=15] add minionanim
execute @p[tag=mes_sb_mnion,scores={mes_splbk_mnt=1}] ~ ~ ~ execute @e[type=mes_splbk:nzombie,c=1,r=15] ~ ~ ~ tag @p[tag=mes_sb_mnion] add yes
execute @p[tag=mes_sb_mnion,scores={mes_splbk_mnt=1}] ~ ~ ~ execute @e[type=mes_splbk:nskeleton,c=1,r=15] ~ ~ ~ tag @p[tag=mes_sb_mnion] add yes
execute @p[tag=mes_sb_mnion,scores={mes_splbk_mnt=1}] ~ ~ ~ titleraw @p[tag=mes_sb_mnion,tag=!yes] actionbar { "rawtext" : [ { "translate" : "nominion.text" } ] }
execute @p[tag=mes_sb_mnion,scores={mes_splbk_mnt=1}] ~ ~ ~ scoreboard players set @p[tag=mes_sb_mnion,tag=!yes] mes_splbk_mnt 50
execute @p[tag=mes_sb_mnion,scores={mes_splbk_mnt=1..}] ~ ~ ~ execute @e[tag=minionanim] ~ ~ ~ particle mes_splbk:necro_poof ~ ~1.8 ~
execute @p[tag=mes_sb_mnion,scores={mes_splbk_mnt=1}] ~ ~ ~ playanimation @e[tag=minionanim] animation.mes_splbk.necro.boom f 100
execute @p[tag=mes_sb_mnion,scores={mes_splbk_mnt=49}] ~ ~ ~ execute @e[tag=minionanim] ~ ~ ~ effect @e[r=15,family=mob] fatal_poison 5 255 true
execute @p[tag=mes_sb_mnion,scores={mes_splbk_mnt=49}] ~ ~ ~ execute @e[tag=minionanim] ~ ~ ~ summon mes_splbk:instanttnt ~ ~2.1 ~
execute @p[tag=mes_sb_mnion,scores={mes_splbk_mnt=50}] ~ ~ ~ execute @e[tag=minionanim] ~ ~ ~ kill @s
execute @p[tag=mes_sb_mnion,scores={mes_splbk_mnt=50}] ~ ~ ~ event entity @s mes_splbk:cooldown_off
execute @p[tag=mes_sb_mnion,scores={mes_splbk_mnt=5}] ~ ~ ~ tag @a[tag=mes_sb_mnion] remove yes
tag @p[tag=mes_sb_mnion,scores={mes_splbk_mnt=50}] remove mes_sb_mnion
scoreboard players set @p[r=1,scores={mes_splbk_mnt=50}] mes_splbk_mnt 0

scoreboard players add @p[r=1,tag=mes_sb_totem] mes_splbk_ttmt 1
execute @p[tag=mes_sb_totem,scores={mes_splbk_ttmt=1}] ~ ~ ~ replaceitem entity @e[r=15,family=mob] slot.weapon.offhand 0 totem_of_undying
execute @p[tag=mes_sb_totem,scores={mes_splbk_ttmt=1}] ~ ~ ~ playsound random.totem @a[r=15]
execute @p[tag=mes_sb_totem,scores={mes_splbk_ttmt=1}] ~ ~ ~ particle minecraft:totem_particle ~ ~ ~
execute @p[tag=mes_sb_totem,scores={mes_splbk_ttmt=1}] ~ ~ ~ replaceitem entity @s slot.weapon.offhand 0 totem_of_undying
execute @p[tag=mes_sb_totem,scores={mes_splbk_ttmt=1}] ~ ~ ~ replaceitem entity @e[r=15,family=necro] slot.weapon.offhand 0 totem_of_undying
execute @p[tag=mes_sb_totem,scores={mes_splbk_ttmt=1..20}] ~ ~ ~ execute @e[r=15,family=mob,hasitem={location=slot.weapon.offhand,slot=0,item=totem_of_undying}] ~ ~ ~ particle minecraft:totem_particle
execute @p[tag=mes_sb_totem,scores={mes_splbk_ttmt=1..20}] ~ ~ ~ execute @e[r=15,family=necro,hasitem={location=slot.weapon.offhand,slot=0,item=totem_of_undying}] ~ ~ ~ particle minecraft:totem_particle
tag @p[tag=mes_sb_totem,scores={mes_splbk_ttmt=40}] remove mes_sb_totem
scoreboard players set @p[r=1,scores={mes_splbk_ttmt=40}] mes_splbk_ttmt 0


scoreboard players add @p[r=1,tag=mes_sb_drk] mes_splbk_drkt 1
execute @p[tag=mes_sb_drk,scores={mes_splbk_drkt=1}] ~ ~ ~ tag @s add mes_sb_drksh
execute @p[tag=mes_sb_drk,scores={mes_splbk_drkt=1}] ~ ~ ~ effect @e[r=5] darkness 2 255 true
tag @p[tag=mes_sb_drk,scores={mes_splbk_drkt=40}] remove mes_sb_drk
scoreboard players set @p[r=1,scores={mes_splbk_drkt=40}] mes_splbk_drkt 0

scoreboard players add @e[type=mes_splbk:dark_shoot] mes_splbk_drkt 1
execute @e[type=mes_splbk:dark_shoot] ~ ~ ~ particle mes_splbk:darkshoot ~ ~ ~
execute @e[type=mes_splbk:dark_shoot,scores={mes_splbk_drkt=50}] ~ ~ ~ playsound random.explode @a[r=30]
execute @e[type=mes_splbk:dark_shoot,scores={mes_splbk_drkt=40..50}] ~ ~ ~ particle mes_splbk:dark ~ ~ ~
execute @e[type=mes_splbk:dark_shoot,scores={mes_splbk_drkt=50}] ~ ~ ~ tag @e[r=8,type=!player,family=mob,family=!inac,type=!mes_splbk:dark_shoot] add darkexplosion
execute @e[type=mes_splbk:dark_shoot,scores={mes_splbk_drkt=50}] ~ ~ ~ effect @e[r=8,type=!player,family=mob,family=!inac,type=!mes_splbk:dark_shoot] levitation 1 25 true
execute @e[type=mes_splbk:dark_shoot,scores={mes_splbk_drkt=50}] ~ ~ ~ effect @e[r=8,type=!player,family=mob,family=!inac,type=!mes_splbk:dark_shoot] fatal_poison 1 3 true
execute @e[type=mes_splbk:dark_shoot,scores={mes_splbk_drkt=62}] ~ ~ ~ execute @e[tag=darkexplosion] ~ ~ ~ summon mes_splbk:instanttnt
execute @e[type=mes_splbk:dark_shoot,scores={mes_splbk_drkt=62}] ~ ~ ~ execute @e[tag=darkexplosion] ~ ~ ~ particle mes_splbk:dark_explode ~ ~ ~
execute @e[type=mes_splbk:dark_shoot,scores={mes_splbk_drkt=62}] ~ ~ ~ tag @e[tag=darkexplosion] remove darkexplosion
execute @e[type=mes_splbk:dark_shoot,scores={mes_splbk_drkt=63}] ~ ~ ~ kill @s

scoreboard players add @p[r=1,tag=mes_sb_wolf] mes_splbk_wlft 1
execute @p[tag=mes_sb_wolf,scores={mes_splbk_wlft=16..200,book=0}] ~ ~ ~ event entity @s mes_splbk:cooldown_on
execute @p[tag=mes_sb_wolf,scores={mes_splbk_wlft=1}] ~ ~ ~ playsound sw.music.necro_ability @a[r=15]
execute @p[tag=mes_sb_wolf,scores={mes_splbk_wlft=1}] ~ ~ ~ summon wolf ~ ~ ~1
execute @p[tag=mes_sb_wolf,scores={mes_splbk_wlft=1}] ~ ~ ~ summon wolf ~ ~ ~-1
execute @p[tag=mes_sb_wolf,scores={mes_splbk_wlft=1}] ~ ~ ~ effect @e[type=wolf,r=3] strength 10 2 true
execute @p[tag=mes_sb_wolf,scores={mes_splbk_wlft=1}] ~ ~ ~ effect @e[type=wolf,r=3] resistance 10 10 true
execute @p[tag=mes_sb_wolf,scores={mes_splbk_wlft=198}] ~ ~ ~ execute @e[type=wolf] ~ ~ ~ particle mes_splbk:poof ~ ~ ~
execute @p[tag=mes_sb_wolf,scores={mes_splbk_wlft=199}] ~ ~ ~ execute @e[type=wolf] ~ ~ ~ tp @s ~ ~-1000 ~
execute @p[tag=mes_sb_wolf,scores={mes_splbk_wlft=202}] ~ ~ ~ kill @e[type=wolf] 
execute @p[tag=mes_sb_wolf,scores={mes_splbk_wlft=202}] ~ ~ ~ event entity @s mes_splbk:cooldown_off
tag @p[tag=mes_sb_wolf,scores={mes_splbk_wlft=202}] remove mes_sb_wolf
scoreboard players set @p[r=1,scores={mes_splbk_wlft=202}] mes_splbk_wlft 0


scoreboard players add @p[r=1,tag=mes_sb_spider] mes_splbk_drdt 1
execute @p[tag=mes_sb_spider,scores={mes_splbk_drdt=16..600,book=1}] ~ ~ ~ event entity @s mes_splbk:cooldown_on
execute @p[tag=mes_sb_spider,scores={mes_splbk_drdt=1}] ~ ~ ~ titleraw @p[tag=mes_sb_spider] actionbar { "rawtext" : [ { "translate" : "sneakdruid.text" } ] }
execute @p[tag=mes_sb_spider,scores={mes_splbk_drdt=1}] ~ ~ ~ effect @s invisibility 30 255 true
execute @p[tag=mes_sb_spider,scores={mes_splbk_drdt=5..595}] ~ ~ ~ execute @e[tag=spiderdruid,rm=1.5] ~ ~ ~ scoreboard players set @p[tag=mes_sb_spider] mes_splbk_drdt 597
execute @p[tag=mes_sb_spider,scores={mes_splbk_drdt=1}] ~ ~ ~ playsound sw.music.sky_ability @a[r=10]
execute @p[tag=mes_sb_spider,scores={mes_splbk_drdt=1}] ~ ~ ~ effect @p resistance 30 255 true
execute @p[tag=mes_sb_spider,scores={mes_splbk_drdt=1}] ~ ~ ~ camera @p set minecraft:third_person
execute @p[tag=mes_sb_spider,scores={mes_splbk_drdt=1}] ~ ~ ~ event entity @s mes_splbk:masked
execute @p[tag=mes_sb_spider,scores={mes_splbk_drdt=2}] ~ ~ ~ particle mes_splbk:poof
execute @p[tag=mes_sb_spider,scores={mes_splbk_drdt=1}] ~ ~ ~ summon mes_splbk:nrabbit
execute @p[tag=mes_sb_spider,scores={mes_splbk_drdt=2}] ~ ~ ~ ride @p[tag=mes_sb_spider] start_riding @e[tag=spiderdruid]
execute @p[tag=mes_sb_spider,scores={mes_splbk_drdt=1}] ~ ~ ~ tag @e[type=mes_splbk:nrabbit,r=1,c=1] add spiderdruid
execute @p[tag=mes_sb_spider,scores={mes_splbk_drdt=1}] ~ ~ ~ effect @e[type=mes_splbk:nrabbit,r=1] resistance 30 255 true
execute @p[tag=mes_sb_spider,scores={mes_splbk_drdt=597}] ~ ~ ~ particle mes_splbk:poof
execute @p[tag=mes_sb_spider,scores={mes_splbk_drdt=597}] ~ ~ ~ event entity @s mes_splbk:masked_off
execute @p[tag=mes_sb_spider,scores={mes_splbk_drdt=597}] ~ ~ ~ effect @p invisibility 0
execute @p[tag=mes_sb_spider,scores={mes_splbk_drdt=597}] ~ ~ ~ effect @p resistance 0
execute @p[tag=mes_sb_spider,scores={mes_splbk_drdt=597}] ~ ~ ~ camera @p clear 
execute @p[tag=mes_sb_spider,scores={mes_splbk_drdt=597}] ~ ~ ~ ride @p[tag=mes_sb_spider] stop_riding
execute @p[tag=mes_sb_spider,scores={mes_splbk_drdt=598}] ~ ~ ~ tp @e[tag=spiderdruid] ~ ~-100 ~
execute @p[tag=mes_sb_spider,scores={mes_splbk_drdt=603}] ~ ~ ~ kill @e[tag=spiderdruid]
execute @p[tag=mes_sb_spider,scores={mes_splbk_drdt=603}] ~ ~ ~ event entity @s mes_splbk:cooldown_off
tag @p[tag=mes_sb_spider,scores={mes_splbk_drdt=603}] add revds
tag @p[tag=mes_sb_spider,scores={mes_splbk_drdt=603}] remove mes_sb_spider
scoreboard players set @p[tag=revds,scores={mes_splbk_drdt=603}] mes_splbk_drdt 0
tag @p remove revds

scoreboard players add @p[r=1,tag=mes_sb_bat] mes_splbk_drdt 1
execute @p[tag=mes_sb_bat,scores={mes_splbk_drdt=16..600,book=2}] ~ ~ ~ event entity @s mes_splbk:cooldown_on
execute @p[tag=mes_sb_bat,scores={mes_splbk_drdt=1}] ~ ~ ~ titleraw @p[tag=mes_sb_bat] actionbar { "rawtext" : [ { "translate" : "sneakdruid.text" } ] }
execute @p[tag=mes_sb_bat,scores={mes_splbk_drdt=1}] ~ ~ ~ effect @s invisibility 30 255 true
execute @p[tag=mes_sb_bat,scores={mes_splbk_drdt=1}] ~ ~ ~ effect @p resistance 30 255 true
execute @p[tag=mes_sb_bat,scores={mes_splbk_drdt=1}] ~ ~ ~ playsound sw.music.sky_ability @a[r=10]
execute @p[tag=mes_sb_bat,scores={mes_splbk_drdt=1}] ~ ~ ~ camera @p set minecraft:third_person
execute @p[tag=mes_sb_bat,scores={mes_splbk_drdt=1}] ~ ~ ~ event entity @s mes_splbk:masked
execute @p[tag=mes_sb_bat,scores={mes_splbk_drdt=2}] ~ ~ ~ particle mes_splbk:poof
execute @p[tag=mes_sb_bat,scores={mes_splbk_drdt=1}] ~ ~ ~ summon bat
execute @p[tag=mes_sb_bat,scores={mes_splbk_drdt=1}] ~ ~ ~ tag @e[type=bat,r=1,c=1] add batdruid
execute @p[tag=mes_sb_bat,scores={mes_splbk_drdt=1}] ~ ~ ~ effect @e[type=bat,r=1] resistance 30 255 true
execute @p[tag=mes_sb_bat,scores={mes_splbk_drdt=1..596}] ~ ~ ~ tp @e[tag=batdruid] ~ ~1.3 ~ facing ^ ^ ^10
execute @p[tag=mes_sb_bat,scores={mes_splbk_drdt=29..596},rx=-35,rxm=-90] ~ ~ ~ effect @s levitation 1 9 true
execute @p[tag=mes_sb_bat,scores={mes_splbk_drdt=29..596},rx=5,rxm=-10] ~ ~ ~ effect @s levitation 1 2 true
execute @p[tag=mes_sb_bat,scores={mes_splbk_drdt=29..596},rx=-10,rxm=-35] ~ ~ ~ effect @s levitation 1 5 true
execute @p[tag=mes_sb_bat,scores={mes_splbk_drdt=29..596},rx=90,rxm=5] ~ ~ ~ effect @s slow_falling 1 0 true
execute @p[tag=mes_sb_bat,scores={mes_splbk_drdt=597}] ~ ~ ~ particle mes_splbk:poof
execute @p[tag=mes_sb_bat,scores={mes_splbk_drdt=597}] ~ ~ ~ effect @s slow_falling 5 1 true
execute @p[tag=mes_sb_bat,scores={mes_splbk_drdt=597}] ~ ~ ~ event entity @s mes_splbk:masked_off
execute @p[tag=mes_sb_bat,scores={mes_splbk_drdt=597}] ~ ~ ~ effect @p invisibility 0
execute @p[tag=mes_sb_bat,scores={mes_splbk_drdt=597}] ~ ~ ~ effect @p resistance 0
execute @p[tag=mes_sb_bat,scores={mes_splbk_drdt=597}] ~ ~ ~ effect @p levitation 0
execute @p[tag=mes_sb_bat,scores={mes_splbk_drdt=597}] ~ ~ ~ camera @p clear
execute @p[tag=mes_sb_bat,scores={mes_splbk_drdt=598}] ~ ~ ~ tp @e[tag=batdruid] ~ ~-100 ~
execute @p[tag=mes_sb_bat,scores={mes_splbk_drdt=602}] ~ ~ ~ kill @e[tag=batdruid]
execute @p[tag=mes_sb_bat,scores={mes_splbk_drdt=602}] ~ ~ ~ event entity @s mes_splbk:cooldown_off
tag @p[tag=mes_sb_bat,scores={mes_splbk_drdt=602}] add revdb
tag @p[tag=mes_sb_bat,scores={mes_splbk_drdt=602}] remove mes_sb_bat
scoreboard players set @p[tag=revdb,scores={mes_splbk_drdt=602}] mes_splbk_drdt 0
tag @p remove revdb

scoreboard players add @p[r=1,tag=mes_sb_seed] mes_splbk_seedt 1
execute @p[tag=mes_sb_seed,scores={mes_splbk_seedt=16..119,book=4}] ~ ~ ~ event entity @s mes_splbk:cooldown_on
execute @p[tag=mes_sb_seed,scores={mes_splbk_seedt=10}] ~ ~ ~ playsound dig.azalea_leaves @a[r=15]
execute @p[tag=mes_sb_seed,scores={mes_splbk_seedt=1}] ~ ~ ~ summon mes_splbk:seed ^ ^1 ^2
execute @p[tag=mes_sb_seed,scores={mes_splbk_seedt=2}] ~ ~ ~ playanimation @e[type=mes_splbk:seed] animation.mes_splbk.seed.start f 100
execute @p[tag=mes_sb_seed,scores={mes_splbk_seedt=1..}] ~ ~ ~ execute @e[type=mes_splbk:seed] ~ ~ ~ particle mes_splbk:seed ~ ~0.5 ~
execute @p[tag=mes_sb_seed,scores={mes_splbk_seedt=1..}] ~ ~ ~ execute @e[type=mes_splbk:seed] ~ ~ ~ effect @a[r=5] regeneration 2 10 true
execute @p[tag=mes_sb_seed,scores={mes_splbk_seedt=1..}] ~ ~ ~ execute @e[type=mes_splbk:seed] ~ ~ ~ effect @e[r=5,family=monster] fatal_poison 2 255 true
execute @p[tag=mes_sb_seed,scores={mes_splbk_seedt=118}] ~ ~ ~ execute @e[type=mes_splbk:seed] ~ ~ ~ particle mes_splbk:vines_death ~ ~1 ~ 
execute @p[tag=mes_sb_seed,scores={mes_splbk_seedt=118}] ~ ~ ~ execute @e[type=mes_splbk:seed] ~ ~ ~ particle mes_splbk:vines_death ~ ~2 ~
execute @p[tag=mes_sb_seed,scores={mes_splbk_seedt=118}] ~ ~ ~ playsound block.sweet_berry_bush.break @a[r=15]
execute @p[tag=mes_sb_seed,scores={mes_splbk_seedt=118}] ~ ~ ~ tp @e[type=mes_splbk:seed] ~ ~-100 ~
execute @p[tag=mes_sb_seed,scores={mes_splbk_seedt=120}] ~ ~ ~ kill @e[type=mes_splbk:seed]
execute @p[tag=mes_sb_seed,scores={mes_splbk_seedt=120}] ~ ~ ~ event entity @s mes_splbk:cooldown_off
tag @p[tag=mes_sb_seed,scores={mes_splbk_seedt=120}] remove mes_sb_seed
scoreboard players set @p[r=1,scores={mes_splbk_seedt=120}] mes_splbk_seedt 0

scoreboard players add @p[r=1,tag=mes_sb_vines] mes_splbk_vnst 1
execute @p[tag=mes_sb_vines,scores={mes_splbk_vnst=16..109,book=3}] ~ ~ ~ event entity @s mes_splbk:cooldown_on
execute @p[tag=mes_sb_vines,scores={mes_splbk_vnst=1}] ~ ~ ~ execute @e[r=15,family=mob,tag=!ocelotdruid,tag=!spiderdruid,tag=!batdruid,family=!inac] ~ ~ ~ tag @p[tag=mes_sb_vines] add yes
execute @p[tag=mes_sb_vines,scores={mes_splbk_vnst=1}] ~ ~ ~ titleraw @p[tag=mes_sb_vines,tag=!yes] actionbar { "rawtext" : [ { "translate" : "noone.text" } ] }
execute @p[tag=mes_sb_vines,scores={mes_splbk_vnst=1}] ~ ~ ~ scoreboard players set @p[tag=mes_sb_vines,tag=!yes] mes_splbk_vnst 109
execute @p[tag=mes_sb_vines,scores={mes_splbk_vnst=1}] ~ ~ ~ effect @e[r=15,family=mob,tag=!ocelotdruid,tag=!spiderdruid,tag=!batdruid,family=!inac] slowness 3 255 true
execute @p[tag=mes_sb_vines,scores={mes_splbk_vnst=1}] ~ ~ ~ playsound dig.azalea_leaves @a[r=15]
execute @p[tag=mes_sb_vines,scores={mes_splbk_vnst=1}] ~ ~ ~ execute @e[r=15,family=mob,tag=!ocelotdruid,tag=!spiderdruid,tag=!batdruid,family=!inac] ~ ~ ~ summon mes_splbk:vines
execute @p[tag=mes_sb_vines,scores={mes_splbk_vnst=3}] ~ ~ ~ playanimation @e[type=mes_splbk:vines] animation.mes_splbk.vines.start f 100
execute @p[tag=mes_sb_vines,scores={mes_splbk_vnst=1..}] ~ ~ ~ execute @e[type=mes_splbk:vines] ~ ~ ~ particle mes_splbk:vines ~ ~1.2 ~
execute @p[tag=mes_sb_vines,scores={mes_splbk_vnst=15}] ~ ~ ~ execute @e[type=mes_splbk:vines] ~ ~ ~ effect @e[r=3,family=mob] slowness 5 10 true
execute @p[tag=mes_sb_vines,scores={mes_splbk_vnst=15}] ~ ~ ~ execute @e[type=mes_splbk:vines] ~ ~ ~ effect @e[r=3,family=mob] fatal_poison 5 255 true
execute @p[tag=mes_sb_vines,scores={mes_splbk_vnst=108}] ~ ~ ~ execute @e[type=mes_splbk:vines] ~ ~ ~ particle mes_splbk:vines_death ~ ~1 ~
execute @p[tag=mes_sb_vines,scores={mes_splbk_vnst=108}] ~ ~ ~ playsound block.sweet_berry_bush.break @a[r=15]
execute @p[tag=mes_sb_vines,scores={mes_splbk_vnst=108}] ~ ~ ~ tp @e[type=mes_splbk:vines] ~ ~-100 ~
execute @p[tag=mes_sb_vines,scores={mes_splbk_vnst=110}] ~ ~ ~ kill @e[type=mes_splbk:vines]
execute @p[tag=mes_sb_vines,scores={mes_splbk_vnst=5}] ~ ~ ~ tag @p remove yes
execute @p[tag=mes_sb_vines,scores={mes_splbk_vnst=110}] ~ ~ ~ event entity @s mes_splbk:cooldown_off
tag @p[tag=mes_sb_vines,scores={mes_splbk_vnst=110}] remove mes_sb_vines
scoreboard players set @p[r=1,scores={mes_splbk_vnst=110}] mes_splbk_vnst 0

scoreboard players add @p[r=1,tag=mes_sb_tballs] mes_splbk_tblst 1
execute @p[tag=mes_sb_tballs,scores={mes_splbk_tblst=16..129,book=0}] ~ ~ ~ event entity @s mes_splbk:cooldown_on
execute @p[tag=mes_sb_tballs,scores={mes_splbk_tblst=1}] ~ ~ ~ summon mes_splbk:tballs_shoot ^ ^3.7 ^2
execute @p[tag=mes_sb_tballs,scores={mes_splbk_tblst=1}] ~ ~ ~ summon mes_splbk:tballs_shoot ^1.2 ^3 ^2
execute @p[tag=mes_sb_tballs,scores={mes_splbk_tblst=1}] ~ ~ ~ summon mes_splbk:tballs_shoot ^-1.2 ^3 ^2
execute @p[tag=mes_sb_tballs,scores={mes_splbk_tblst=1}] ~ ~ ~ titleraw @p[tag=mes_sb_tballs] actionbar { "rawtext" : [ { "translate" : "tballs.punch" } ] }
execute @p[tag=mes_sb_tballs,scores={mes_splbk_tblst=1}] ~ ~ ~ playsound mob.wither.shoot @a[r=10]
execute @p[tag=mes_sb_tballs,scores={mes_splbk_tblst=20..}] ~ ~ ~ execute @e[family=mob,family=!inac] ~ ~ ~ tp @e[type=mes_splbk:tballs_shoot,r=3] @s
execute @p[tag=mes_sb_tballs,scores={mes_splbk_tblst=130}] ~ ~ ~ kill @e[type=mes_splbk:tballs_shoot]
execute @p[tag=mes_sb_tballs,scores={mes_splbk_tblst=130}] ~ ~ ~ event entity @s mes_splbk:cooldown_off
tag @p[tag=mes_sb_tballs,scores={mes_splbk_tblst=130}] remove mes_sb_tballs
scoreboard players set @p[r=1,scores={mes_splbk_tblst=130}] mes_splbk_tblst 0

execute @e[type=mes_splbk:tballs_shoot] ~ ~ ~ particle mes_splbk:tballs ~ ~ ~ 

scoreboard players add @p[r=1,tag=mes_sb_blink] mes_splbk_blkt 1
execute @p[tag=mes_sb_blink,scores={mes_splbk_blkt=1}] ~ ~ ~ playsound sw.music.tp_ability @a[r=20]
execute @p[tag=mes_sb_blink,scores={mes_splbk_blkt=1}] ~ ~ ~ effect @s darkness 2 255 true
execute @p[tag=mes_sb_blink,scores={mes_splbk_blkt=10}] ~ ~ ~ particle mes_splbk:necro_poof
execute @p[tag=mes_sb_blink,scores={mes_splbk_blkt=10}] ~ ~ ~ detect ^ ^0.2 ^1 air 0 tp @s ^ ^0.1 ^1 facing ^ ^ ^10
execute @p[tag=mes_sb_blink,scores={mes_splbk_blkt=10}] ~ ~ ~ detect ^ ^0.2 ^1 air 0 tp @s ^ ^0.1 ^1 facing ^ ^ ^10
execute @p[tag=mes_sb_blink,scores={mes_splbk_blkt=10}] ~ ~ ~ detect ^ ^0.2 ^1 air 0 tp @s ^ ^0.1 ^1 facing ^ ^ ^10
execute @p[tag=mes_sb_blink,scores={mes_splbk_blkt=10}] ~ ~ ~ detect ^ ^0.2 ^1 air 0 tp @s ^ ^0.1 ^1 facing ^ ^ ^10
execute @p[tag=mes_sb_blink,scores={mes_splbk_blkt=10}] ~ ~ ~ detect ^ ^0.2 ^1 air 0 tp @s ^ ^0.1 ^1 facing ^ ^ ^10
execute @p[tag=mes_sb_blink,scores={mes_splbk_blkt=10}] ~ ~ ~ detect ^ ^0.2 ^1 air 0 tp @s ^ ^0.1 ^1 facing ^ ^ ^10
execute @p[tag=mes_sb_blink,scores={mes_splbk_blkt=10}] ~ ~ ~ detect ^ ^0.2 ^1 air 0 tp @s ^ ^0.1 ^1 facing ^ ^ ^10
execute @p[tag=mes_sb_blink,scores={mes_splbk_blkt=10}] ~ ~ ~ detect ^ ^0.2 ^1 air 0 tp @s ^ ^0.1 ^1 facing ^ ^ ^10
execute @p[tag=mes_sb_blink,scores={mes_splbk_blkt=10}] ~ ~ ~ detect ^ ^0.2 ^1 air 0 tp @s ^ ^0.1 ^1 facing ^ ^ ^10
execute @p[tag=mes_sb_blink,scores={mes_splbk_blkt=10}] ~ ~ ~ detect ^ ^0.2 ^1 air 0 tp @s ^ ^0.1 ^1 facing ^ ^ ^10
execute @p[tag=mes_sb_blink,scores={mes_splbk_blkt=11}] ~ ~ ~ particle mes_splbk:necro_poof
execute @p[tag=mes_sb_blink,scores={mes_splbk_blkt=11}] ~ ~ ~ effect @s darkness 0
tag @p[tag=mes_sb_blink,scores={mes_splbk_blkt=40}] remove mes_sb_blink
scoreboard players set @p[r=1,scores={mes_splbk_blkt=40}] mes_splbk_blkt 0



scoreboard players add @p[r=1,tag=mes_sb_plmrph] mes_splbk_plmrt 1
execute @p[tag=mes_sb_plmrph,scores={mes_splbk_plmrt=16..149,book=2}] ~ ~ ~ event entity @s mes_splbk:cooldown_on
execute @p[tag=mes_sb_plmrph,scores={mes_splbk_plmrt=1}] ~ ~ ~ playsound mob.chicken.say @a[r=15]
execute @p[tag=mes_sb_plmrph,scores={mes_splbk_plmrt=1}] ~ ~ ~ particle mes_splbk:polymorph_launch ~ ~ ~
execute @p[tag=mes_sb_plmrph,scores={mes_splbk_plmrt=1}] ~ ~ ~ execute @e[family=!inac,family=!npc,r=8,type=!wither,type=!ender_dragon,family=mob,type=!chicken] ~ ~ ~ particle mes_splbk:necro_poof ~ ~ ~
execute @p[tag=mes_sb_plmrph,scores={mes_splbk_plmrt=1}] ~ ~ ~ execute @e[family=!inac,family=!npc,r=8,type=!wither,type=!ender_dragon,family=mob,type=!chicken] ~ ~ ~ tag @p[tag=mes_sb_plmrph] add yes
execute @p[tag=mes_sb_plmrph,scores={mes_splbk_plmrt=1}] ~ ~ ~ titleraw @p[tag=mes_sb_plmrph,tag=!yes] actionbar { "rawtext" : [ { "translate" : "noone.text" } ] }
execute @p[tag=mes_sb_plmrph,scores={mes_splbk_plmrt=1}] ~ ~ ~ scoreboard players set @p[tag=mes_sb_plmrph,tag=!yes] mes_splbk_plmrt 4
execute @p[tag=mes_sb_plmrph,scores={mes_splbk_plmrt=4}] ~ ~ ~ execute @e[family=!inac,family=!npc,r=8,type=!wither,type=!ender_dragon,family=mob,type=!chicken] ~ ~ ~ summon chicken
execute @p[tag=mes_sb_plmrph,scores={mes_splbk_plmrt=4}] ~ ~ ~ execute @e[family=!inac,family=!npc,r=8,type=!wither,type=!ender_dragon,family=mob,type=!chicken] ~ ~ ~ tp @s ~ ~-1000 ~
execute @p[tag=mes_sb_plmrph,scores={mes_splbk_plmrt=6}] ~ ~ ~ tag @a[tag=mes_sb_plmrph] remove yes
execute @p[tag=mes_sb_plmrph,scores={mes_splbk_plmrt=150}] ~ ~ ~ event entity @s mes_splbk:cooldown_off
tag @p[tag=mes_sb_plmrph,scores={mes_splbk_plmrt=150}] remove mes_sb_plmrph
scoreboard players set @p[r=1,scores={mes_splbk_plmrt=150}] mes_splbk_plmrt 0


scoreboard players add @p[r=1,tag=mes_sb_arcexpl] mes_splbk_arcext 1
execute @p[tag=mes_sb_arcexpl,scores={mes_splbk_arcext=16..200,book=3}] ~ ~ ~ event entity @s mes_splbk:cooldown_on
execute @p[tag=mes_sb_arcexpl,scores={mes_splbk_arcext=1}] ~ ~ ~ playsound liquid.mes_sb_lava @a[r=20]
execute @p[tag=mes_sb_arcexpl,scores={mes_splbk_arcext=1..60}] ~ ~ ~ particle mes_splbk:arcaneexpl_launch ~ ~ ~
execute @p[tag=mes_sb_arcexpl,scores={mes_splbk_arcext=1}] ~ ~ ~ playanimation @s animation.evoker.casting f 3
execute @p[tag=mes_sb_arcexpl,scores={mes_splbk_arcext=61}] ~ ~ ~ particle mes_splbk:arcaneexpl_explode
execute @p[tag=mes_sb_arcexpl,scores={mes_splbk_arcext=61}] ~ ~ ~ particle mes_splbk:arcane_fire
execute @p[tag=mes_sb_arcexpl,scores={mes_splbk_arcext=61}] ~ ~ ~ playsound cauldron.explode @a[r=15]
execute @p[tag=mes_sb_arcexpl,scores={mes_splbk_arcext=63}] ~ ~ ~ effect @e[r=15,family=!inac,family=mob] instant_damage 1 2 true
execute @p[tag=mes_sb_arcexpl,scores={mes_splbk_arcext=63}] ~ ~ ~ effect @e[r=15,family=!inac,family=mob] fatal_poison 3 255 true
execute @p[tag=mes_sb_arcexpl,scores={mes_splbk_arcext=63..120}] ~ ~ ~ execute @e[family=!inac,family=mob,r=15] ~ ~ ~ particle mes_splbk:arcane_fire_ambient ~ ~1 ~
execute @p[tag=mes_sb_arcexpl,scores={mes_splbk_arcext=200}] ~ ~ ~ event entity @s mes_splbk:cooldown_off
tag @p[tag=mes_sb_arcexpl,scores={mes_splbk_arcext=200}] remove mes_sb_arcexpl
scoreboard players set @p[r=1,scores={mes_splbk_arcext=200}] mes_splbk_arcext 0


scoreboard players add @p[r=1,tag=mes_sb_arcward] mes_splbk_wrdt 1
execute @p[tag=mes_sb_arcward,scores={mes_splbk_wrdt=16..99,book=4}] ~ ~ ~ event entity @s mes_splbk:cooldown_on
execute @p[tag=mes_sb_arcward,scores={mes_splbk_wrdt=1}] ~ ~ ~ playsound beacon.power @a[r=8] ~ ~ ~ 0.65
execute @p[tag=mes_sb_arcward,scores={mes_splbk_wrdt=1}] ~ ~ ~ tag @s add mes_sb_wardsh
execute @p[tag=mes_sb_arcward,scores={mes_splbk_wrdt=9..98}] ~ ~ ~ execute @e[type=mes_splbk:ward] ~ ~ ~ particle mes_splbk:ward ~ ~ ~
execute @p[tag=mes_sb_arcward,scores={mes_splbk_wrdt=9..88}] ~ ~ ~ execute @e[type=mes_splbk:ward] ~ ~ ~ effect @e[family=mob,family=!inac,r=3] slowness 1 255 true
execute @p[tag=mes_sb_arcward,scores={mes_splbk_wrdt=2..98}] ~ ~ ~ execute @e[type=mes_splbk:ward] ~ ~ ~ particle mes_splbk:ward_explode ~ ~ ~
execute @p[tag=mes_sb_arcward,scores={mes_splbk_wrdt=85}] ~ ~ ~ playsound beacon.activate @a[r=8] ~ ~ ~ 0.65
execute @p[tag=mes_sb_arcward,scores={mes_splbk_wrdt=100}] ~ ~ ~ kill @e[type=mes_splbk:ward]
execute @p[tag=mes_sb_arcward,scores={mes_splbk_wrdt=100}] ~ ~ ~ event entity @s mes_splbk:cooldown_off
tag @p[tag=mes_sb_arcward,scores={mes_splbk_wrdt=100}] remove mes_sb_arcward
scoreboard players set @p[r=1,scores={mes_splbk_wrdt=100}] mes_splbk_wrdt 0


scoreboard players add @p[r=1,tag=mes_sb_zephyr] mes_splbk_airt 1
execute @p[tag=mes_sb_zephyr,scores={mes_splbk_airt=16..249,book=0}] ~ ~ ~ event entity @s mes_splbk:cooldown_on
execute @p[tag=mes_sb_zephyr,scores={mes_splbk_airt=1}] ~ ~ ~ effect @p resistance 16 255 true
execute @p[tag=mes_sb_zephyr,scores={mes_splbk_airt=1}] ~ ~ ~ playsound hit.mes_sb_big_dripleaf @a[r=5]
execute @p[tag=mes_sb_zephyr,scores={mes_splbk_airt=1}] ~ ~ ~ titleraw @p[tag=mes_sb_zephyr] actionbar { "rawtext" : [ { "translate" : "zephyr.jump" } ] }
execute @p[tag=mes_sb_zephyr,scores={mes_splbk_airt=250}] ~ ~ ~ event entity @s mes_splbk:cooldown_off
tag @p[tag=mes_sb_zephyr,scores={mes_splbk_airt=250}] add revaz
tag @p[tag=mes_sb_zephyr,scores={mes_splbk_airt=250}] remove mes_sb_zephyr
scoreboard players set @p[tag=revaz,scores={mes_splbk_airt=250}] mes_splbk_airt 0
tag @p remove revaz

scoreboard players add @p[tag=mes_sb_rmvjp] mes_splbk_stnbt 1
effect @a[scores={mes_splbk_stnbt=5..},tag=mes_sb_rmvjp] levitation 0
scoreboard players set @a[tag=mes_sb_rmvjp,scores={mes_splbk_stnbt=5..}] mes_splbk_stnbt 0
tag @a[tag=mes_sb_rmvjp,scores={mes_splbk_stnbt=0}] remove mes_sb_rmvjp



scoreboard players add @p[r=1,tag=mes_sb_lttng] mes_splbk_lightt 1
execute @p[tag=mes_sb_lttng,scores={mes_splbk_lightt=16..79,book=4}] ~ ~ ~ event entity @s mes_splbk:cooldown_on
execute @p[tag=mes_sb_lttng,scores={mes_splbk_lightt=1}] ~ ~ ~ playsound sw.music.lightning_ability @a[r=20]
execute @p[tag=mes_sb_lttng,scores={mes_splbk_lightt=1}] ~ ~ ~ tag @s add mes_sb_td
execute @p[tag=mes_sb_lttng,scores={mes_splbk_lightt=1}] ~ ~ ~ particle mes_splbk:lightning_launch ^ ^1.2 ^1
execute @p[tag=mes_sb_lttng,scores={mes_splbk_lightt=1}] ~ ~ ~ particle mes_splbk:lightning_launch ^1.8 ^1. ^1
execute @p[tag=mes_sb_lttng,scores={mes_splbk_lightt=1}] ~ ~ ~ particle mes_splbk:lightning_launch ^0.3 ^1.3 ^1
execute @p[tag=mes_sb_lttng,scores={mes_splbk_lightt=1},tag=mes_sb_big] ~ ~ ~ particle mes_splbk:lightning_launch ^ ^1.2 ^1
execute @p[tag=mes_sb_lttng,scores={mes_splbk_lightt=1},tag=mes_sb_big] ~ ~ ~ particle mes_splbk:lightning_launch ^1.8 ^1. ^1
execute @p[tag=mes_sb_lttng,scores={mes_splbk_lightt=1},tag=mes_sb_big] ~ ~ ~ particle mes_splbk:lightning_launch ^0.3 ^1.3 ^1
execute @p[tag=mes_sb_lttng,scores={mes_splbk_lightt=1}] ~ ~ ~ tag @s add mes_sb_llsh
execute @p[tag=mes_sb_lttng,scores={mes_splbk_lightt=3},tag=mes_sb_small] ~ ~ ~ tag @e[type=mes_splbk:lightning_shoot] add mes_sb_small
execute @p[tag=mes_sb_lttng,scores={mes_splbk_lightt=3},tag=mes_sb_medium] ~ ~ ~ tag @e[type=mes_splbk:lightning_shoot] add mes_sb_medium
execute @p[tag=mes_sb_lttng,scores={mes_splbk_lightt=3},tag=mes_sb_big] ~ ~ ~ tag @e[type=mes_splbk:lightning_shoot] add mes_sb_big
execute @p[tag=mes_sb_lttng,scores={mes_splbk_lightt=80}] ~ ~ ~ event entity @s mes_splbk:cooldown_off
tag @p[tag=mes_sb_lttng,scores={mes_splbk_lightt=80}] remove mes_sb_small
tag @p[tag=mes_sb_lttng,scores={mes_splbk_lightt=80}] remove mes_sb_medium
tag @p[tag=mes_sb_lttng,scores={mes_splbk_lightt=80}] remove mes_sb_big
tag @p[tag=mes_sb_lttng,scores={mes_splbk_lightt=80}] remove mes_sb_lttng
scoreboard players set @p[r=1,scores={mes_splbk_lightt=80}] mes_splbk_lightt 0


scoreboard players add @e[type=mes_splbk:lightning_shoot] mes_splbk_lightt 1
execute @e[type=mes_splbk:lightning_shoot] ~ ~ ~ particle mes_splbk:lightning_ball ~ ~ ~
execute @e[type=mes_splbk:lightning_shoot,scores={mes_splbk_lightt=50},tag=mes_sb_small] ~ ~ ~ execute @e[r=5,type=!mes_splbk:lightning_shoot,c=1] ~ ~ ~ summon lightning_bolt
execute @e[type=mes_splbk:lightning_shoot,scores={mes_splbk_lightt=50},tag=mes_sb_medium] ~ ~ ~ execute @e[r=5,type=!mes_splbk:lightning_shoot,c=2] ~ ~ ~ summon lightning_bolt
execute @e[type=mes_splbk:lightning_shoot,scores={mes_splbk_lightt=50},tag=mes_sb_big] ~ ~ ~ execute @e[r=5,type=!mes_splbk:lightning_shoot,c=3] ~ ~ ~ summon lightning_bolt
execute @e[type=mes_splbk:lightning_shoot,scores={mes_splbk_lightt=50}] ~ ~ ~ execute @e[r=5,type=!mes_splbk:lightning_shoot] ~ ~ ~ kill @e[type=mes_splbk:lightning_shoot,r=5]
execute @e[type=mes_splbk:lightning_shoot,scores={mes_splbk_lightt=51}] ~ ~ ~ summon lightning_bolt
execute @e[type=mes_splbk:lightning_shoot,scores={mes_splbk_lightt=51},tag=mes_sb_medium] ~ ~ ~ summon lightning_bolt ~3 ~ ~
execute @e[type=mes_splbk:lightning_shoot,scores={mes_splbk_lightt=51},tag=mes_sb_big] ~ ~ ~ summon lightning_bolt ~3 ~ ~
execute @e[type=mes_splbk:lightning_shoot,scores={mes_splbk_lightt=51},tag=mes_sb_big] ~ ~ ~ summon lightning_bolt ~-3 ~ ~
execute @e[type=mes_splbk:lightning_shoot,scores={mes_splbk_lightt=51}] ~ ~ ~ kill @s

scoreboard players add @e[r=1,tag=mes_sb_dfsv] mes_splbk_dfsvt 1
execute @a[tag=mes_sb_dfsv,scores={mes_splbk_dfsvt=1}] ~ ~ ~ playsound sw.music.shoot_ability @a[r=10]
execute @a[tag=mes_sb_dfsv,scores={mes_splbk_dfsvt=1}] ~ ~ ~ particle mes_splbk:air_shockwave ~ ~ ~
execute @a[tag=mes_sb_dfsv,scores={mes_splbk_dfsvt=1}] ~ ~ ~ particle mes_splbk:air_visual ~ ~ ~
execute @a[tag=mes_sb_dfsv,scores={mes_splbk_dfsvt=1..16}] ~ ~ ~ execute @e[type=!player,family=!inac,family=!npc,type=!item,r=8,family=mob] ~ ~ ~ tp @s ^ ^0.1 ^-0.45 facing @p[tag=mes_sb_dfsv] 
tag @a[tag=mes_sb_dfsv,scores={mes_splbk_dfsvt=34}] remove mes_sb_dfsv
scoreboard players set @p[r=1,scores={mes_splbk_dfsvt=34}] mes_splbk_dfsvt 0



scoreboard players add @p[r=1,tag=mes_sb_blind] mes_splbk_blndt 1
execute @a[tag=mes_sb_blind,scores={mes_splbk_blndt=16..100,book=1}] ~ ~ ~ event entity @s mes_splbk:cooldown_on
execute @a[tag=mes_sb_blind,scores={mes_splbk_blndt=1}] ~ ~ ~ playsound sw.music.shoot_ability @a[r=10]
execute @a[tag=mes_sb_blind,scores={mes_splbk_blndt=1}] ~ ~ ~ execute @e[rm=1,family=!inac,family=!npc,type=!item,r=10,family=mob] ~ ~ ~ tag @p[tag=mes_sb_blind] add yes
execute @a[tag=mes_sb_blind,scores={mes_splbk_blndt=1}] ~ ~ ~ titleraw @p[tag=mes_sb_blind,tag=!yes] actionbar { "rawtext" : [ { "translate" : "noone.text" } ] }
execute @a[tag=mes_sb_blind,scores={mes_splbk_blndt=1}] ~ ~ ~ scoreboard players set @p[tag=mes_sb_blind,tag=!yes] mes_splbk_blndt 100
execute @a[tag=mes_sb_blind,scores={mes_splbk_blndt=1}] ~ ~ ~ execute @e[rm=1,family=!inac,family=!npc,type=!item,r=10,family=mob] ~ ~ ~ particle mes_splbk:dark_ring ^ ^0.1 ^0.1
execute @a[tag=mes_sb_blind,scores={mes_splbk_blndt=1}] ~ ~ ~ execute @e[rm=1,family=!inac,family=!npc,type=!item,r=10,family=mob] ~ ~ ~ particle mes_splbk:necro_poof ~ ~ ~
execute @a[tag=mes_sb_blind,scores={mes_splbk_blndt=1}] ~ ~ ~ effect @e[rm=1,family=!inac,family=!npc,type=!item,r=10,family=mob] darkness 5 255 true
execute @a[tag=mes_sb_blind,scores={mes_splbk_blndt=1}] ~ ~ ~ effect @e[rm=1,family=!inac,family=!npc,type=!item,r=10,family=mob] slowness 5 255 true
execute @a[tag=mes_sb_blind,scores={mes_splbk_blndt=100}] ~ ~ ~ execute @e[rm=1,family=!inac,family=!npc,type=!item,r=10,family=mob] ~ ~ ~ particle mes_splbk:necro_poof ~ ~ ~
execute @a[tag=mes_sb_blind,scores={mes_splbk_blndt=5}] ~ ~ ~ tag @a[tag=mes_sb_blind] remove yes
execute @a[tag=mes_sb_blind,scores={mes_splbk_blndt=100}] ~ ~ ~ event entity @s mes_splbk:cooldown_off
tag @a[tag=mes_sb_blind,scores={mes_splbk_blndt=101}] remove mes_sb_blind
scoreboard players set @p[r=1,scores={mes_splbk_blndt=101}] mes_splbk_blndt 0

scoreboard players add @p[r=1,tag=mes_sb_heat] mes_splbk_ncrt 1
execute @p[tag=mes_sb_heat,scores={mes_splbk_ncrt=16..80,book=2}] ~ ~ ~ event entity @s mes_splbk:cooldown_on
execute @p[tag=mes_sb_heat,scores={mes_splbk_ncrt=1}] ~ ~ ~ tag @e[type=!player,type=!mes_splbk:heat_shoot,family=!inac,family=!npc,type=!item,c=1,family=mob,tag=!mes_sb_vctm] add mes_sb_vctm
execute @p[tag=mes_sb_heat,scores={mes_splbk_ncrt=1}] ~ ~ ~ summon mes_splbk:heat_shoot ^ ^ ^3
execute @p[tag=mes_sb_heat,scores={mes_splbk_ncrt=2}] ~ ~ ~ tag @e[type=!player,type=!mes_splbk:heat_shoot,family=!inac,family=!npc,type=!item,c=1,family=mob,tag=!mes_sb_vctm,tag=!mes_sb_vctmd] add mes_sb_vctmd
execute @p[tag=mes_sb_heat,scores={mes_splbk_ncrt=2}] ~ ~ ~ summon mes_splbk:heat_shoot ^1.5 ^ ^3
execute @p[tag=mes_sb_heat,scores={mes_splbk_ncrt=3}] ~ ~ ~ tag @e[type=!player,type=!mes_splbk:heat_shoot,family=!inac,family=!npc,type=!item,c=1,family=mob,tag=!mes_sb_vctmd,tag=!mes_sb_vctm,tag=!mes_sb_vctmt] add mes_sb_vctmt
execute @p[tag=mes_sb_heat,scores={mes_splbk_ncrt=3}] ~ ~ ~ summon mes_splbk:heat_shoot ^-1.5 ^ ^3
execute @p[tag=mes_sb_heat,scores={mes_splbk_ncrt=1}] ~ ~ ~ playsound sw.music.tp_ability @a[r=20]
execute @p[tag=mes_sb_heat,scores={mes_splbk_ncrt=4}] ~ ~ ~ tag @e[type=mes_splbk:heat_shoot,tag=!mes_sb_hone,tag=!mes_sb_htwo,tag=!mes_sb_hthree,c=1] add mes_sb_hone
execute @p[tag=mes_sb_heat,scores={mes_splbk_ncrt=4}] ~ ~ ~ tag @e[type=mes_splbk:heat_shoot,tag=!mes_sb_hone,tag=!mes_sb_htwo,tag=!mes_sb_hthree,c=1] add mes_sb_htwo
execute @p[tag=mes_sb_heat,scores={mes_splbk_ncrt=4}] ~ ~ ~ tag @e[type=mes_splbk:heat_shoot,tag=!mes_sb_hone,tag=!mes_sb_htwo,tag=!mes_sb_hthree,c=1] add mes_sb_hthree
execute @p[tag=mes_sb_heat,scores={mes_splbk_ncrt=80}] ~ ~ ~ kill @e[type=mes_splbk:heat_shoot]
execute @p[tag=mes_sb_heat,scores={mes_splbk_ncrt=80}] ~ ~ ~ tag @e remove mes_sb_vctm
execute @p[tag=mes_sb_heat,scores={mes_splbk_ncrt=80}] ~ ~ ~ tag @e remove mes_sb_vctmt
execute @p[tag=mes_sb_heat,scores={mes_splbk_ncrt=80}] ~ ~ ~ tag @e remove mes_sb_vctmd
execute @p[tag=mes_sb_heat,scores={mes_splbk_ncrt=80}] ~ ~ ~ event entity @s mes_splbk:cooldown_off
tag @p[tag=mes_sb_heat,scores={mes_splbk_ncrt=81}] add revheat
tag @p[tag=mes_sb_heat,scores={mes_splbk_ncrt=81}] remove mes_sb_heat
scoreboard players set @p[tag=revheat,scores={mes_splbk_ncrt=81}] mes_splbk_ncrt 0
tag @p[r=1] remove revheat


execute @e[type=mes_splbk:heat_shoot,tag=mes_sb_hone] ~ ~ ~ tp @s ^ ^0.05 ^0.39 facing @e[tag=mes_sb_vctm] 
execute @e[type=mes_splbk:heat_shoot,tag=mes_sb_htwo] ~ ~ ~ tp @s ^ ^0.05 ^0.39 facing @e[tag=mes_sb_vctmd] 
execute @e[type=mes_splbk:heat_shoot,tag=mes_sb_hthree] ~ ~ ~ tp @s ^ ^0.05 ^0.39 facing @e[tag=mes_sb_vctmt] 
execute @e[type=mes_splbk:heat_shoot] ~ ~ ~ particle mes_splbk:shadow_ball ~ ~ ~


scoreboard players add @p[r=1,tag=mes_sb_ebon] mes_splbk_ncrt 1
execute @p[tag=mes_sb_ebon,scores={mes_splbk_ncrt=16..97,book=3}] ~ ~ ~ event entity @s mes_splbk:cooldown_on
execute @p[tag=mes_sb_ebon,scores={mes_splbk_ncrt=1}] ~ ~ ~ effect @e[r=15,family=mob,tag=!ocelotdruid,tag=!spiderdruid,tag=!batdruid,family=!inac] slowness 6 255 true
execute @p[tag=mes_sb_ebon,scores={mes_splbk_ncrt=1}] ~ ~ ~ execute @e[r=15,family=mob,tag=!ocelotdruid,tag=!spiderdruid,tag=!batdruid,family=!inac] ~ ~ ~ tag @p[tag=mes_sb_ebon] add yes
execute @p[tag=mes_sb_ebon,scores={mes_splbk_ncrt=1}] ~ ~ ~ titleraw @p[tag=mes_sb_ebon,tag=!yes] actionbar { "rawtext" : [ { "translate" : "noone.text" } ] }
execute @p[tag=mes_sb_ebon,scores={mes_splbk_ncrt=1}] ~ ~ ~ scoreboard players set @p[tag=mes_sb_ebon,tag=!yes] mes_splbk_ncrt 100
execute @p[tag=mes_sb_ebon,scores={mes_splbk_ncrt=1}] ~ ~ ~ playsound dig.azalea_leaves @a[r=10]
execute @p[tag=mes_sb_ebon,scores={mes_splbk_ncrt=1}] ~ ~ ~ particle mes_splbk:ebon_launch ~ ~ ~
execute @p[tag=mes_sb_ebon,scores={mes_splbk_ncrt=10}] ~ ~ ~ playsound block.chorusflower.death @a[r=10]
execute @p[tag=mes_sb_ebon,scores={mes_splbk_ncrt=1}] ~ ~ ~ execute @e[r=15,family=mob,tag=!ocelotdruid,tag=!spiderdruid,tag=!batdruid,family=!inac] ~ ~ ~ summon mes_splbk:ebon
execute @p[tag=mes_sb_ebon,scores={mes_splbk_ncrt=2}] ~ ~ ~ execute @e[r=15,family=mob,tag=!ocelotdruid,tag=!spiderdruid,tag=!batdruid,family=!inac] ~ ~ ~ particle mes_splbk:ebon
execute @p[tag=mes_sb_ebon,scores={mes_splbk_ncrt=2}] ~ ~ ~ execute @e[r=15,family=mob,tag=!ocelotdruid,tag=!spiderdruid,tag=!batdruid,family=!inac] ~ ~ ~ particle mes_splbk:ebon_mes_sb_small ~ ~0.11 ~
execute @p[tag=mes_sb_ebon,scores={mes_splbk_ncrt=3}] ~ ~ ~ playanimation @e[type=mes_splbk:ebon] animation.mes_splbk.ebon.start f 100
execute @p[tag=mes_sb_ebon,scores={mes_splbk_ncrt=15}] ~ ~ ~ execute @e[type=mes_splbk:ebon] ~ ~ ~ effect @e[r=3,family=mob] fatal_poison 6 255 true
execute @p[tag=mes_sb_ebon,scores={mes_splbk_ncrt=96}] ~ ~ ~ execute @e[type=mes_splbk:ebon] ~ ~ ~ particle mes_splbk:ebon_explode ~ ~1 ~
execute @p[tag=mes_sb_ebon,scores={mes_splbk_ncrt=96}] ~ ~ ~ playsound block.chorusflower.grow @a[r=10]
execute @p[tag=mes_sb_ebon,scores={mes_splbk_ncrt=96}] ~ ~ ~ tp @e[type=mes_splbk:ebon] ~ ~-100 ~
execute @p[tag=mes_sb_ebon,scores={mes_splbk_ncrt=99}] ~ ~ ~ kill @e[type=mes_splbk:ebon]
execute @p[tag=mes_sb_ebon,scores={mes_splbk_ncrt=99}] ~ ~ ~ tag @a[tag=mes_sb_ebon] remove yes
execute @p[tag=mes_sb_ebon,scores={mes_splbk_ncrt=110}] ~ ~ ~ event entity @s mes_splbk:cooldown_off
tag @p[tag=mes_sb_ebon,scores={mes_splbk_ncrt=110}] add revdebon
tag @p[tag=mes_sb_ebon,scores={mes_splbk_ncrt=110}] remove mes_sb_ebon
scoreboard players set @p[tag=revdebon,scores={mes_splbk_ncrt=110}] mes_splbk_ncrt 0
tag @p remove revdebon

scoreboard players add @p[r=1,tag=mes_sb_dash] mes_splbk_ncrt 1
execute @p[tag=mes_sb_dash,scores={mes_splbk_ncrt=16..99,book=4}] ~ ~ ~ event entity @s mes_splbk:cooldown_on
execute @p[tag=mes_sb_dash,scores={mes_splbk_ncrt=1}] ~ ~ ~ playsound sw.music.necro_ability @a[r=15]
execute @p[tag=mes_sb_dash,scores={mes_splbk_ncrt=1}] ~ ~ ~ summon mes_splbk:nwither_skeleton ^ ^ ^1
execute @p[tag=mes_sb_dash,scores={mes_splbk_ncrt=1}] ~ ~ ~ tag @e[type=mes_splbk:nwither_skeleton,r=2.5,c=1] add mes_sb_dashw
execute @p[tag=mes_sb_dash,scores={mes_splbk_ncrt=1}] ~ ~ ~ replaceitem entity @e[tag=mes_sb_dashw] slot.weapon.mainhand 0 stone_sword
execute @p[tag=mes_sb_dash,scores={mes_splbk_ncrt=1}] ~ ~ ~ replaceitem entity @e[tag=mes_sb_dashw] slot.weapon.offhand 0 ender_pearl
execute @p[tag=mes_sb_dash,scores={mes_splbk_ncrt=1}] ~ ~ ~ replaceitem entity @e[tag=mes_sb_dashw] slot.armor.head 0 netherite_helmet
execute @p[tag=mes_sb_dash,scores={mes_splbk_ncrt=1}] ~ ~ ~ effect @e[tag=mes_sb_dashw] resistance 1000 255 true

execute @p[tag=mes_sb_dash,scores={mes_splbk_ncrt=20}] ~ ~ ~ execute @e[tag=mes_sb_dashw] ~ ~ ~ playsound mob.endermen.portal @a[r=20]
execute @p[tag=mes_sb_dash,scores={mes_splbk_ncrt=20}] ~ ~ ~ execute @e[tag=mes_sb_dashw] ~ ~ ~ particle mes_splbk:necro_poof ~ ~ ~
execute @p[tag=mes_sb_dash,scores={mes_splbk_ncrt=20}] ~ ~ ~ execute @e[tag=mes_sb_dashw] ~ ~ ~ tp @s @e[type=!player,family=!inac,family=!npc,type=!item,c=1,family=mob,tag=!tempennemy,r=12]
execute @p[tag=mes_sb_dash,scores={mes_splbk_ncrt=21}] ~ ~ ~ execute @e[tag=mes_sb_dashw] ~ ~ ~ effect @e[r=1,family=mob] instant_damage 1 1 true
execute @p[tag=mes_sb_dash,scores={mes_splbk_ncrt=21}] ~ ~ ~ execute @e[tag=mes_sb_dashw] ~ ~ ~ effect @e[r=1,family=mob] wither 5 1 true
execute @p[tag=mes_sb_dash,scores={mes_splbk_ncrt=21}] ~ ~ ~ execute @e[tag=mes_sb_dashw] ~ ~ ~ tag @e[type=!player,family=!inac,family=!npc,type=!item,c=1,family=mob,tag=!tempennemy,r=1.2] add tempennemy

execute @p[tag=dash,scores={mes_splbk_ncrt=35}] ~ ~ ~ execute @e[tag=mes_sb_dashw] ~ ~ ~ playsound mob.endermen.portal @a[r=20]
execute @p[tag=mes_sb_dash,scores={mes_splbk_ncrt=35}] ~ ~ ~ execute @e[tag=mes_sb_dashw] ~ ~ ~ particle mes_splbk:necro_poof ~ ~ ~
execute @p[tag=mes_sb_dash,scores={mes_splbk_ncrt=35}] ~ ~ ~ execute @e[tag=mes_sb_dashw] ~ ~ ~ tp @s @e[type=!player,family=!inac,family=!npc,type=!item,c=1,family=mob,tag=!tempennemy,r=12]
execute @p[tag=mes_sb_dash,scores={mes_splbk_ncrt=36}] ~ ~ ~ execute @e[tag=mes_sb_dashw] ~ ~ ~ effect @e[r=1,family=mob] instant_damage 1 1 true
execute @p[tag=mes_sb_dash,scores={mes_splbk_ncrt=36}] ~ ~ ~ execute @e[tag=mes_sb_dashw] ~ ~ ~ effect @e[r=1,family=mob] wither 5 1 true
execute @p[tag=mes_sb_dash,scores={mes_splbk_ncrt=36}] ~ ~ ~ execute @e[tag=mes_sb_dashw] ~ ~ ~ tag @e[type=!player,family=!inac,family=!npc,type=!item,c=1,family=mob,tag=!tempennemy,r=1.2] add tempennemy

execute @p[tag=mes_sb_dash,scores={mes_splbk_ncrt=51}] ~ ~ ~ execute @e[tag=mes_sb_dashw] ~ ~ ~ playsound mob.endermen.portal @a[r=20]
execute @p[tag=mes_sb_dash,scores={mes_splbk_ncrt=51}] ~ ~ ~ execute @e[tag=mes_sb_dashw] ~ ~ ~ particle mes_splbk:necro_poof ~ ~ ~
execute @p[tag=mes_sb_dash,scores={mes_splbk_ncrt=51}] ~ ~ ~ execute @e[tag=mes_sb_dashw] ~ ~ ~ tp @s @e[type=!player,family=!inac,family=!npc,type=!item,c=1,family=mob,tag=!tempennemy,r=12]
execute @p[tag=mes_sb_dash,scores={mes_splbk_ncrt=52}] ~ ~ ~ execute @e[tag=mes_sb_dashw] ~ ~ ~ effect @e[r=1,family=mob] instant_damage 1 1 true
execute @p[tag=mes_sb_dash,scores={mes_splbk_ncrt=52}] ~ ~ ~ execute @e[tag=mes_sb_dashw] ~ ~ ~ effect @e[r=1,family=mob] wither 5 1 true
execute @p[tag=mes_sb_dash,scores={mes_splbk_ncrt=52}] ~ ~ ~ execute @e[tag=mes_sb_dashw] ~ ~ ~ tag @e[type=!player,family=!inac,family=!npc,type=!item,c=1,family=mob,tag=!tempennemy,r=1.2] add tempennemy

execute @p[tag=mes_sb_dash,scores={mes_splbk_ncrt=67}] ~ ~ ~ execute @e[tag=mes_sb_dashw] ~ ~ ~ playsound mob.endermen.portal @a[r=20]
execute @p[tag=mes_sb_dash,scores={mes_splbk_ncrt=67}] ~ ~ ~ execute @e[tag=mes_sb_dashw] ~ ~ ~ particle mes_splbk:necro_poof ~ ~ ~
execute @p[tag=mes_sb_dash,scores={mes_splbk_ncrt=67}] ~ ~ ~ execute @e[tag=mes_sb_dashw] ~ ~ ~ tp @s @e[type=!player,family=!inac,family=!npc,type=!item,c=1,family=mob,tag=!tempennemy,r=12]
execute @p[tag=mes_sb_dash,scores={mes_splbk_ncrt=68}] ~ ~ ~ execute @e[tag=mes_sb_dashw] ~ ~ ~ effect @e[r=1,family=mob] instant_damage 1 1 true
execute @p[tag=mes_sb_dash,scores={mes_splbk_ncrt=68}] ~ ~ ~ execute @e[tag=mes_sb_dashw] ~ ~ ~ effect @e[r=1,family=mob] wither 5 1 true
execute @p[tag=mes_sb_dash,scores={mes_splbk_ncrt=68}] ~ ~ ~ execute @e[tag=mes_sb_dashw] ~ ~ ~ tag @e[type=!player,family=!inac,family=!npc,type=!item,c=1,family=mob,tag=!tempennemy,r=1.2] add tempennemy

execute @p[tag=mes_sb_dash,scores={mes_splbk_ncrt=83}] ~ ~ ~ execute @e[tag=mes_sb_dashw] ~ ~ ~ playsound mob.endermen.portal @a[r=20]
execute @p[tag=mes_sb_dash,scores={mes_splbk_ncrt=83}] ~ ~ ~ execute @e[tag=mes_sb_dashw] ~ ~ ~ particle mes_splbk:necro_poof ~ ~ ~
execute @p[tag=mes_sb_dash,scores={mes_splbk_ncrt=83}] ~ ~ ~ execute @e[tag=mes_sb_dashw] ~ ~ ~ tp @s @e[type=!player,family=!inac,family=!npc,type=!item,c=1,family=mob,tag=!tempennemy,r=12]
execute @p[tag=mes_sb_dash,scores={mes_splbk_ncrt=84}] ~ ~ ~ execute @e[tag=mes_sb_dashw] ~ ~ ~ effect @e[r=1,family=mob] instant_damage 1 1 true
execute @p[tag=mes_sb_dash,scores={mes_splbk_ncrt=84}] ~ ~ ~ execute @e[tag=mes_sb_dashw] ~ ~ ~ effect @e[r=1,family=mob] wither 5 1 true
execute @p[tag=mes_sb_dash,scores={mes_splbk_ncrt=84}] ~ ~ ~ execute @e[tag=mes_sb_dashw] ~ ~ ~ tag @e[type=!player,family=!inac,family=!npc,type=!item,c=1,family=mob,tag=!tempennemy,r=1.2] add tempennemy

execute @p[tag=mes_sb_dash,scores={mes_splbk_ncrt=95}] ~ ~ ~ execute @e[tag=mes_sb_dashw] ~ ~ ~ tag @e[r=30] remove tempennemy
execute @p[tag=mes_sb_dash,scores={mes_splbk_ncrt=95}] ~ ~ ~ execute @e[tag=mes_sb_dashw] ~ ~ ~ particle mes_splbk:poof ~ ~ ~
execute @p[tag=mes_sb_dash,scores={mes_splbk_ncrt=95}] ~ ~ ~ execute @e[tag=mes_sb_dashw] ~ ~ ~ tp @s ~ ~-20 ~
execute @p[tag=mes_sb_dash,scores={mes_splbk_ncrt=99}] ~ ~ ~ kill @e[tag=mes_sb_dashw]
execute @p[tag=mes_sb_dash,scores={mes_splbk_ncrt=100}] ~ ~ ~ event entity @s mes_splbk:cooldown_off
tag @p[tag=mes_sb_dash,scores={mes_splbk_ncrt=100}] add revsdash
tag @p[tag=mes_sb_dash,scores={mes_splbk_ncrt=100}] remove mes_sb_dash
scoreboard players set @p[tag=revsdash,scores={mes_splbk_ncrt=100}] mes_splbk_ncrt 0
tag @p remove revsdash

