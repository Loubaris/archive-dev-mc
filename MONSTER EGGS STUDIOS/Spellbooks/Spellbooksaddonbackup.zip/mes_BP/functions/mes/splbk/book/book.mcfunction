scoreboard players add @p[r=0.5] mes_splbk_book 1

playsound item.book.page_turn @p[r=1] ~ ~ ~ 0.6

titleraw @p[r=0.5,scores={mes_splbk_book=1,mes_splbk_page=0}] actionbar { "rawtext" : [ { "translate" : "nounlock.text" } ] }
scoreboard players set @p[r=0.5,scores={mes_splbk_book=1,mes_splbk_page=0}] mes_splbk_book 5
titleraw @p[r=0.5,scores={mes_splbk_book=2,mes_splbk_page=..1}] actionbar { "rawtext" : [ { "translate" : "nounlock.text" } ] }
scoreboard players set @p[r=0.5,scores={mes_splbk_book=2,mes_splbk_page=..1}] mes_splbk_book 5
titleraw @p[r=0.5,scores={mes_splbk_book=3,mes_splbk_page=..2}] actionbar { "rawtext" : [ { "translate" : "nounlock.text" } ] }
scoreboard players set @p[r=0.5,scores={mes_splbk_book=3,mes_splbk_page=..2}] mes_splbk_book 5
titleraw @p[r=0.5,scores={mes_splbk_book=4,mes_splbk_page=..3}] actionbar { "rawtext" : [ { "translate" : "nounlock.text" } ] }
scoreboard players set @p[r=0.5,scores={mes_splbk_book=4,mes_splbk_page=..3}] mes_splbk_book 5

scoreboard players set @p[r=0.5,scores={mes_splbk_book=5}] mes_splbk_book 0
event entity @p[r=0.5,scores={mes_splbk_book=4,mes_splbk_page=4}] page_five
event entity @p[r=0.5,scores={mes_splbk_book=3,mes_splbk_page=3..}] page_four
event entity @p[r=0.5,scores={mes_splbk_book=2,mes_splbk_page=2..}] page_three
event entity @p[r=0.5,scores={mes_splbk_book=1,mes_splbk_page=1..}] page_two
event entity @p[r=0.5,scores={mes_splbk_book=0}] page_one
event entity @s mes_splbk:cooldown_off