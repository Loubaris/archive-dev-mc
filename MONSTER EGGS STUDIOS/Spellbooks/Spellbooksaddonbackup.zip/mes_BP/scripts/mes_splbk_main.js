import * as menu from './mes_splbk_menu.js';
import * as launches from './mes_splbk_launches.js';
import { world, system } from "@minecraft/server";

// switch book page e.source.runCommand("/function mes/splbk/book/book")

world.afterEvents.itemStopUse.subscribe(e => {

    // FIRE BOOK
    if (e.itemStack.typeId === "mes_splbk:fire_book") {
        e.source.runCommand("/tag @p[r=0.5,scores={mes_splbk_book=0}] add mes_sb_fireswrd")
        e.source.runCommand("/tag @p[r=0.5,scores={mes_splbk_book=1}] add mes_sb_lava")
        e.source.runCommand("/tag @p[r=0.5,scores={mes_splbk_book=2}] add mes_sb_geyser")
        e.source.runCommand("/tag @p[r=0.5,scores={mes_splbk_book=3}] add mes_sb_inferno")
        e.source.runCommand("/tag @p[r=0.5,scores={mes_splbk_book=4}] add mes_sb_volcano")
        e.source.runCommand("/titleraw @a[r=0.5,scores={mes_splbk_book=1,mes_splbk_lvt=50..}] actionbar { \"rawtext\" : [ { \"translate\" : \"firewall.wait\" } ] }")
    };
    if (e.itemStack.typeId === "mes_splbk:water_book") {
        e.source.runCommand("/tag @p[r=0.5,scores={mes_splbk_book=0,mes_splbk_mlt=0}] add mes_sb_wave")
        e.source.runCommand("/tag @p[r=0.5,scores={mes_splbk_book=1,mes_splbk_mlt=0}] add mes_sb_snow")
        e.source.runCommand("/tag @p[r=0.5,scores={mes_splbk_book=2}] add mes_sb_bble")
        e.source.runCommand("/tag @p[r=0.5,scores={mes_splbk_book=3}] add mes_sb_iclce")
        e.source.runCommand("/tag @p[r=0.5,scores={mes_splbk_book=4,mes_splbk_mlt=0}] add mes_sb_water")
        e.source.runCommand("/titleraw @a[r=0.5,scores={mes_splbk_book=0,mes_splbk_mlt=3..}] actionbar { \"rawtext\" : [ { \"translate\" : \"general.wait\" } ] }")
        e.source.runCommand("/titleraw @a[r=0.5,scores={mes_splbk_book=1,mes_splbk_mlt=3..}] actionbar { \"rawtext\" : [ { \"translate\" : \"general.wait\" } ] }")
        e.source.runCommand("/titleraw @a[r=0.5,scores={mes_splbk_book=4,mes_splbk_mlt=3..}] actionbar { \"rawtext\" : [ { \"translate\" : \"general.wait\" } ] }")
    };
    if (e.itemStack.typeId === "mes_splbk:earth_book") {
        e.source.runCommand("/tag @p[r=0.5,scores={mes_splbk_book=0}] add mes_sb_stnfsts")
        e.source.runCommand("/tag @p[r=0.5,scores={mes_splbk_book=1}] add mes_sb_entomb")
        e.source.runCommand("/tag @p[r=0.5,scores={mes_splbk_book=2}] add mes_sb_stnbdy")
        e.source.runCommand("/tag @p[r=0.5,scores={mes_splbk_book=3}] add mes_sb_aval")
        e.source.runCommand("/tag @p[r=0.5,scores={mes_splbk_book=4}] add mes_sb_earqke")
        e.source.runCommand("/titleraw @a[r=0.5,scores={mes_splbk_book=2,mes_splbk_stnbt=50..}] actionbar { \"rawtext\" : [ { \"translate\" : \"general.wait\" } ] }")
    };
    if (e.itemStack.typeId === "mes_splbk:druid_book") {
        e.source.runCommand("/tag @p[r=0.5,scores={mes_splbk_book=0,mes_splbk_wlft=..4}] add mes_sb_wolf")
        e.source.runCommand("/tag @p[r=0.5,scores={mes_splbk_book=1,mes_splbk_drdt=..4}] add mes_sb_spider")
        e.source.runCommand("/tag @p[r=0.5,scores={mes_splbk_book=2,mes_splbk_drdt=..4}] add mes_sb_bat")
        e.source.runCommand("/tag @p[r=0.5,scores={mes_splbk_book=3}] add mes_sb_vines")
        e.source.runCommand("/tag @p[r=0.5,scores={mes_splbk_book=4}] add mes_sb_seed")
        e.source.runCommand("/titleraw @a[r=0.5,scores={mes_splbk_book=1,mes_splbk_drdt=4..}] actionbar { \"rawtext\" : [ { \"translate\" : \"general.wait\" } ] }")
        e.source.runCommand("/titleraw @a[r=0.5,scores={mes_splbk_book=0,mes_splbk_wlft=4..}] actionbar { \"rawtext\" : [ { \"translate\" : \"general.wait\" } ] }")
        e.source.runCommand("/titleraw @a[r=0.5,scores={mes_splbk_book=2,mes_splbk_drdt=4..}] actionbar { \"rawtext\" : [ { \"translate\" : \"general.wait\" } ] }")
    };
    if (e.itemStack.typeId === "mes_splbk:necro_book") {
        e.source.runCommand("/tag @p[r=0.5,scores={mes_splbk_book=0,mes_splbk_ncrt=..4},tag=!zombie] add mes_sb_skltn")
        e.source.runCommand("/tag @p[r=0.5,scores={mes_splbk_book=1,mes_splbk_ncrt=..4},tag=!skeleton] add mes_sb_zmbie")
        e.source.runCommand("/tag @p[r=0.5,scores={mes_splbk_book=2}] add mes_sb_mnion")
        e.source.runCommand("/tag @p[r=0.5,scores={mes_splbk_book=3}] add mes_sb_totem")
        e.source.runCommand("/tag @p[r=0.5,scores={mes_splbk_book=4}] add mes_sb_drk")
        e.source.runCommand("/titleraw @a[r=0.5,scores={mes_splbk_book=0,mes_splbk_ncrt=4..}] actionbar { \"rawtext\" : [ { \"translate\" : \"general.wait\" } ] }")
        e.source.runCommand("/titleraw @a[r=0.5,scores={mes_splbk_book=1,mes_splbk_ncrt=4..}] actionbar { \"rawtext\" : [ { \"translate\" : \"general.wait\" } ] }")
    };
    if (e.itemStack.typeId === "mes_splbk:arcane_book") {
        e.source.runCommand("/tag @p[r=0.5,scores={mes_splbk_book=0}] add mes_sb_tballs")
        e.source.runCommand("/tag @p[r=0.5,scores={mes_splbk_book=1}] add mes_sb_blink")
        e.source.runCommand("/tag @p[r=0.5,scores={mes_splbk_book=2,mes_splbk_plmrt=..2}] add mes_sb_plmrph")
        e.source.runCommand("/tag @p[r=0.5,scores={mes_splbk_book=3}] add mes_sb_arcexpl")
        e.source.runCommand("/tag @p[r=0.5,scores={mes_splbk_book=4}] add mes_sb_arcward")
        e.source.runCommand("/titleraw @a[r=0.5,scores={mes_splbk_book=2,mes_splbk_plmrt=2..}] actionbar { \"rawtext\" : [ { \"translate\" : \"general.wait\" } ] }")
        e.source.runCommand("/titleraw @a[r=0.5,scores={mes_splbk_book=3,mes_splbk_arcext=1..}] actionbar { \"rawtext\" : [ { \"translate\" : \"general.wait\" } ] }")
        e.source.runCommand("/titleraw @a[r=0.5,scores={mes_splbk_book=1,mes_splbk_blkt=1..}] actionbar { \"rawtext\" : [ { \"translate\" : \"general.wait\" } ] }")
    };
    if (e.itemStack.typeId === "mes_splbk:air_book") {
        e.source.runCommand("/tag @p[r=0.5,scores={mes_splbk_book=0}] add mes_sb_zephyr")
        e.source.runCommand("/tag @p[r=0.5,scores={mes_splbk_book=1,mes_splbk_mlt=..3}] add mes_sb_mlstrm")
        e.source.runCommand("/tag @p[r=0.5,scores={mes_splbk_book=2,mes_splbk_mlt=..3}] add mes_sb_hdblt")
        e.source.runCommand("/tag @p[r=0.5,scores={mes_splbk_book=3}] add mes_sb_dfsv")
        e.source.runCommand("/tag @p[r=0.5,scores={mes_splbk_book=4,mes_splbk_lightt=..2}] add mes_sb_lttng")
        e.source.runCommand("/titleraw @a[r=0.5,scores={mes_splbk_book=2,mes_splbk_mlt=3..}] actionbar { \"rawtext\" : [ { \"translate\" : \"general.wait\" } ] }")
        e.source.runCommand("/titleraw @a[r=0.5,scores={mes_splbk_book=4,mes_splbk_lightt=3..}] actionbar { \"rawtext\" : [ { \"translate\" : \"general.wait\" } ] }")
        e.source.runCommand("/titleraw @a[r=0.5,scores={mes_splbk_book=1,mes_splbk_mlt=3..}] actionbar { \"rawtext\" : [ { \"translate\" : \"general.wait\" } ] }")
    };
    if (e.itemStack.typeId === "mes_splbk:shadow_book") {
        e.source.runCommand("/effect @p[r=0.5,scores={mes_splbk_book=0}] invisibility 3 255 true")
        e.source.runCommand("/execute @p[r=0.5,scores={mes_splbk_book=0}] ~ ~ ~ particle mes_splbk:necro_poof ^ ^ ^0.2")
        e.source.runCommand("/execute @p[r=0.5,scores={mes_splbk_book=0}] ~ ~ ~ playsound sw.music.shoot_ability @a[r=5]")
        e.source.runCommand("/tag @p[r=0.5,scores={mes_splbk_book=1}] add mes_sb_blind")
        e.source.runCommand("/tag @p[r=0.5,scores={mes_splbk_book=2,mes_splbk_ncrt=..2}] add mes_sb_heat")
        e.source.runCommand("/tag @p[r=0.5,scores={mes_splbk_book=3,mes_splbk_ncrt=..2}] add mes_sb_ebon")
        e.source.runCommand("/tag @p[r=0.5,scores={mes_splbk_book=4,mes_splbk_ncrt=..2}] add mes_sb_dash")
        e.source.runCommand("/titleraw @a[r=0.5,scores={mes_splbk_book=2,mes_splbk_ncrt=4..}] actionbar { \"rawtext\" : [ { \"translate\" : \"general.wait\" } ] }")
        e.source.runCommand("/titleraw @a[r=0.5,scores={mes_splbk_book=4,mes_splbk_ncrt=4..}] actionbar { \"rawtext\" : [ { \"translate\" : \"general.wait\" } ] }")
        e.source.runCommand("/titleraw @a[r=0.5,scores={mes_splbk_book=3,mes_splbk_ncrt=4..}] actionbar { \"rawtext\" : [ { \"translate\" : \"general.wait\" } ] }")

    };



    // FOR CHARGING BOOKS
    if (e.source.hasTag("mes_sb_td") === true) {
        const timeduration = e.useDuration
        if (timeduration > 99970) {
            console.warn("first state")
            e.source.runCommand("/tag @s add mes_sb_small");
        };
        if (timeduration > 99940 && timeduration < 99971) {
            console.warn("second state");
            e.source.runCommand("/tag @s add mes_sb_medium");
        };
        if (timeduration < 99941) {
            console.warn("last state")
            e.source.runCommand("/tag @s add mes_sb_big");
        };
        
    };
    e.source.runCommand("/tag @s remove mes_sb_td")
});



function loop_commands(player) {
    system.runInterval(() => {


        player.runCommand("/function mes/splbk/commands")
        
        launches.test(player);
        // players[0].playAnimation("animation.mes_splbk.book.third_person")

        if (player.isJumping) {
            player.runCommand("/execute @a[tag=mes_sb_stnbdy,scores={mes_splbk_stnbt=..600}] ~ ~ ~ particle mes_splbk:earth_shockwave ~ ~ ~ ");
            player.runCommand("/execute @a[tag=mes_sb_stnbdy,scores={mes_splbk_stnbt=..600}] ~ ~ ~ playsound mob.breeze.slide @a[r=5]");
            player.runCommand("/execute @a[tag=mes_sb_zephyr,scores={mes_splbk_airt=5..}] ~ ~ ~ particle mes_splbk:zephyr ~ ~-1 ~");
            player.runCommand("/execute @a[tag=mes_sb_zephyr,scores={mes_splbk_airt=5..}] ~ ~ ~ tag @s add mes_sb_rmvjp");
            player.runCommand("/execute @a[tag=mes_sb_zephyr,scores={mes_splbk_airt=5..}] ~ ~ ~ effect @s levitation 1 27 true");
        };
        if (player.isSneaking) {
            player.runCommand("/execute @a[tag=mes_sb_spider,scores={mes_splbk_drdt=5..}] ~ ~ ~ scoreboard players set @p mes_splbk_drdt 595");
            player.runCommand("/execute @a[tag=mes_sb_bat,scores={mes_splbk_drdt=5..}] ~ ~ ~ scoreboard players set @p mes_splbk_drdt 595")
        };
    });


    world.afterEvents.itemUse.subscribe(e => {
        if (e.itemStack.typeId === "mes_splbk:guidebook") {
            menu.menushow(players[0]);
        }
    });
}


let players = world.getAllPlayers(); 

world.afterEvents.playerSpawn.subscribe(({ player, initialSpawn }) => {
    players = world.getAllPlayers(); 
});

players.forEach(loop_commands);

