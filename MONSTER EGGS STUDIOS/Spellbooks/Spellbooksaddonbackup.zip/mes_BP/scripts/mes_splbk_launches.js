
import { world, system, ItemStack, EntityInventoryComponent } from "@minecraft/server";
import { MessageFormResponse, MessageFormData, ActionFormData } from '@minecraft/server-ui';

export function test(player) {

    if (player.hasTag("mes_sb_fb") === true) {
        let location = player.getHeadLocation();
        const velocity = player.getViewDirection();
        location = {
            x: location.x + velocity.x*1.5,
            y: location.y + velocity.y*1.5,
            z: location.z + velocity.z*1.5
        };
        const projectile = player.dimension.spawnEntity('mes_splbk:boulder_toss', location);
        projectile.setRotation(player.getRotation());
        projectile.clearVelocity();
        projectile.applyImpulse({ x: velocity.x * 2, y: velocity.y * 2, z: velocity.z * 2 })
        player.runCommand("/tag @s remove mes_sb_fb")
    };
    if (player.hasTag("mes_sb_stnl") === true) {
        let location = player.getHeadLocation();
        const velocity = player.getViewDirection();
        location = {
            x: location.x + velocity.x*1.5,
            y: location.y + velocity.y*1.5,
            z: location.z + velocity.z*1.5
        };
        const projectile = player.dimension.spawnEntity('mes_splbk:stone_boulder', location);
        projectile.setRotation(player.getRotation());
        projectile.clearVelocity();
        projectile.applyImpulse({ x: velocity.x * 1.2, y: velocity.y * 1.2, z: velocity.z * 1.2 })
        player.runCommand("/tag @s remove mes_sb_stnl")
    };
    if (player.hasTag("mes_sb_bbll") === true) {
        let location = player.getHeadLocation();
        const velocity = player.getViewDirection();
        location = {
            x: location.x + velocity.x*1.5,
            y: location.y + velocity.y*1.5,
            z: location.z + velocity.z*1.5
        };
        const projectile = player.dimension.spawnEntity('mes_splbk:bubble_shoot', location);
        projectile.setRotation(player.getRotation());
        projectile.clearVelocity();
        projectile.applyImpulse({ x: velocity.x * 1.5, y: velocity.y * 1.5, z: velocity.z * 1.5 })
        player.runCommand("/tag @s remove mes_sb_bbll")
    };
    if (player.hasTag("mes_sb_icel") === true) {
        let location = player.getHeadLocation();
        const velocity = player.getViewDirection();
        location = {
            x: location.x + velocity.x*1.5,
            y: location.y + velocity.y*1.5,
            z: location.z + velocity.z*1.5
        };
        const projectile = player.dimension.spawnEntity('mes_splbk:icelance_shoot', location);
        projectile.setRotation(player.getRotation());
        projectile.clearVelocity();
        projectile.applyImpulse({ x: velocity.x * 2, y: velocity.y * 2, z: velocity.z * 2 })
        player.runCommand("/tag @s remove mes_sb_icel")
    };
    if (player.hasTag("mes_sb_drksh") === true) {
        let location = player.getHeadLocation();
        const velocity = player.getViewDirection();
        location = {
            x: location.x + velocity.x*1.5,
            y: location.y + velocity.y*1.5,
            z: location.z + velocity.z*1.5
        };
        const projectile = player.dimension.spawnEntity('mes_splbk:dark_shoot', location);
        projectile.setRotation(player.getRotation());
        projectile.clearVelocity();
        projectile.applyImpulse({ x: velocity.x * 2, y: velocity.y * 2, z: velocity.z * 2 })
        player.runCommand("/tag @s remove mes_sb_drksh")
    };
    if (player.hasTag("mes_sb_wardsh") === true) {
        let location = player.getHeadLocation();
        const velocity = player.getViewDirection();
        location = {
            x: location.x + velocity.x*1.5,
            y: location.y + velocity.y*1.5,
            z: location.z + velocity.z*1.5
        };
        const projectile = player.dimension.spawnEntity('mes_splbk:ward', location);
        projectile.setRotation(player.getRotation());
        projectile.clearVelocity();
        projectile.applyImpulse({ x: velocity.x * 2, y: velocity.y * 2, z: velocity.z * 2 })
        player.runCommand("/tag @s remove mes_sb_wardsh")
    };
    if (player.hasTag("mes_sb_llsh") === true) {
        let location = player.getHeadLocation();
        const velocity = player.getViewDirection();
        location = {
            x: location.x + velocity.x*1.5,
            y: location.y + velocity.y*1.5,
            z: location.z + velocity.z*1.5
        };
        const projectile = player.dimension.spawnEntity('mes_splbk:lightning_shoot', location);
        projectile.setRotation(player.getRotation());
        projectile.clearVelocity();
        projectile.applyImpulse({ x: velocity.x * 2.2, y: velocity.y * 2.5, z: velocity.z * 2.2 })
        player.runCommand("/tag @s remove mes_sb_llsh")
    }
};



