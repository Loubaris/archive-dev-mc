
import { world, system, ItemStack, EntityInventoryComponent } from "@minecraft/server";
import { MessageFormResponse, MessageFormData, ActionFormData } from '@minecraft/server-ui';


export function menushow(player) {
	player.playSound("item.book.put");
	const form = new ActionFormData()
    	.title({ translate: "mes_splbk.tutorial_title" })
    	.body({ translate: "mes_splbk.page1_body" })
    	.button({ translate: "mes_splbk.page1_btn1" }, "textures/items/stick")
    	.button({ translate: "mes_splbk.page1_btn2" }, "textures/items/netherite_pickaxe")
    	.button({ translate: "mes_splbk.page1_btn3" }, "textures/items/barrier");
	form.show(player);
}