execute @e[type=mes:wizard,tag=!a] ~ ~ ~ execute @p[r=10] ~ ~ ~ tellraw @a {"rawtext":[{"translate":"tutorial.first_text"}]}
execute @e[type=mes:wizard,tag=!a] ~ ~ ~ execute @p[r=10] ~ ~ ~ tag @e[type=mes:wizard] add a
# SUMMON CHECKPOINT







execute @e[tag=student] ~ ~ ~ detect ~ ~-0.1 ~ air 0 tp @s ~ ~-0.1 ~
execute @e[tag=student] ~ ~ ~ detect ^ ^ ^0.15 air 0 tp @s ^ ^ ^0.15 facing @e[type=mes:checkpoint,c=1,tag=!notfollow]
execute @e[tag=student] ~ ~ ~ tag @e[type=mes:checkpoint,r=1] add notfollow


execute @e[tag=student] ~ ~ ~ tp @e[type=mes:checkpoint,tag=notfollow] ~ ~-100 ~