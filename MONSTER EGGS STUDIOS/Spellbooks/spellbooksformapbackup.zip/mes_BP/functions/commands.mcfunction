scoreboard players add @a[tag=using,tag=!firesword,tag=!icelance,tag=!lightning,tag=!zombie,tag=!skeleton] chargetime 1

title @a[scores={chargetime=1..30},tag=fireusing] actionbar 
title @a[scores={chargetime=31..60},tag=fireusing] actionbar  
title @a[scores={chargetime=61..},tag=fireusing] actionbar §4!    !

title @a[scores={chargetime=1..30},tag=iceusing] actionbar 
title @a[scores={chargetime=31..60},tag=iceusing] actionbar  
title @a[scores={chargetime=61..},tag=iceusing] actionbar §b!    !

title @a[scores={chargetime=1..30},tag=lightusing] actionbar 
title @a[scores={chargetime=31..60},tag=lightusing] actionbar  
title @a[scores={chargetime=61..},tag=lightusing] actionbar §b!    !

title @a[scores={chargetime=1},tag=zombieuse] actionbar 
title @a[scores={chargetime=3},tag=zombieuse] actionbar  
title @a[scores={chargetime=5..30},tag=zombieuse] actionbar   
title @a[scores={chargetime=31..60},tag=zombieuse] actionbar    
title @a[scores={chargetime=61..},tag=zombieuse] actionbar §4!      !

title @a[scores={chargetime=1},tag=skeletonuse] actionbar  
title @a[scores={chargetime=3},tag=skeletonuse] actionbar   
title @a[scores={chargetime=5..30},tag=skeletonuse] actionbar   
title @a[scores={chargetime=31..60},tag=skeletonuse] actionbar    
title @a[scores={chargetime=61..},tag=skeletonuse] actionbar §4!      !

playsound mob.breeze.jump @p[r=0.5,scores={chargetime=60..},tag=!using]
tag @p[r=0.5,scores={book=0,chargetime=1..},tag=!using,tag=fireusing] add firesword   
execute @p[r=0.5,scores={book=0,chargetime=1..30},tag=!using,tag=fireusing] ~ ~ ~ tag @p add small
execute @p[r=0.5,scores={book=0,chargetime=31..60},tag=!using,tag=fireusing] ~ ~ ~ tag @p add medium
execute @p[r=0.5,scores={book=0,chargetime=61..},tag=!using,tag=fireusing] ~ ~ ~ tag @p add big

tag @p[r=0.5,scores={book=3,chargetime=1..},tag=!using,tag=iceusing] add icelance
execute @p[r=0.5,scores={book=3,chargetime=1..30},tag=!using,tag=iceusing] ~ ~ ~ tag @p add small
execute @p[r=0.5,scores={book=3,chargetime=31..60},tag=!using,tag=iceusing] ~ ~ ~ tag @p add medium
execute @p[r=0.5,scores={book=3,chargetime=61..},tag=!using,tag=iceusing] ~ ~ ~ tag @p add big

tag @p[r=0.5,scores={book=4,chargetime=1..},tag=!using,tag=lightusing] add lightning
execute @p[r=0.5,scores={book=4,chargetime=1..30},tag=!using,tag=lightusing] ~ ~ ~ tag @p add small
execute @p[r=0.5,scores={book=4,chargetime=31..60},tag=!using,tag=lightusing] ~ ~ ~ tag @p add medium
execute @p[r=0.5,scores={book=4,chargetime=61..},tag=!using,tag=lightusing] ~ ~ ~ tag @p add big


tag @p[r=0.5,scores={book=1,chargetime=1..},tag=!using,tag=zombieuse] add zombie
execute @p[r=0.5,scores={book=1,chargetime=31..60},tag=!using,tag=zombieuse] ~ ~ ~ tag @p add medium
execute @p[r=0.5,scores={book=1,chargetime=61..},tag=!using,tag=zombieuse] ~ ~ ~ tag @p add big

tag @p[r=0.5,scores={book=0,chargetime=1..},tag=!using,tag=skeletonuse] add skeleton
execute @p[r=0.5,scores={book=0,chargetime=31..60},tag=!using,tag=skeletonuse] ~ ~ ~ tag @p add medium
execute @p[r=0.5,scores={book=0,chargetime=61..},tag=!using,tag=skeletonuse] ~ ~ ~ tag @p add big

tag @a[scores={chargetime=1..},tag=!using] remove iceusing
tag @a[scores={chargetime=1..},tag=!using] remove fireusing
tag @a[scores={chargetime=1..},tag=!using] remove lightusing
tag @a[scores={chargetime=1..},tag=!using] remove skeletonuse
tag @a[scores={chargetime=1..},tag=!using] remove zombieuse
scoreboard players set @a[scores={chargetime=1..},tag=!using] chargetime 0

scoreboard players add @p[r=1,tag=firesword] firetime 1
execute @p[tag=firesword,scores={firetime=1}] ~ ~ ~ effect @p fire_resistance 5 255 true
execute @p[tag=firesword,scores={firetime=1}] ~ ~ ~ playsound sw.music.fire_ability @a[r=20]
execute @p[tag=firesword,scores={firetime=1}] ~ ~ ~ event entity @p[tag=firesword] sp:n_boulder_shoot
execute @p[tag=firesword,scores={firetime=6},tag=small] ~ ~ ~ playanimation @e[type=mes:boulder_toss] animation.boulder.small f 1000
execute @p[tag=firesword,scores={firetime=5},tag=small] ~ ~ ~ tag @e[type=mes:boulder_toss] add smallfire
execute @p[tag=firesword,scores={firetime=6},tag=medium] ~ ~ ~ playanimation @e[type=mes:boulder_toss] animation.boulder.medium f 1000
execute @p[tag=firesword,scores={firetime=6},tag=big] ~ ~ ~ playanimation @e[type=mes:boulder_toss] animation.boulder.big f 1000
tag @p[tag=firesword,scores={firetime=24}] remove small
tag @p[tag=firesword,scores={firetime=24}] remove medium
tag @p[tag=firesword,scores={firetime=24}] remove big
tag @p[tag=firesword,scores={firetime=25}] remove firesword
scoreboard players set @p[r=1,scores={firetime=25}] firetime 0

scoreboard players add @e[type=mes:boulder_toss] firetime 1
execute @e[type=mes:boulder_toss,tag=smallfire] ~ ~ ~ particle minecraft:mobflame_single ~ ~0.5 ~
execute @e[type=mes:boulder_toss,tag=!smallfire] ~ ~ ~ particle minecraft:mobflame_single ~ ~ ~0.5
execute @e[type=mes:boulder_toss,tag=!smallfire] ~ ~ ~ particle minecraft:mobflame_single ~0.5 ~ ~
execute @e[type=mes:boulder_toss,scores={firetime=50}] ~ ~ ~ playsound random.explode @a[r=30]
execute @e[type=mes:boulder_toss,scores={firetime=50}] ~ ~ ~ summon mes:instanttnt
execute @e[type=mes:boulder_toss,scores={firetime=50},tag=!smallfire] ~ ~ ~ summon mes:instanttnt
execute @e[type=mes:boulder_toss,scores={firetime=50}] ~ ~ ~ particle mes:boulder ~ ~ ~
execute @e[type=mes:boulder_toss,scores={firetime=47}] ~ ~ ~ effect @a resistance 2 255 true
execute @e[type=mes:boulder_toss,scores={firetime=50}] ~ ~ ~ effect @e[r=8,family=mob,family=!inac] instant_damage 3 1 true
execute @e[type=mes:boulder_toss,scores={firetime=51}] ~ ~ ~ kill @s


scoreboard players add @p[r=1,tag=inferno] infernotime 1
execute @a[tag=inferno,scores={infernotime=16..80,book=3}] ~ ~ ~ event entity @s mes:cooldown_on
execute @a[tag=inferno,scores={infernotime=1}] ~ ~ ~ playsound sw.music.inferno_ability @a[r=10]
execute @a[tag=inferno,scores={infernotime=1..40}] ~ ~ ~ particle mes:inferno_ring ~ ~ ~
execute @a[tag=inferno,scores={infernotime=1}] ~ ~ ~ effect @s fire_resistance 10 255 true
execute @a[tag=inferno,scores={infernotime=81}] ~ ~ ~ event entity @s mes:cooldown_off
execute @a[tag=inferno,scores={infernotime=81}] ~ ~ ~ fill ~-10 ~-1 ~-10 ~10 ~2 ~10 air 0 replace fire
tag @a[tag=inferno,scores={infernotime=81}] remove inferno
scoreboard players set @p[r=1,scores={infernotime=81}] infernotime 0


scoreboard players add @p[r=1,tag=geyser] geysertime 1
execute @a[tag=geyser,scores={geysertime=16..109,book=2}] ~ ~ ~ event entity @s mes:cooldown_on
execute @p[tag=geyser,scores={geysertime=1}] ~ ~ ~ effect @p fire_resistance 5 255 true
execute @p[tag=geyser,scores={geysertime=1}] ~ ~ ~ playsound sw.music.fire_ability @a[r=20]
execute @p[tag=geyser,scores={geysertime=1}] ~ ~ ~ summon mes:geyser ~ ~-100 ~
execute @p[tag=geyser,scores={geysertime=1}] ~ ~ ~ summon mes:geyser ~ ~-100 ~
execute @p[tag=geyser,scores={geysertime=1}] ~ ~ ~ summon mes:geyser ~ ~-100 ~
execute @p[tag=geyser,scores={geysertime=1}] ~ ~ ~ tp @e[type=mes:geyser,c=1,rm=5] ^ ^1 ^2 facing @p[tag=geyser]
execute @p[tag=geyser,scores={geysertime=1}] ~ ~ ~ tp @e[type=mes:geyser,c=1,rm=5] ^1.5 ^1 ^2 facing @p[tag=geyser]
execute @p[tag=geyser,scores={geysertime=1}] ~ ~ ~ tp @e[type=mes:geyser,c=1,rm=5] ^-1.5 ^1 ^2 facing @p[tag=geyser]
execute @p[tag=geyser,scores={geysertime=1}] ~ ~ ~ execute @e[type=mes:geyser] ~ ~ ~ tp @s ^ ^ ^-1
execute @p[tag=geyser,scores={geysertime=1}] ~ ~ ~ execute @e[type=mes:geyser] ~ ~ ~ effect @e[family=mob,family=!inac,r=2] fatal_poison 4 255 true
execute @p[tag=geyser,scores={geysertime=1}] ~ ~ ~ execute @e[type=mes:geyser] ~ ~ ~ execute @e[family=mob,family=!inac,r=2] ~ ~ ~ fill ~ ~ ~ ~ ~ ~ fire 0 replace air
execute @p[tag=geyser,scores={geysertime=1}] ~ ~ ~ execute @e[type=mes:geyser] ~ ~ ~ fill ^1 ^ ^ ^2 ^ ^ fire 0 replace air
execute @p[tag=geyser,scores={geysertime=1}] ~ ~ ~ execute @e[type=mes:geyser] ~ ~ ~ fill ^-1 ^ ^ ^-2 ^ ^ fire 0 replace air
execute @p[tag=geyser,scores={geysertime=1}] ~ ~ ~ execute @e[type=mes:geyser] ~ ~ ~ playanimation @e[type=mes:geyser] animation.geyser.monte
execute @p[tag=geyser,scores={geysertime=15}] ~ ~ ~ execute @e[type=mes:geyser] ~ ~ ~ tp @s ^ ^ ^-1
execute @p[tag=geyser,scores={geysertime=15}] ~ ~ ~ execute @e[type=mes:geyser] ~ ~ ~ effect @e[family=mob,family=!inac,r=2] fatal_poison 4 255 true
execute @p[tag=geyser,scores={geysertime=15}] ~ ~ ~ execute @e[type=mes:geyser] ~ ~ ~ execute @e[family=mob,family=!inac,r=2] ~ ~ ~ fill ~ ~ ~ ~ ~ ~ fire 0 replace air
execute @p[tag=geyser,scores={geysertime=15}] ~ ~ ~ execute @e[type=mes:geyser] ~ ~ ~ fill ^1 ^ ^ ^2 ^ ^ fire 0 replace air
execute @p[tag=geyser,scores={geysertime=15}] ~ ~ ~ execute @e[type=mes:geyser] ~ ~ ~ fill ^-1 ^ ^ ^-2 ^ ^ fire 0 replace air
execute @p[tag=geyser,scores={geysertime=15}] ~ ~ ~ execute @e[type=mes:geyser] ~ ~ ~ playanimation @e[type=mes:geyser] animation.geyser.monte
execute @p[tag=geyser,scores={geysertime=30}] ~ ~ ~ execute @e[type=mes:geyser] ~ ~ ~ tp @s ^ ^ ^-1
execute @p[tag=geyser,scores={geysertime=30}] ~ ~ ~ execute @e[type=mes:geyser] ~ ~ ~ effect @e[family=mob,family=!inac,r=2] fatal_poison 4 255 true
execute @p[tag=geyser,scores={geysertime=30}] ~ ~ ~ execute @e[type=mes:geyser] ~ ~ ~ execute @e[family=mob,family=!inac,r=2] ~ ~ ~ fill ~ ~ ~ ~ ~ ~ fire 0 replace air
execute @p[tag=geyser,scores={geysertime=30}] ~ ~ ~ execute @e[type=mes:geyser] ~ ~ ~ fill ^1 ^ ^ ^2 ^ ^ fire 0 replace air
execute @p[tag=geyser,scores={geysertime=30}] ~ ~ ~ execute @e[type=mes:geyser] ~ ~ ~ fill ^-1 ^ ^ ^-2 ^ ^ fire 0 replace air
execute @p[tag=geyser,scores={geysertime=30}] ~ ~ ~ execute @e[type=mes:geyser] ~ ~ ~ playanimation @e[type=mes:geyser] animation.geyser.monte
execute @p[tag=geyser,scores={geysertime=45}] ~ ~ ~ execute @e[type=mes:geyser] ~ ~ ~ tp @s ^ ^ ^-1
execute @p[tag=geyser,scores={geysertime=45}] ~ ~ ~ execute @e[type=mes:geyser] ~ ~ ~ effect @e[family=mob,family=!inac,r=2] fatal_poison 4 255 true
execute @p[tag=geyser,scores={geysertime=45}] ~ ~ ~ execute @e[type=mes:geyser] ~ ~ ~ execute @e[family=mob,family=!inac,r=2] ~ ~ ~ fill ~ ~ ~ ~ ~ ~ fire 0 replace air
execute @p[tag=geyser,scores={geysertime=45}] ~ ~ ~ execute @e[type=mes:geyser] ~ ~ ~ fill ^1 ^ ^ ^2 ^ ^ fire 0 replace air
execute @p[tag=geyser,scores={geysertime=45}] ~ ~ ~ execute @e[type=mes:geyser] ~ ~ ~ fill ^-1 ^ ^ ^-2 ^ ^ fire 0 replace air
execute @p[tag=geyser,scores={geysertime=45}] ~ ~ ~ execute @e[type=mes:geyser] ~ ~ ~ playanimation @e[type=mes:geyser] animation.geyser.monte
execute @p[tag=geyser,scores={geysertime=60}] ~ ~ ~ execute @e[type=mes:geyser] ~ ~ ~ tp @s ^ ^ ^-1
execute @p[tag=geyser,scores={geysertime=60}] ~ ~ ~ execute @e[type=mes:geyser] ~ ~ ~ effect @e[family=mob,family=!inac,r=2] fatal_poison 4 255 true
execute @p[tag=geyser,scores={geysertime=60}] ~ ~ ~ execute @e[type=mes:geyser] ~ ~ ~ execute @e[family=mob,family=!inac,r=2] ~ ~ ~ fill ~ ~ ~ ~ ~ ~ fire 0 replace air
execute @p[tag=geyser,scores={geysertime=60}] ~ ~ ~ execute @e[type=mes:geyser] ~ ~ ~ fill ^1 ^ ^ ^2 ^ ^ fire 0 replace air
execute @p[tag=geyser,scores={geysertime=60}] ~ ~ ~ execute @e[type=mes:geyser] ~ ~ ~ fill ^-1 ^ ^ ^-2 ^ ^ fire 0 replace air
execute @p[tag=geyser,scores={geysertime=60}] ~ ~ ~ execute @e[type=mes:geyser] ~ ~ ~ playanimation @e[type=mes:geyser] animation.geyser.monte
execute @p[tag=geyser,scores={geysertime=75}] ~ ~ ~ execute @e[type=mes:geyser] ~ ~ ~ tp @s ^ ^ ^-1
execute @p[tag=geyser,scores={geysertime=75}] ~ ~ ~ execute @e[type=mes:geyser] ~ ~ ~ effect @e[family=mob,family=!inac,r=2] fatal_poison 4 255 true
execute @p[tag=geyser,scores={geysertime=75}] ~ ~ ~ execute @e[type=mes:geyser] ~ ~ ~ execute @e[family=mob,family=!inac,r=2] ~ ~ ~ fill ~ ~ ~ ~ ~ ~ fire 0 replace air
execute @p[tag=geyser,scores={geysertime=75}] ~ ~ ~ execute @e[type=mes:geyser] ~ ~ ~ fill ^1 ^ ^ ^2 ^ ^ fire 0 replace air
execute @p[tag=geyser,scores={geysertime=75}] ~ ~ ~ execute @e[type=mes:geyser] ~ ~ ~ fill ^-1 ^ ^ ^-2 ^ ^ fire 0 replace air
execute @p[tag=geyser,scores={geysertime=75}] ~ ~ ~ execute @e[type=mes:geyser] ~ ~ ~ playanimation @e[type=mes:geyser] animation.geyser.monte
execute @p[tag=geyser,scores={geysertime=90}] ~ ~ ~ execute @e[type=mes:geyser] ~ ~ ~ tp @s ^ ^ ^-1
execute @p[tag=geyser,scores={geysertime=90}] ~ ~ ~ execute @e[type=mes:geyser] ~ ~ ~ effect @e[family=mob,family=!inac,r=2] fatal_poison 4 255 true
execute @p[tag=geyser,scores={geysertime=90}] ~ ~ ~ execute @e[type=mes:geyser] ~ ~ ~ execute @e[family=mob,family=!inac,r=2] ~ ~ ~ fill ~ ~ ~ ~ ~ ~ fire 0 replace air
execute @p[tag=geyser,scores={geysertime=90}] ~ ~ ~ execute @e[type=mes:geyser] ~ ~ ~ fill ^1 ^ ^ ^2 ^ ^ fire 0 replace air
execute @p[tag=geyser,scores={geysertime=90}] ~ ~ ~ execute @e[type=mes:geyser] ~ ~ ~ fill ^-1 ^ ^ ^-2 ^ ^ fire 0 replace air
execute @p[tag=geyser,scores={geysertime=90}] ~ ~ ~ execute @e[type=mes:geyser] ~ ~ ~ playanimation @e[type=mes:geyser] animation.geyser.monte
execute @p[tag=geyser,scores={geysertime=107}] ~ ~ ~ particle mes:volcano_explode ~ ~1 ~
execute @p[tag=geyser,scores={geysertime=107}] ~ ~ ~ execute @e[type=mes:geyser] ~ ~ ~ fill ~-10 ~-1 ~-10 ~10 ~2 ~10 air 0 replace fire
execute @p[tag=geyser,scores={geysertime=107}] ~ ~ ~ playsound cauldron.explode @a[r=10]
execute @p[tag=geyser,scores={geysertime=108}] ~ ~ ~ execute @e[type=mes:geyser] ~ ~ ~ tp @s ~ ~-100 ~
execute @p[tag=geyser,scores={geysertime=110}] ~ ~ ~ execute @e[type=mes:geyser] ~ ~ ~ kill @s
execute @p[tag=geyser,scores={geysertime=110}] ~ ~ ~ event entity @s mes:cooldown_off
tag @p[tag=geyser,scores={geysertime=110}] remove geyser
scoreboard players set @p[r=1,scores={geysertime=110}] geysertime 0



scoreboard players add @p[r=1,tag=lava] lavatime 1
execute @a[tag=lava,scores={lavatime=1}] ~ ~ ~ playsound sw.music.fire_ability_2 @a[r=10]
execute @a[tag=lava,scores={lavatime=16..240,book=1}] ~ ~ ~ event entity @s mes:cooldown_on
execute @a[tag=lava,scores={lavatime=1}] ~ ~ ~ summon mes:lava ~ ~-100 ~
execute @a[tag=lava,scores={lavatime=1}] ~ ~ ~ execute @e[family=mob,family=!inac,r=10] ~ ~ ~ fill ~ ~ ~ ~ ~ ~ fire 0 replace air
execute @a[tag=lava,scores={lavatime=1}] ~ ~ ~ effect @e[family=mob,r=4] slowness 2 255 true
execute @a[tag=lava,scores={lavatime=1}] ~ ~ ~ effect @e[type=mes:lava] invisibility 100 255 true
execute @a[tag=lava,scores={lavatime=1}] ~ ~ ~ tp @e[type=mes:lava] ^ ^1 ^2.8 facing @p[tag=lava]
execute @a[tag=lava,scores={lavatime=4}] ~ ~ ~ effect @e[type=mes:lava] clear
execute @a[tag=lava,scores={lavatime=5}] ~ ~ ~ playanimation @e[type=mes:lava] animation.lava.spawn
execute @a[tag=lava,scores={lavatime=80}] ~ ~ ~ playanimation @e[type=mes:lava] animation.lava.break1 f 1000
execute @a[tag=lava,scores={lavatime=87}] ~ ~ ~ execute @e[family=mob,family=!inac,r=10] ~ ~ ~ fill ~ ~ ~ ~ ~ ~ fire 0 replace air
execute @a[tag=lava,scores={lavatime=87}] ~ ~ ~ execute @e[type=mes:lava] ~ ~ ~ particle minecraft:large_explosion ~ ~2 ~
execute @a[tag=lava,scores={lavatime=87}] ~ ~ ~ playsound cauldron.explode @a[r=10]
execute @a[tag=lava,scores={lavatime=160}] ~ ~ ~ playanimation @e[type=mes:lava] animation.lava.break2 f 1000
execute @a[tag=lava,scores={lavatime=167}] ~ ~ ~ execute @e[type=mes:lava] ~ ~ ~ particle minecraft:large_explosion ~ ~1 ~
execute @a[tag=lava,scores={lavatime=167}] ~ ~ ~ playsound cauldron.explode @a[r=10]
execute @a[tag=lava,scores={lavatime=167}] ~ ~ ~ execute @e[family=mob,family=!inac,r=10] ~ ~ ~ fill ~ ~ ~ ~ ~ ~ fire 0 replace air
execute @a[tag=lava,scores={lavatime=229}] ~ ~ ~ playanimation @e[type=mes:lava] animation.lava.break3 f 1000
execute @a[tag=lava,scores={lavatime=238}] ~ ~ ~ particle mes:volcano_explode ~ ~1 ~
execute @a[tag=lava,scores={lavatime=238}] ~ ~ ~ playsound cauldron.explode @a[r=10]
execute @a[tag=lava,scores={lavatime=238}] ~ ~ ~ execute @e[family=mob,family=!inac,r=10] ~ ~ ~ fill ~ ~ ~ ~ ~ ~ fire 0 replace air
execute @a[tag=lava,scores={lavatime=240}] ~ ~ ~ tp @e[type=mes:lava] ~ ~-100 ~
execute @a[tag=lava,scores={lavatime=241}] ~ ~ ~ kill @e[type=mes:lava]
execute @a[tag=lava,scores={lavatime=241}] ~ ~ ~ event entity @s mes:cooldown_off
execute @a[tag=lava,scores={lavatime=241}] ~ ~ ~ fill ~-10 ~-1 ~-10 ~10 ~2 ~10 air 0 replace fire
tag @a[tag=lava,scores={lavatime=241}] remove lava
scoreboard players set @p[r=1,scores={lavatime=241}] lavatime 0

execute @a[tag=lava,scores={lavatime=1..87}] ~ ~ ~ execute @e[type=mes:lava] ~ ~ ~ particle minecraft:basic_flame_particle ^1.3 ^3.3 ^
execute @a[tag=lava,scores={lavatime=1..87}] ~ ~ ~ execute @e[type=mes:lava] ~ ~ ~ particle minecraft:basic_flame_particle ^ ^3.3 ^
execute @a[tag=lava,scores={lavatime=1..87}] ~ ~ ~ execute @e[type=mes:lava] ~ ~ ~ particle minecraft:basic_flame_particle ^-1.3 ^3.3 ^
execute @a[tag=lava,scores={lavatime=87..167}] ~ ~ ~ execute @e[type=mes:lava] ~ ~ ~ particle minecraft:basic_flame_particle ^1.3 ^2.3 ^
execute @a[tag=lava,scores={lavatime=87..167}] ~ ~ ~ execute @e[type=mes:lava] ~ ~ ~ particle minecraft:basic_flame_particle ^ ^2.3 ^
execute @a[tag=lava,scores={lavatime=87..167}] ~ ~ ~ execute @e[type=mes:lava] ~ ~ ~ particle minecraft:basic_flame_particle ^-1.3 ^2.3 ^
execute @a[tag=lava,scores={lavatime=167..229}] ~ ~ ~ execute @e[type=mes:lava] ~ ~ ~ particle minecraft:basic_flame_particle ^1.3 ^1.3 ^
execute @a[tag=lava,scores={lavatime=167..229}] ~ ~ ~ execute @e[type=mes:lava] ~ ~ ~ particle minecraft:basic_flame_particle ^ ^1.3 ^
execute @a[tag=lava,scores={lavatime=167..229}] ~ ~ ~ execute @e[type=mes:lava] ~ ~ ~ particle minecraft:basic_flame_particle ^-1.3 ^1.3 ^



scoreboard players add @p[r=1,tag=volcano] volcanotime 1
execute @a[tag=volcano,scores={volcanotime=1}] ~ ~ ~ playsound sw.music.fire_ability @a[r=20]
execute @a[tag=volcano,scores={volcanotime=16..100,book=4}] ~ ~ ~ event entity @s mes:cooldown_on
execute @a[tag=volcano,scores={volcanotime=1}] ~ ~ ~ summon mes:volcano ^ ^1.8 ^5 
execute @a[tag=volcano,scores={volcanotime=1..5}] ~ ~ ~ execute @e[type=mes:volcano] ~ ~ ~ detect ~ ~-0.5 ~ air 0 tp @s ~ ~-0.5 ~
execute @a[tag=volcano,scores={volcanotime=1}] ~ ~ ~ effect @e[type=mes:volcano] invisibility 1 255 true
execute @a[tag=volcano,scores={volcanotime=3}] ~ ~ ~ effect @e[type=mes:volcano] invisibility 0
execute @a[tag=volcano,scores={volcanotime=3}] ~ ~ ~ playanimation @e[type=mes:volcano] animation.volcano.start f 100
execute @a[tag=volcano,scores={volcanotime=1..94}] ~ ~ ~ execute @e[type=mes:volcano] ~ ~ ~ execute @e[type=!player,family=!inac,family=!npc,type=!item,r=15,family=mob,type=!mes:volcano] ~ ~ ~ fill ~ ~ ~ ~ ~ ~ fire 0 replace air 0
execute @a[tag=volcano,scores={volcanotime=1..85}] ~ ~ ~ execute @e[type=mes:volcano] ~ ~ ~ particle mes:volcano ~ ~2 ~
execute @a[tag=volcano,scores={volcanotime=24}] ~ ~ ~ execute @e[type=mes:volcano] ~ ~ ~ particle mes:volcano_explode ~ ~2 ~
execute @a[tag=volcano,scores={volcanotime=44}] ~ ~ ~ execute @e[type=mes:volcano] ~ ~ ~ particle mes:volcano_explode ~ ~2 ~
execute @a[tag=volcano,scores={volcanotime=64}] ~ ~ ~ execute @e[type=mes:volcano] ~ ~ ~ particle mes:volcano_explode ~ ~2 ~
execute @a[tag=volcano,scores={volcanotime=94}] ~ ~ ~ execute @e[type=mes:volcano] ~ ~ ~ particle mes:volcano_explode ~ ~2 ~
execute @a[tag=volcano,scores={volcanotime=24}] ~ ~ ~ execute @e[type=mes:volcano] ~ ~ ~ playsound cauldron.explode @a[r=15]
execute @a[tag=volcano,scores={volcanotime=44}] ~ ~ ~ execute @e[type=mes:volcano] ~ ~ ~ playsound cauldron.explode @a[r=15]
execute @a[tag=volcano,scores={volcanotime=64}] ~ ~ ~ execute @e[type=mes:volcano] ~ ~ ~ playsound cauldron.explode @a[r=15]
execute @a[tag=volcano,scores={volcanotime=94}] ~ ~ ~ execute @e[type=mes:volcano] ~ ~ ~ playsound cauldron.explode @a[r=15]
execute @a[tag=volcano,scores={volcanotime=24}] ~ ~ ~ execute @e[type=mes:volcano] ~ ~ ~ execute @e[type=!player,family=!inac,family=!npc,type=!item,r=15,family=mob,type=!mes:volcano] ~ ~ ~ summon mes:miniinstanttnt
execute @a[tag=volcano,scores={volcanotime=44}] ~ ~ ~ execute @e[type=mes:volcano] ~ ~ ~ execute @e[type=!player,family=!inac,family=!npc,type=!item,r=15,family=mob,type=!mes:volcano] ~ ~ ~ summon mes:miniinstanttnt
execute @a[tag=volcano,scores={volcanotime=64}] ~ ~ ~ execute @e[type=mes:volcano] ~ ~ ~ execute @e[type=!player,family=!inac,family=!npc,type=!item,r=15,family=mob,type=!mes:volcano] ~ ~ ~ summon mes:miniinstanttnt
execute @a[tag=volcano,scores={volcanotime=94}] ~ ~ ~ execute @e[type=mes:volcano] ~ ~ ~ execute @e[type=!player,family=!inac,family=!npc,type=!item,r=15,family=mob,type=!mes:volcano] ~ ~ ~ summon mes:miniinstanttnt
execute @a[tag=volcano,scores={volcanotime=94}] ~ ~ ~ execute @e[type=mes:volcano] ~ ~ ~ tp @s ~ ~-100 ~
execute @a[tag=volcano,scores={volcanotime=94}] ~ ~ ~ fill ~-10 ~-1 ~-10 ~10 ~2 ~10 air 0 replace fire
execute @a[tag=volcano,scores={volcanotime=100}] ~ ~ ~ kill @e[type=mes:volcano]
execute @a[tag=volcano,scores={volcanotime=101}] ~ ~ ~ event entity @s mes:cooldown_off
tag @a[tag=volcano,scores={volcanotime=101}] remove volcano
scoreboard players set @p[r=1,scores={volcanotime=101}] volcanotime 0

execute @e[type=mes:volcano,tag=!playanim] ~ ~ ~ playanimation @s animation.volcano.spawn
execute @e[type=mes:volcano,tag=!playanim] ~ ~ ~ tag @s add playanim


scoreboard players add @p[r=1,tag=snowman] maelstromtime 1
execute @a[tag=snowman,scores={maelstromtime=16..148,book=1}] ~ ~ ~ event entity @s mes:cooldown_on
execute @p[tag=snowman,scores={maelstromtime=1}] ~ ~ ~ summon minecraft:snow_golem
execute @p[tag=snowman,scores={maelstromtime=1..}] ~ ~ ~ execute @e[type=minecraft:snow_golem,r=10] ~ ~ ~ particle mes:snowman ~ ~ ~
execute @p[tag=snowman,scores={maelstromtime=1}] ~ ~ ~ spreadplayers ~ ~ 7 10 @p
execute @p[tag=snowman,scores={maelstromtime=2}] ~ ~ ~ tp @s ~ ~ ~ facing @e[type=snow_golem]
execute @p[tag=snowman,scores={maelstromtime=2}] ~ ~ ~ particle mes:frost_poof ~ ~ ~
execute @p[tag=snowman,scores={maelstromtime=2}] ~ ~ ~ effect @e[type=snow_golem] slowness 7 255 true
execute @p[tag=snowman,scores={maelstromtime=2}] ~ ~ ~ effect @e[type=snow_golem] resistance 7 5 true
execute @p[tag=snowman,scores={maelstromtime=1}] ~ ~ ~ playsound mob.snowgolem.death @a[r=20]
execute @p[tag=snowman,scores={maelstromtime=150}] ~ ~ ~ tp @e[type=minecraft:snow_golem] ~ ~-100 ~
execute @p[tag=snowman,scores={maelstromtime=150}] ~ ~ ~ playsound mob.snowgolem.death @a[r=20]
execute @a[tag=snowman,scores={maelstromtime=150}] ~ ~ ~ event entity @s mes:cooldown_off
tag @p[tag=snowman,scores={maelstromtime=150}] add revmsnow
tag @p[tag=snowman,scores={maelstromtime=150}] remove snowman
scoreboard players set @p[tag=revmsnow,scores={maelstromtime=150}] maelstromtime 0
tag @p remove revmsnow


scoreboard players add @p[r=1,tag=hydroblaster] maelstromtime 1
execute @p[tag=hydroblaster,scores={maelstromtime=1}] ~ ~ ~ execute @e[r=10,type=!mes:maelstrom,type=!item,type=!player,family=!inac,family=!npc,family=mob] ~ ~ ~ tag @p[tag=hydroblaster] add yes
execute @p[tag=hydroblaster,scores={maelstromtime=1}] ~ ~ ~ titleraw @p[tag=hydroblaster,tag=!yes] actionbar { "rawtext" : [ { "translate" : "noone.text" } ] }
execute @p[tag=hydroblaster,scores={maelstromtime=1}] ~ ~ ~ scoreboard players set @p[tag=hydroblaster,tag=!yes] maelstromtime 49
execute @p[tag=hydroblaster,scores={maelstromtime=1}] ~ ~ ~ execute @e[r=10,type=!mes:maelstrom,type=!item,type=!player,family=!inac,family=!npc,family=mob] ~ ~ ~ particle mes:hydroblast
execute @p[tag=hydroblaster,scores={maelstromtime=1}] ~ ~ ~ execute @e[r=10,type=!mes:maelstrom,type=!item,type=!player,family=!inac,family=!npc,family=mob] ~ ~ ~ particle mes:hydroblast_bubble
execute @p[tag=hydroblaster,scores={maelstromtime=1}] ~ ~ ~ execute @e[r=10,type=!mes:maelstrom,type=!item,type=!player,family=!inac,family=!npc,family=mob] ~ ~ ~ effect @s levitation 1 25 true
execute @p[tag=hydroblaster,scores={maelstromtime=1}] ~ ~ ~ playsound mob.breeze.charge @a[r=20]
execute @p[tag=hydroblaster,scores={maelstromtime=5}] ~ ~ ~ tag @a[tag=hydroblaster] remove yes
tag @p[tag=hydroblaster,scores={maelstromtime=50}] add removetimeblde
tag @p[tag=hydroblaster,scores={maelstromtime=50}] remove hydroblaster
scoreboard players set @p[tag=removetimeblde,scores={maelstromtime=50}] maelstromtime 0
tag @p remove removetimeblde

scoreboard players add @p[r=1,tag=maelstrom] maelstromtime 1
execute @p[r=1,scores={maelstromtime=16..99,book=1},tag=maelstrom] ~ ~ ~ event entity @s mes:cooldown_on
execute @p[r=1,scores={maelstromtime=1},tag=maelstrom] ~ ~ ~ summon mes:maelstrom ^ ^2 ^5
execute @p[r=1,scores={maelstromtime=1},tag=maelstrom] ~ ~ ~ playsound firework.shoot @p[r=10]
execute @p[r=1,scores={maelstromtime=13},tag=maelstrom] ~ ~ ~ playsound mob.breeze.idle_ground @a[r=10]
execute @p[r=1,scores={maelstromtime=80},tag=maelstrom] ~ ~ ~ playsound mob.breeze.inhale @a[r=10]
execute @e[type=mes:maelstrom] ~ ~ ~ particle mes:maelstrom ~ ~ ~
execute @e[type=mes:maelstrom] ~ ~ ~ execute @e[r=16,family=mob,type=!mes:maelstrom,type=!item,tag=!maelstrom,type=!player,family=!inac,family=!npc,type=!armor_stand] ~ ~ ~ tp @s ^ ^0.15 ^0.35 facing @e[type=mes:maelstrom]
execute @p[r=1,scores={maelstromtime=100..},tag=maelstrom] ~ ~ ~ execute @e[type=mes:maelstrom] ~ ~ ~ effect @e[r=16,type=!mes:maelstrom,family=mob,type=!item,tag=!maelstrom] instant_damage 2 255 true
execute @p[r=1,scores={maelstromtime=100..},tag=maelstrom] ~ ~ ~ execute @e[type=mes:maelstrom] ~ ~ ~ particle mes:bubble_air ~ ~2 ~
execute @p[r=1,scores={maelstromtime=100..},tag=maelstrom] ~ ~ ~ execute @e[type=mes:maelstrom] ~ ~ ~ particle mes:bubble_air ~ ~3 ~
execute @p[r=1,scores={maelstromtime=100..},tag=maelstrom] ~ ~ ~ playsound cauldron.explode @a[r=20]
execute @p[r=1,scores={maelstromtime=100..},tag=maelstrom] ~ ~ ~ execute @e[type=mes:maelstrom] ~ ~ ~ kill @s
execute @p[r=1,scores={maelstromtime=100..},tag=maelstrom] ~ ~ ~ event entity @s mes:cooldown_off
tag @p[r=1,scores={maelstromtime=100..},tag=maelstrom] add removetimec
tag @p[r=1,scores={maelstromtime=100..},tag=maelstrom] remove maelstrom
scoreboard players set @p[r=1,tag=removetimec,scores={maelstromtime=100..}] maelstromtime 0
tag @p remove removetimec


scoreboard players add @p[r=1,tag=bubble] bubbletime 1
execute @a[tag=bubble,scores={bubbletime=16..34,book=2}] ~ ~ ~ event entity @s mes:cooldown_on
execute @p[tag=bubble,scores={bubbletime=1}] ~ ~ ~ particle mes:bubble_launch ^ ^1 ^1.2
execute @p[tag=bubble,scores={bubbletime=1}] ~ ~ ~ playsound mob.breeze.slide @a[r=5]
execute @p[tag=bubble,scores={bubbletime=1}] ~ ~ ~ event entity @p[tag=bubble] sp:n_bubble_shoot
execute @p[tag=bubble,scores={bubbletime=35}] ~ ~ ~ particle mes:bubble ~ ~1.5 ~
execute @p[tag=bubble,scores={bubbletime=35}] ~ ~ ~ kill @e[type=mes:bubble_shoot]
execute @p[tag=bubble,scores={bubbletime=35}] ~ ~ ~ event entity @s mes:cooldown_off
tag @p[tag=bubble,scores={bubbletime=35}] remove bubble
scoreboard players set @p[r=1,scores={bubbletime=35}] bubbletime 0

execute @e[type=mes:bubble_shoot] ~ ~ ~ particle mes:bubble_launch ~ ~ ~
execute @e[type=mes:bubble_shoot] ~ ~ ~ tp @e[family=mob,type=!player,r=4] ~ ~ ~
execute @e[type=mes:bubble_shoot] ~ ~ ~ effect @e[family=mob,type=!player,r=4] fatal_poison 3 255 true

scoreboard players add @p[r=1,tag=water] maelstromtime 1
execute @a[tag=water,scores={maelstromtime=16..99,book=4}] ~ ~ ~ event entity @p[tag=water] mes:cooldown_on
execute @p[tag=water,scores={maelstromtime=1}] ~ ~ ~ effect @p fire_resistance 5 255 true
execute @p[tag=water,scores={maelstromtime=1}] ~ ~ ~ playsound cauldron.takewater @a[r=10]
execute @p[tag=water,scores={maelstromtime=35}] ~ ~ ~ playsound mob.breeze.idle_air @a[r=10]
execute @p[tag=water,scores={maelstromtime=1}] ~ ~ ~ summon mes:water ~ ~ ~
execute @p[tag=water,scores={maelstromtime=1..}] ~ ~ ~ execute @e[type=mes:water] ~ ~ ~ particle mes:water ~ ~ ~
execute @p[tag=water,scores={maelstromtime=1..}] ~ ~ ~ execute @e[type=mes:water] ~ ~ ~ execute @e[family=mob,type=!mes:water,r=10] ~ ~ ~ tp @s ^ ^0.5 ^-0.4 facing @e[type=mes:water]
execute @p[tag=water,scores={maelstromtime=97}] ~ ~ ~ execute @e[type=mes:water] ~ ~ ~ particle mes:bubble ~ ~3 ~
execute @p[tag=water,scores={maelstromtime=97}] ~ ~ ~ execute @e[type=mes:water] ~ ~ ~ playsound cauldron.explode @a[r=15]
execute @p[tag=water,scores={maelstromtime=98}] ~ ~ ~ tp @e[type=mes:water] ~ ~-100 ~
execute @p[tag=water,scores={maelstromtime=100}] ~ ~ ~ kill @e[type=mes:water]
execute @p[tag=water,scores={maelstromtime=100}] ~ ~ ~ event entity @p[tag=water] mes:cooldown_off
tag @p[tag=water,scores={maelstromtime=100}] add revww
tag @p[tag=water,scores={maelstromtime=100}] remove water
scoreboard players set @p[tag=revww,scores={maelstromtime=100}] maelstromtime 0
tag @p[r=1] remove revww


scoreboard players add @p[r=1,tag=icelance] icelancetime 1
execute @p[tag=icelance,scores={icelancetime=1}] ~ ~ ~ particle mes:icelance_launch ^ ^1 ^1.2
execute @p[tag=icelance,scores={icelancetime=1}] ~ ~ ~ effect @a[r=5,tag=small] speed 5 1 true
execute @p[tag=icelance,scores={icelancetime=1}] ~ ~ ~ effect @a[r=5,tag=medium] speed 5 2 true
execute @p[tag=icelance,scores={icelancetime=1}] ~ ~ ~ effect @a[r=5,tag=big] speed 5 4 true
execute @p[tag=icelance,scores={icelancetime=1}] ~ ~ ~ playsound sw.music.banished_ability @a[r=5] 
execute @p[tag=icelance,scores={icelancetime=1}] ~ ~ ~ event entity @p[tag=icelance] sp:n_icelance_shoot
execute @p[tag=icelance,scores={icelancetime=6},tag=small] ~ ~ ~ playanimation @e[type=mes:icelance_shoot] animation.icelance.small
execute @p[tag=icelance,scores={icelancetime=6},tag=medium] ~ ~ ~ playanimation @e[type=mes:icelance_shoot] animation.icelance.medium
execute @p[tag=icelance,scores={icelancetime=6},tag=big] ~ ~ ~ playanimation @e[type=mes:icelance_shoot] animation.icelance.big
execute @p[tag=icelance,scores={icelancetime=1..}] ~ ~ ~ effect @e[family=mob,type=!player,r=6] slowness 5 255 true
execute @p[tag=icelance,scores={icelancetime=35}] ~ ~ ~ execute @e[type=mes:icelance_shoot] ~ ~ ~ particle mes:icelance_explode
execute @p[tag=icelance,scores={icelancetime=35}] ~ ~ ~ execute @e[type=mes:icelance_shoot] ~ ~ ~ particle mes:icelance_explode
execute @p[tag=icelance,scores={icelancetime=35}] ~ ~ ~ execute @e[type=mes:icelance_shoot] ~ ~ ~ summon mes:miniinstanttnt
execute @p[tag=icelance,scores={icelancetime=35},tag=big] ~ ~ ~ execute @e[type=mes:icelance_shoot] ~ ~ ~ summon mes:instanttnt
execute @p[tag=icelance,scores={icelancetime=35}] ~ ~ ~ playsound block.glass.break @a[r=20]
execute @p[tag=icelance,scores={icelancetime=35}] ~ ~ ~ kill @e[type=mes:icelance_shoot]
tag @p[tag=icelance,scores={icelancetime=35}] remove small
tag @p[tag=icelance,scores={icelancetime=35}] remove medium
tag @p[tag=icelance,scores={icelancetime=35}] remove big
tag @p[tag=icelance,scores={icelancetime=35}] remove icelance
scoreboard players set @p[r=1,scores={icelancetime=35}] icelancetime 0

execute @e[type=mes:icelance_shoot] ~ ~ ~ particle minecraft:falling_dust_top_snow_particle ~ ~ ~

scoreboard players add @p[r=1,tag=wave] maelstromtime 1
execute @a[tag=wave,scores={maelstromtime=16..110,book=0}] ~ ~ ~ event entity @s mes:cooldown_on
execute @a[tag=wave,scores={maelstromtime=1}] ~ ~ ~ playsound bucket.fill_water @a[r=10]
execute @a[tag=wave,scores={maelstromtime=1}] ~ ~ ~ summon mes:nothing ~ ~ ~
execute @a[tag=wave,scores={maelstromtime=1}] ~ ~ ~ summon mes:wave ~ ~-100 ~
execute @a[tag=wave,scores={maelstromtime=2}] ~ ~ ~ particle mes:wave_launch ^ ^1 ^1
execute @a[tag=wave,scores={maelstromtime=1}] ~ ~ ~ effect @e[family=mob,r=4] slowness 2 255 true
execute @a[tag=wave,scores={maelstromtime=1}] ~ ~ ~ effect @e[type=mes:wave] invisibility 100 255 true
execute @a[tag=wave,scores={maelstromtime=1}] ~ ~ ~ tp @e[type=mes:wave] ^ ^1 ^2 facing @p[tag=wave]
execute @a[tag=wave,scores={maelstromtime=1..7}] ~ ~ ~ execute @e[type=mes:wave] ~ ~ ~ detect ~ ~-0.3 ~ air 0 tp @s ~ ~-0.3 ~
execute @a[tag=wave,scores={maelstromtime=8..}] ~ ~ ~ execute @e[type=mes:wave] ~ ~ ~ detect ~ ~-0.1 ~ air 0 tp @s ~ ~-0.1 ~
execute @a[tag=wave,scores={maelstromtime=6}] ~ ~ ~ effect @e[type=mes:wave] clear
execute @a[tag=wave,scores={maelstromtime=6}] ~ ~ ~ playanimation @e[type=mes:wave] animation.wave.start
execute @a[tag=wave,scores={maelstromtime=8}] ~ ~ ~ playsound liquid.water @a[r=10]
execute @a[tag=wave,scores={maelstromtime=30}] ~ ~ ~ playsound liquid.water @a[r=10]
execute @a[tag=wave,scores={maelstromtime=70}] ~ ~ ~ playsound liquid.water @a[r=10]
execute @a[tag=wave,scores={maelstromtime=8..}] ~ ~ ~ execute @e[type=mes:wave] ~ ~ ~ tp @s ^ ^ ^-0.42 facing @e[type=mes:nothing]
execute @a[tag=wave,scores={maelstromtime=8..}] ~ ~ ~ execute @e[type=mes:wave] ~ ~ ~ tp @e[family=mob,family=!inac,family=!npc,r=3] ^ ^ ^-0.80
execute @a[tag=wave,scores={maelstromtime=108}] ~ ~ ~ tp @e[type=mes:nothing] ~ ~-100 ~
execute @a[tag=wave,scores={maelstromtime=108}] ~ ~ ~ execute @e[type=mes:wave] ~ ~ ~ playsound cauldron.explode @a ~ ~ ~
execute @a[tag=wave,scores={maelstromtime=108}] ~ ~ ~ execute @e[type=mes:wave] ~ ~ ~ particle mes:bubble ~ ~2 ~
execute @a[tag=wave,scores={maelstromtime=108}] ~ ~ ~ execute @e[type=mes:wave] ~ ~ ~ tp @s ~ ~-100 ~
execute @a[tag=wave,scores={maelstromtime=112}] ~ ~ ~ kill @e[type=mes:wave]
execute @a[tag=wave,scores={maelstromtime=112}] ~ ~ ~ kill @e[type=mes:nothing]
execute @a[tag=wave,scores={maelstromtime=112}] ~ ~ ~ event entity @s mes:cooldown_off
tag @a[tag=wave,scores={maelstromtime=112}] add revww
tag @a[tag=wave,scores={maelstromtime=112}] remove wave
scoreboard players set @p[tag=revww,scores={maelstromtime=112}] maelstromtime 0
tag @p remove revww

execute @a[tag=wave,scores={maelstromtime=1..111}] ~ ~ ~ execute @e[type=mes:wave] ~ ~ ~ particle mes:wave
execute @a[tag=wave,scores={maelstromtime=8..111}] ~ ~ ~ execute @e[type=mes:wave] ~ ~ ~ particle mes:wave_launch ^ ^ ^1






scoreboard players add @p[r=1,tag=stone_fists] stonetime 1
execute @p[tag=stone_fists,scores={stonetime=16..120,book=0}] ~ ~ ~ event entity @s mes:cooldown_on
execute @p[tag=stone_fists,scores={stonetime=1}] ~ ~ ~ playsound sw.music.fire_ability @a[r=20]
execute @p[tag=stone_fists,scores={stonetime=1}] ~ ~ ~ summon mes:stone_boulder ^1 ^1.5 ^2
execute @p[tag=stone_fists,scores={stonetime=1}] ~ ~ ~ summon mes:stone_boulder ^-1 ^1.5 ^2
execute @p[tag=stone_fists,scores={stonetime=1}] ~ ~ ~ titleraw @p[tag=stone_fists] actionbar { "rawtext" : [ { "translate" : "stoneboulder.punch" } ] }
execute @p[tag=stone_fists,scores={stonetime=120}] ~ ~ ~ event entity @s mes:cooldown_off
tag @p[tag=stone_fists,scores={stonetime=120}] remove stone_fists
scoreboard players set @p[r=1,scores={stonetime=120}] stonetime 0

scoreboard players add @e[type=mes:stone_boulder] stonetime 1
execute @e[type=mes:stone_boulder] ~ ~ ~ particle mes:stone_boulder_ambient ~ ~ ~
execute @e[type=mes:stone_boulder,scores={stonetime=116}] ~ ~ ~ effect @a resistance 2 255 true
execute @e[type=mes:stone_boulder,scores={stonetime=120}] ~ ~ ~ playsound random.explode @a[r=30]
execute @e[type=mes:stone_boulder,scores={stonetime=120}] ~ ~ ~ summon mes:instanttnt
execute @e[type=mes:stone_boulder,scores={stonetime=120}] ~ ~ ~ summon mes:instanttnt
execute @e[type=mes:stone_boulder,scores={stonetime=120}] ~ ~ ~ particle mes:stone_boulder_explode ~ ~ ~
execute @e[type=mes:stone_boulder,scores={stonetime=120}] ~ ~ ~ effect @e[r=8] instant_damage 3 1 true
execute @e[type=mes:stone_boulder,scores={stonetime=121}] ~ ~ ~ kill @s

scoreboard players add @p[r=1,tag=stone_body] stonebodytime 1
execute @p[tag=stone_body,scores={stonebodytime=16..1000,book=2}] ~ ~ ~ event entity @s mes:cooldown_on
execute @p[tag=stone_body,scores={stonebodytime=1}] ~ ~ ~ effect @p health_boost 30 4 true
execute @p[tag=stone_body,scores={stonebodytime=2}] ~ ~ ~ effect @p instant_health 1 255 true
execute @p[tag=stone_body,scores={stonebodytime=2}] ~ ~ ~ effect @p jump_boost 30 2 true
execute @p[tag=stone_body,scores={stonebodytime=1}] ~ ~ ~ playsound sw.music.heart_ability @a[r=20]
execute @p[tag=stone_body,scores={stonebodytime=1001}] ~ ~ ~ event entity @s mes:cooldown_off
tag @p[tag=stone_body,scores={stonebodytime=1001}] add revstb
tag @p[tag=stone_body,scores={stonebodytime=1001}] remove stone_body
scoreboard players set @p[tag=revstb,scores={stonebodytime=1001}] stonebodytime 0
tag @p remove revstb

scoreboard players add @p[r=1,tag=avalanche] avalanchetime 1
execute @p[tag=avalanche,scores={avalanchetime=16..99,book=3}] ~ ~ ~ event entity @s mes:cooldown_on
execute @p[tag=avalanche,scores={avalanchetime=1}] ~ ~ ~ playsound sw.music.boulder_ability @a[r=20] 
execute @p[tag=avalanche,scores={avalanchetime=1}] ~ ~ ~ execute @e[r=15,family=mob,type=!mes:avalanche] ~ ~ ~ summon mes:avalanche ~ ~20 ~
execute @p[tag=avalanche,scores={avalanchetime=1}] ~ ~ ~ execute @e[r=15,family=mob,type=!mes:avalanche] ~ ~ ~ tag @p[tag=avalanche] add yes
execute @p[tag=avalanche,scores={avalanchetime=1}] ~ ~ ~ titleraw @p[tag=avalanche,tag=!yes] actionbar { "rawtext" : [ { "translate" : "noone.text" } ] }
execute @p[tag=avalanche,scores={avalanchetime=1}] ~ ~ ~ scoreboard players set @p[tag=avalanche,tag=!yes] avalanchetime 80
execute @p[tag=avalanche,scores={avalanchetime=1}] ~ ~ ~ effect @e[r=18,family=mob,type=!mes:avalanche] slowness 5 255 true
execute @p[tag=avalanche,scores={avalanchetime=2}] ~ ~ ~ playanimation @e[type=mes:avalanche] animation.avalanche.start
execute @p[tag=avalanche,scores={avalanchetime=1..}] ~ ~ ~ execute @e[r=15,family=mob,type=!mes:avalanche] ~ ~ ~ execute @e[type=mes:avalanche,r=1.5] ~ ~ ~ summon mes:miniinstanttnt ~ ~-1.5 ~
execute @p[tag=avalanche,scores={avalanchetime=1..}] ~ ~ ~ execute @e[r=15,family=mob,type=!mes:avalanche] ~ ~ ~ execute @e[type=mes:avalanche,r=1.5] ~ ~ ~ particle mes:avalanche_explode
execute @p[tag=avalanche,scores={avalanchetime=1..}] ~ ~ ~ execute @e[r=15,family=mob,type=!mes:avalanche] ~ ~ ~ execute @e[type=mes:avalanche,r=1.5] ~ ~ ~ effect @e[r=2,family=mob,type=!mes:avalanche] instant_damage 1 1 true
execute @p[tag=avalanche,scores={avalanchetime=1..}] ~ ~ ~ execute @e[r=15,family=mob,type=!mes:avalanche] ~ ~ ~ tp @e[type=mes:avalanche,r=1.5] ~ ~-100 ~
execute @p[tag=avalanche,scores={avalanchetime=80}] ~ ~ ~ tp @e[type=mes:avalanche] ~ ~-100 ~
execute @p[tag=avalanche,scores={avalanchetime=82}] ~ ~ ~ kill @e[type=mes:avalanche]
execute @p[tag=avalanche,scores={avalanchetime=5}] ~ ~ ~ tag @p[tag=avalanche] remove yes
execute @p[tag=avalanche,scores={avalanchetime=99}] ~ ~ ~ event entity @s mes:cooldown_off
tag @p[tag=avalanche,scores={avalanchetime=100}] remove avalanche
scoreboard players set @p[r=1,scores={avalanchetime=100}] avalanchetime 0

scoreboard players add @p[r=1,tag=entomb] entombtime 1
execute @p[tag=entomb,scores={entombtime=16..99,book=1}] ~ ~ ~ event entity @s mes:cooldown_on
execute @p[tag=entomb,scores={entombtime=1}] ~ ~ ~ playsound sw.music.boulder_ability @a[r=20]
execute @p[tag=entomb,scores={entombtime=1}] ~ ~ ~ execute @e[r=12,family=mob,rm=1] ~ ~ ~ summon mes:entomb
execute @p[tag=entomb,scores={entombtime=1}] ~ ~ ~ execute @e[r=12,family=mob,rm=1] ~ ~ ~ tag @p[tag=entomb] add yes
execute @p[tag=entomb,scores={entombtime=1}] ~ ~ ~ titleraw @p[tag=entomb,tag=!yes] actionbar { "rawtext" : [ { "translate" : "noone.text" } ] }
execute @p[tag=entomb,scores={entombtime=1}] ~ ~ ~ scoreboard players set @p[tag=entomb,tag=!yes] entombtime 80
execute @p[tag=entomb,scores={entombtime=1}] ~ ~ ~ effect @e[r=12,family=mob] slowness 6 255 true
execute @p[tag=entomb,scores={entombtime=3}] ~ ~ ~ playanimation @e[type=mes:entomb] animation.entomb.start
execute @p[tag=entomb,scores={entombtime=80}] ~ ~ ~ execute @e[r=12,family=mob] ~ ~ ~ summon mes:miniinstanttnt
execute @p[tag=entomb,scores={entombtime=80}] ~ ~ ~ execute @e[r=12,family=mob] ~ ~ ~ particle mes:stone_boulder_explode
execute @p[tag=entomb,scores={entombtime=81}] ~ ~ ~ tp @e[type=mes:entomb] ~ ~-100 ~
execute @p[tag=entomb,scores={entombtime=82}] ~ ~ ~ kill @e[type=mes:entomb]
execute @p[tag=entomb,scores={entombtime=5}] ~ ~ ~ tag @p[tag=entomb] remove yes
execute @p[tag=entomb,scores={entombtime=99}] ~ ~ ~ event entity @s mes:cooldown_off 
tag @p[tag=entomb,scores={entombtime=100}] remove entomb
scoreboard players set @p[r=1,scores={entombtime=100}] entombtime 0

scoreboard players add @p[r=1,tag=earthquake] earthquaketime 1
execute @p[tag=earthquake,scores={earthquaketime=16..99,book=4}] ~ ~ ~ event entity @s mes:cooldown_on
execute @p[tag=earthquake,scores={earthquaketime=1}] ~ ~ ~ effect @p resistance 5 255 true
execute @p[tag=earthquake,scores={earthquaketime=1}] ~ ~ ~ playsound sw.music.inferno_ability @a[r=20]
execute @p[tag=earthquake,scores={earthquaketime=1}] ~ ~ ~ particle mes:earthquake_launch ~ ~ ~
execute @p[tag=earthquake,scores={earthquaketime=9..40}] ~ ~ ~ particle mes:earthquake ~ ~ ~
execute @p[tag=earthquake,scores={earthquaketime=10}] ~ ~ ~ camerashake add @a[r=15] 1 1 positional
execute @p[tag=earthquake,scores={earthquaketime=10}] ~ ~ ~ effect @e[family=mob,family=!npc,type=!player,r=15] fatal_poison 4 255 true
execute @p[tag=earthquake,scores={earthquaketime=10}] ~ ~ ~ effect @e[family=mob,family=!npc,type=!player,r=15] slowness 4 255 true
execute @p[tag=earthquake,scores={earthquaketime=99}] ~ ~ ~ event entity @s mes:cooldown_off
tag @p[tag=earthquake,scores={earthquaketime=100}] remove earthquake
scoreboard players set @p[r=1,scores={earthquaketime=100}] earthquaketime 0

scoreboard players add @p[r=1,tag=skeleton] necrotime 1
execute @p[tag=skeleton,scores={necrotime=16..262,book=0}] ~ ~ ~ event entity @s mes:cooldown_on
execute @p[tag=skeleton,scores={necrotime=5}] ~ ~ ~ playsound mob.skeleton.say @a[r=15]
execute @p[tag=skeleton,scores={necrotime=1}] ~ ~ ~ playsound sw.music.inferno_ability @a[r=15]
execute @p[tag=skeleton,scores={necrotime=1}] ~ ~ ~ summon mes:nskeleton ~ ~-2.1 ~2
execute @p[tag=skeleton,scores={necrotime=1}] ~ ~ ~ summon mes:nskeleton ~ ~-2.1 ~-2
execute @p[tag=skeleton,scores={necrotime=1}] ~ ~ ~ summon mes:nskeleton ~2 ~-2.1 ~
execute @p[tag=skeleton,scores={necrotime=1},tag=medium] ~ ~ ~ summon mes:nskeleton ~2 ~-2.1 ~2
execute @p[tag=skeleton,scores={necrotime=1},tag=big] ~ ~ ~ summon mes:nskeleton ~2 ~-2.1 ~2
execute @p[tag=skeleton,scores={necrotime=1},tag=big] ~ ~ ~ summon mes:nskeleton ~-2 ~-2.1 ~-2
execute @p[tag=skeleton,scores={necrotime=3}] ~ ~ ~ playanimation @e[type=mes:nskeleton] animation.evoker.casting f 3
execute @p[tag=skeleton,scores={necrotime=3..26}] ~ ~ ~ execute @e[type=mes:nskeleton,r=10] ~ ~ ~ tp @s ~ ~0.1 ~ 
execute @p[tag=skeleton,scores={necrotime=2..5}] ~ ~ ~ execute @e[type=mes:nskeleton] ~ ~ ~ particle mes:ground ~ ~2.0 ~
execute @p[tag=skeleton,scores={necrotime=258}] ~ ~ ~ execute @e[type=mes:nskeleton] ~ ~ ~ particle mes:poof ~ ~ ~
execute @p[tag=skeleton,scores={necrotime=259}] ~ ~ ~ execute @e[type=mes:nskeleton] ~ ~ ~ tp @s ~ ~-100 ~
execute @p[tag=skeleton,scores={necrotime=262}] ~ ~ ~ kill @e[type=mes:nskeleton] 
execute @p[tag=skeleton,scores={necrotime=262}] ~ ~ ~ event entity @s mes:cooldown_off
tag @p[tag=skeleton,scores={necrotime=263}] remove medium
tag @p[tag=skeleton,scores={necrotime=263}] remove big
tag @p[tag=skeleton,scores={necrotime=263}] add revns
tag @p[tag=skeleton,scores={necrotime=263}] remove skeleton
scoreboard players set @p[tag=revns,scores={necrotime=263}] necrotime 0
tag @p remove revns

scoreboard players add @p[r=1,tag=zombie] necrotime 1
execute @p[tag=zombie,scores={necrotime=16..262,book=1}] ~ ~ ~ event entity @s mes:cooldown_on
execute @p[tag=zombie,scores={necrotime=5}] ~ ~ ~ playsound mob.zombie.say @a[r=15]
execute @p[tag=zombie,scores={necrotime=1}] ~ ~ ~ playsound sw.music.inferno_ability @a[r=15]
execute @p[tag=zombie,scores={necrotime=1}] ~ ~ ~ summon mes:nzombie ~ ~-2.1 ~2
execute @p[tag=zombie,scores={necrotime=1}] ~ ~ ~ summon mes:nzombie ~ ~-2.1 ~-2
execute @p[tag=zombie,scores={necrotime=1}] ~ ~ ~ summon mes:nzombie ~2 ~-2.1 ~
execute @p[tag=zombie,scores={necrotime=1},tag=medium] ~ ~ ~ summon mes:nzombie ~-2 ~-2.1 ~
execute @p[tag=zombie,scores={necrotime=1},tag=big] ~ ~ ~ summon mes:nzombie ~-2 ~-2.1 ~
execute @p[tag=zombie,scores={necrotime=1},tag=big] ~ ~ ~ summon mes:nzombie ~2 ~-2.1 ~2
execute @p[tag=zombie,scores={necrotime=3}] ~ ~ ~ playanimation @e[type=mes:nzombie] animation.evoker.casting f 3
execute @p[tag=zombie,scores={necrotime=3..26}] ~ ~ ~ execute @e[type=mes:nzombie,r=10] ~ ~ ~ tp @s ~ ~0.1 ~ 
execute @p[tag=zombie,scores={necrotime=2..5}] ~ ~ ~ execute @e[type=mes:nzombie] ~ ~ ~ particle mes:ground ~ ~2.0 ~
execute @p[tag=zombie,scores={necrotime=258}] ~ ~ ~ execute @e[type=mes:nzombie] ~ ~ ~ particle mes:poof ~ ~ ~
execute @p[tag=zombie,scores={necrotime=259}] ~ ~ ~ execute @e[type=mes:nzombie] ~ ~ ~ tp @s ~ ~-1000 ~
execute @p[tag=zombie,scores={necrotime=262}] ~ ~ ~ kill @e[type=mes:nzombie] 
execute @p[tag=zombie,scores={necrotime=262}] ~ ~ ~ event entity @s mes:cooldown_off
tag @p[tag=zombie,scores={necrotime=263}] remove medium
tag @p[tag=zombie,scores={necrotime=263}] remove big
tag @p[tag=zombie,scores={necrotime=263}] add revnz
tag @p[tag=zombie,scores={necrotime=263}] remove zombie
scoreboard players set @p[tag=revnz,scores={necrotime=263}] necrotime 0
tag @p remove revnz

scoreboard players add @p[r=1,tag=minion] miniontime 1
execute @p[tag=minion,scores={miniontime=16..49,book=2}] ~ ~ ~ event entity @s mes:cooldown_on 
execute @p[tag=minion,scores={miniontime=1}] ~ ~ ~ playsound sw.music.fire_ability @a[r=20]
execute @p[tag=minion,scores={miniontime=1}] ~ ~ ~ tag @e[type=mes:nskeleton,c=1,r=10] add minionanim
execute @p[tag=minion,scores={miniontime=1}] ~ ~ ~ tag @e[type=mes:nzombie,c=1,r=15] add minionanim
execute @p[tag=minion,scores={miniontime=1}] ~ ~ ~ execute @e[type=mes:nzombie,c=1,r=15] ~ ~ ~ tag @p[tag=minion] add yes
execute @p[tag=minion,scores={miniontime=1}] ~ ~ ~ execute @e[type=mes:nskeleton,c=1,r=15] ~ ~ ~ tag @p[tag=minion] add yes
execute @p[tag=minion,scores={miniontime=1}] ~ ~ ~ titleraw @p[tag=minion,tag=!yes] actionbar { "rawtext" : [ { "translate" : "nominion.text" } ] }
execute @p[tag=minion,scores={miniontime=1}] ~ ~ ~ scoreboard players set @p[tag=minion,tag=!yes] miniontime 50
execute @p[tag=minion,scores={miniontime=1..}] ~ ~ ~ execute @e[tag=minionanim] ~ ~ ~ particle mes:necro_poof ~ ~1.8 ~
execute @p[tag=minion,scores={miniontime=1}] ~ ~ ~ playanimation @e[tag=minionanim] animation.necro.boom f 100
execute @p[tag=minion,scores={miniontime=49}] ~ ~ ~ execute @e[tag=minionanim] ~ ~ ~ effect @e[r=15,family=mob] fatal_poison 5 255 true
execute @p[tag=minion,scores={miniontime=49}] ~ ~ ~ execute @e[tag=minionanim] ~ ~ ~ summon mes:instanttnt ~ ~2.1 ~
execute @p[tag=minion,scores={miniontime=50}] ~ ~ ~ execute @e[tag=minionanim] ~ ~ ~ kill @s
execute @p[tag=minion,scores={miniontime=50}] ~ ~ ~ event entity @s mes:cooldown_off
execute @p[tag=minion,scores={miniontime=5}] ~ ~ ~ tag @a[tag=minion] remove yes
tag @p[tag=minion,scores={miniontime=50}] remove minion
scoreboard players set @p[r=1,scores={miniontime=50}] miniontime 0

scoreboard players add @p[r=1,tag=totem] totemtime 1
execute @p[tag=totem,scores={totemtime=1}] ~ ~ ~ replaceitem entity @e[r=15,family=mob] slot.weapon.offhand 0 totem_of_undying
execute @p[tag=totem,scores={totemtime=1}] ~ ~ ~ playsound random.totem @a[r=15]
execute @p[tag=totem,scores={totemtime=1}] ~ ~ ~ particle minecraft:totem_particle ~ ~ ~
execute @p[tag=totem,scores={totemtime=1}] ~ ~ ~ replaceitem entity @s slot.weapon.offhand 0 totem_of_undying
execute @p[tag=totem,scores={totemtime=1}] ~ ~ ~ replaceitem entity @e[r=15,family=necro] slot.weapon.offhand 0 totem_of_undying
execute @p[tag=totem,scores={totemtime=1..20}] ~ ~ ~ execute @e[r=15,family=mob,hasitem={location=slot.weapon.offhand,slot=0,item=totem_of_undying}] ~ ~ ~ particle minecraft:totem_particle
execute @p[tag=totem,scores={totemtime=1..20}] ~ ~ ~ execute @e[r=15,family=necro,hasitem={location=slot.weapon.offhand,slot=0,item=totem_of_undying}] ~ ~ ~ particle minecraft:totem_particle
tag @p[tag=totem,scores={totemtime=40}] remove totem
scoreboard players set @p[r=1,scores={totemtime=40}] totemtime 0


scoreboard players add @p[r=1,tag=dark] darktime 1
execute @p[tag=dark,scores={darktime=1}] ~ ~ ~ event entity @p[tag=dark] sp:n_dark_shoot
execute @p[tag=dark,scores={darktime=1}] ~ ~ ~ effect @e[r=5] darkness 2 255 true
tag @p[tag=dark,scores={darktime=40}] remove dark
scoreboard players set @p[r=1,scores={darktime=40}] darktime 0

scoreboard players add @e[type=mes:dark_shoot] darktime 1
execute @e[type=mes:dark_shoot] ~ ~ ~ particle mes:darkshoot ~ ~ ~
execute @e[type=mes:dark_shoot,scores={darktime=50}] ~ ~ ~ playsound random.explode @a[r=30]
execute @e[type=mes:dark_shoot,scores={darktime=40..50}] ~ ~ ~ particle mes:dark ~ ~ ~
execute @e[type=mes:dark_shoot,scores={darktime=50}] ~ ~ ~ tag @e[r=8,type=!player,family=mob,family=!inac,type=!mes:dark_shoot] add darkexplosion
execute @e[type=mes:dark_shoot,scores={darktime=50}] ~ ~ ~ effect @e[r=8,type=!player,family=mob,family=!inac,type=!mes:dark_shoot] levitation 1 25 true
execute @e[type=mes:dark_shoot,scores={darktime=50}] ~ ~ ~ effect @e[r=8,type=!player,family=mob,family=!inac,type=!mes:dark_shoot] fatal_poison 1 3 true
execute @e[type=mes:dark_shoot,scores={darktime=62}] ~ ~ ~ execute @e[tag=darkexplosion] ~ ~ ~ summon mes:instanttnt
execute @e[type=mes:dark_shoot,scores={darktime=62}] ~ ~ ~ execute @e[tag=darkexplosion] ~ ~ ~ particle mes:dark_explode ~ ~ ~
execute @e[type=mes:dark_shoot,scores={darktime=62}] ~ ~ ~ tag @e[tag=darkexplosion] remove darkexplosion
execute @e[type=mes:dark_shoot,scores={darktime=63}] ~ ~ ~ kill @s

scoreboard players add @p[r=1,tag=wolf] wolftime 1
execute @p[tag=wolf,scores={wolftime=16..200,book=0}] ~ ~ ~ event entity @s mes:cooldown_on
execute @p[tag=wolf,scores={wolftime=1}] ~ ~ ~ playsound sw.music.necro_ability @a[r=15]
execute @p[tag=wolf,scores={wolftime=1}] ~ ~ ~ summon wolf ~ ~ ~1
execute @p[tag=wolf,scores={wolftime=1}] ~ ~ ~ summon wolf ~ ~ ~-1
execute @p[tag=wolf,scores={wolftime=1}] ~ ~ ~ effect @e[type=wolf,r=3] strength 10 2 true
execute @p[tag=wolf,scores={wolftime=1}] ~ ~ ~ effect @e[type=wolf,r=3] resistance 10 10 true
execute @p[tag=wolf,scores={wolftime=198}] ~ ~ ~ execute @e[type=wolf] ~ ~ ~ particle mes:poof ~ ~ ~
execute @p[tag=wolf,scores={wolftime=199}] ~ ~ ~ execute @e[type=wolf] ~ ~ ~ tp @s ~ ~-1000 ~
execute @p[tag=wolf,scores={wolftime=202}] ~ ~ ~ kill @e[type=wolf] 
execute @p[tag=wolf,scores={wolftime=202}] ~ ~ ~ event entity @s mes:cooldown_off
tag @p[tag=wolf,scores={wolftime=202}] remove wolf
scoreboard players set @p[r=1,scores={wolftime=202}] wolftime 0


scoreboard players add @p[r=1,tag=spider] druidtime 1
execute @p[tag=spider,scores={druidtime=16..600,book=1}] ~ ~ ~ event entity @s mes:cooldown_on
execute @p[tag=spider,scores={druidtime=1}] ~ ~ ~ titleraw @p[tag=spider] actionbar { "rawtext" : [ { "translate" : "sneakdruid.text" } ] }
execute @p[tag=spider,scores={druidtime=1}] ~ ~ ~ effect @s invisibility 30 255 true
execute @p[tag=spider,scores={druidtime=5..595}] ~ ~ ~ execute @e[tag=spiderdruid,rm=1] ~ ~ ~ scoreboard players set @p[tag=spider] druidtime 597
execute @p[tag=spider,scores={druidtime=1}] ~ ~ ~ playsound sw.music.sky_ability @a[r=10]
execute @p[tag=spider,scores={druidtime=1}] ~ ~ ~ effect @p resistance 30 255 true
execute @p[tag=spider,scores={druidtime=1}] ~ ~ ~ camera @p set minecraft:third_person
execute @p[tag=spider,scores={druidtime=1}] ~ ~ ~ event entity @s mes:masked
execute @p[tag=spider,scores={druidtime=2}] ~ ~ ~ particle mes:poof
execute @p[tag=spider,scores={druidtime=1}] ~ ~ ~ summon polar_bear
execute @p[tag=spider,scores={druidtime=2}] ~ ~ ~ ride @p[tag=spider] start_riding @e[tag=spiderdruid]
execute @p[tag=spider,scores={druidtime=1}] ~ ~ ~ tag @e[type=polar_bear,r=1,c=1] add spiderdruid
execute @p[tag=spider,scores={druidtime=1}] ~ ~ ~ effect @e[type=polar_bear,r=1] resistance 30 255 true
execute @p[tag=spider,scores={druidtime=597}] ~ ~ ~ particle mes:poof
execute @p[tag=spider,scores={druidtime=597}] ~ ~ ~ event entity @s mes:masked_off
execute @p[tag=spider,scores={druidtime=597}] ~ ~ ~ effect @p invisibility 0
execute @p[tag=spider,scores={druidtime=597}] ~ ~ ~ effect @p resistance 0
execute @p[tag=spider,scores={druidtime=597}] ~ ~ ~ camera @p clear 
execute @p[tag=spider,scores={druidtime=597}] ~ ~ ~ ride @p[tag=spider] stop_riding
execute @p[tag=spider,scores={druidtime=598}] ~ ~ ~ tp @e[tag=spiderdruid] ~ ~-100 ~
execute @p[tag=spider,scores={druidtime=602}] ~ ~ ~ kill @e[tag=spiderdruid]
execute @p[tag=spider,scores={druidtime=602}] ~ ~ ~ event entity @s mes:cooldown_off
tag @p[tag=spider,scores={druidtime=602}] add revds
tag @p[tag=spider,scores={druidtime=602}] remove spider
scoreboard players set @p[tag=revds,scores={druidtime=602}] druidtime 0
tag @p remove revds

scoreboard players add @p[r=1,tag=bat] druidtime 1
execute @p[tag=bat,scores={druidtime=16..600,book=2}] ~ ~ ~ event entity @s mes:cooldown_on
execute @p[tag=bat,scores={druidtime=1}] ~ ~ ~ titleraw @p[tag=bat] actionbar { "rawtext" : [ { "translate" : "sneakdruid.text" } ] }
execute @p[tag=bat,scores={druidtime=1}] ~ ~ ~ effect @s invisibility 30 255 true
execute @p[tag=bat,scores={druidtime=1}] ~ ~ ~ effect @p resistance 30 255 true
execute @p[tag=bat,scores={druidtime=1}] ~ ~ ~ playsound sw.music.sky_ability @a[r=10]
execute @p[tag=bat,scores={druidtime=1}] ~ ~ ~ camera @p set minecraft:third_person
execute @p[tag=bat,scores={druidtime=1}] ~ ~ ~ event entity @s mes:masked
execute @p[tag=bat,scores={druidtime=2}] ~ ~ ~ particle mes:poof
execute @p[tag=bat,scores={druidtime=1}] ~ ~ ~ summon bat
execute @p[tag=bat,scores={druidtime=1}] ~ ~ ~ tag @e[type=bat,r=1,c=1] add batdruid
execute @p[tag=bat,scores={druidtime=1}] ~ ~ ~ effect @e[type=bat,r=1] resistance 30 255 true
execute @p[tag=bat,scores={druidtime=1..596}] ~ ~ ~ tp @e[tag=batdruid] ~ ~1.3 ~ facing ^ ^ ^10
execute @p[tag=bat,scores={druidtime=29..596},rx=-35,rxm=-90] ~ ~ ~ effect @s levitation 1 9 true
execute @p[tag=bat,scores={druidtime=29..596},rx=5,rxm=-10] ~ ~ ~ effect @s levitation 1 2 true
execute @p[tag=bat,scores={druidtime=29..596},rx=-10,rxm=-35] ~ ~ ~ effect @s levitation 1 5 true
execute @p[tag=bat,scores={druidtime=29..596},rx=90,rxm=5] ~ ~ ~ effect @s slow_falling 1 0 true
execute @p[tag=bat,scores={druidtime=597}] ~ ~ ~ particle mes:poof
execute @p[tag=bat,scores={druidtime=597}] ~ ~ ~ effect @s slow_falling 5 1 true
execute @p[tag=bat,scores={druidtime=597}] ~ ~ ~ event entity @s mes:masked_off
execute @p[tag=bat,scores={druidtime=597}] ~ ~ ~ effect @p invisibility 0
execute @p[tag=bat,scores={druidtime=597}] ~ ~ ~ effect @p resistance 0
execute @p[tag=bat,scores={druidtime=597}] ~ ~ ~ effect @p levitation 0
execute @p[tag=bat,scores={druidtime=597}] ~ ~ ~ camera @p clear
execute @p[tag=bat,scores={druidtime=598}] ~ ~ ~ tp @e[tag=batdruid] ~ ~-100 ~
execute @p[tag=bat,scores={druidtime=602}] ~ ~ ~ kill @e[tag=batdruid]
execute @p[tag=bat,scores={druidtime=602}] ~ ~ ~ event entity @s mes:cooldown_off
tag @p[tag=bat,scores={druidtime=602}] add revdb
tag @p[tag=bat,scores={druidtime=602}] remove bat
scoreboard players set @p[tag=revdb,scores={druidtime=602}] druidtime 0
tag @p remove revdb

scoreboard players add @p[r=1,tag=seed] seedtime 1
execute @p[tag=seed,scores={seedtime=16..119,book=4}] ~ ~ ~ event entity @s mes:cooldown_on
execute @p[tag=seed,scores={seedtime=10}] ~ ~ ~ playsound dig.azalea_leaves @a[r=15]
execute @p[tag=seed,scores={seedtime=1}] ~ ~ ~ summon mes:seed ^ ^1 ^2
execute @p[tag=seed,scores={seedtime=2}] ~ ~ ~ playanimation @e[type=mes:seed] animation.seed.start f 100
execute @p[tag=seed,scores={seedtime=1..}] ~ ~ ~ execute @e[type=mes:seed] ~ ~ ~ particle mes:seed ~ ~0.5 ~
execute @p[tag=seed,scores={seedtime=1..}] ~ ~ ~ execute @e[type=mes:seed] ~ ~ ~ effect @a[r=5] regeneration 2 10 true
execute @p[tag=seed,scores={seedtime=1..}] ~ ~ ~ execute @e[type=mes:seed] ~ ~ ~ effect @e[r=5,family=monster] fatal_poison 2 255 true
execute @p[tag=seed,scores={seedtime=118}] ~ ~ ~ execute @e[type=mes:seed] ~ ~ ~ particle mes:vines_death ~ ~1 ~ 
execute @p[tag=seed,scores={seedtime=118}] ~ ~ ~ execute @e[type=mes:seed] ~ ~ ~ particle mes:vines_death ~ ~2 ~
execute @p[tag=seed,scores={seedtime=118}] ~ ~ ~ playsound block.sweet_berry_bush.break @a[r=15]
execute @p[tag=seed,scores={seedtime=118}] ~ ~ ~ tp @e[type=mes:seed] ~ ~-100 ~
execute @p[tag=seed,scores={seedtime=120}] ~ ~ ~ kill @e[type=mes:seed]
execute @p[tag=seed,scores={seedtime=120}] ~ ~ ~ event entity @s mes:cooldown_off
tag @p[tag=seed,scores={seedtime=120}] remove seed
scoreboard players set @p[r=1,scores={seedtime=120}] seedtime 0

scoreboard players add @p[r=1,tag=vines] vinestime 1
execute @p[tag=vines,scores={vinestime=16..109,book=3}] ~ ~ ~ event entity @s mes:cooldown_on
execute @p[tag=vines,scores={vinestime=1}] ~ ~ ~ execute @e[r=15,family=mob,tag=!ocelotdruid,tag=!spiderdruid,tag=!batdruid,family=!inac] ~ ~ ~ tag @p[tag=vines] add yes
execute @p[tag=vines,scores={vinestime=1}] ~ ~ ~ titleraw @p[tag=vines,tag=!yes] actionbar { "rawtext" : [ { "translate" : "noone.text" } ] }
execute @p[tag=vines,scores={vinestime=1}] ~ ~ ~ scoreboard players set @p[tag=vines,tag=!yes] vinestime 109
execute @p[tag=vines,scores={vinestime=1}] ~ ~ ~ effect @e[r=15,family=mob,tag=!ocelotdruid,tag=!spiderdruid,tag=!batdruid,family=!inac] slowness 3 255 true
execute @p[tag=vines,scores={vinestime=1}] ~ ~ ~ playsound dig.azalea_leaves @a[r=15]
execute @p[tag=vines,scores={vinestime=1}] ~ ~ ~ execute @e[r=15,family=mob,tag=!ocelotdruid,tag=!spiderdruid,tag=!batdruid,family=!inac] ~ ~ ~ summon mes:vines
execute @p[tag=vines,scores={vinestime=3}] ~ ~ ~ playanimation @e[type=mes:vines] animation.vines.start f 100
execute @p[tag=vines,scores={vinestime=1..}] ~ ~ ~ execute @e[type=mes:vines] ~ ~ ~ particle mes:vines ~ ~1.2 ~
execute @p[tag=vines,scores={vinestime=15}] ~ ~ ~ execute @e[type=mes:vines] ~ ~ ~ effect @e[r=3,family=mob] slowness 5 10 true
execute @p[tag=vines,scores={vinestime=15}] ~ ~ ~ execute @e[type=mes:vines] ~ ~ ~ effect @e[r=3,family=mob] fatal_poison 5 255 true
execute @p[tag=vines,scores={vinestime=108}] ~ ~ ~ execute @e[type=mes:vines] ~ ~ ~ particle mes:vines_death ~ ~1 ~
execute @p[tag=vines,scores={vinestime=108}] ~ ~ ~ playsound block.sweet_berry_bush.break @a[r=15]
execute @p[tag=vines,scores={vinestime=108}] ~ ~ ~ tp @e[type=mes:vines] ~ ~-100 ~
execute @p[tag=vines,scores={vinestime=110}] ~ ~ ~ kill @e[type=mes:vines]
execute @p[tag=vines,scores={vinestime=5}] ~ ~ ~ tag @p remove yes
execute @p[tag=vines,scores={vinestime=110}] ~ ~ ~ event entity @s mes:cooldown_off
tag @p[tag=vines,scores={vinestime=110}] remove vines
scoreboard players set @p[r=1,scores={vinestime=110}] vinestime 0

scoreboard players add @p[r=1,tag=tballs] tballstime 1
execute @p[tag=tballs,scores={tballstime=16..129,book=0}] ~ ~ ~ event entity @s mes:cooldown_on
execute @p[tag=tballs,scores={tballstime=1}] ~ ~ ~ summon mes:tballs_shoot ^ ^3.7 ^2
execute @p[tag=tballs,scores={tballstime=1}] ~ ~ ~ summon mes:tballs_shoot ^1.2 ^3 ^2
execute @p[tag=tballs,scores={tballstime=1}] ~ ~ ~ summon mes:tballs_shoot ^-1.2 ^3 ^2
execute @p[tag=tballs,scores={tballstime=1}] ~ ~ ~ titleraw @p[tag=tballs] actionbar { "rawtext" : [ { "translate" : "tballs.punch" } ] }
execute @p[tag=tballs,scores={tballstime=1}] ~ ~ ~ playsound mob.wither.shoot @a[r=10]
execute @p[tag=tballs,scores={tballstime=20..}] ~ ~ ~ execute @e[family=mob,family=!inac] ~ ~ ~ tp @e[type=mes:tballs_shoot,r=3] @s
execute @p[tag=tballs,scores={tballstime=130}] ~ ~ ~ kill @e[type=mes:tballs_shoot]
execute @p[tag=tballs,scores={tballstime=130}] ~ ~ ~ event entity @s mes:cooldown_off
tag @p[tag=tballs,scores={tballstime=130}] remove tballs
scoreboard players set @p[r=1,scores={tballstime=130}] tballstime 0

execute @e[type=mes:tballs_shoot] ~ ~ ~ particle mes:tballs ~ ~ ~ 

scoreboard players add @p[r=1,tag=blink] blinktime 1
execute @p[tag=blink,scores={blinktime=1}] ~ ~ ~ playsound sw.music.tp_ability @a[r=20]
execute @p[tag=blink,scores={blinktime=1}] ~ ~ ~ effect @s darkness 2 255 true
execute @p[tag=blink,scores={blinktime=10}] ~ ~ ~ particle mes:necro_poof
execute @p[tag=blink,scores={blinktime=10}] ~ ~ ~ detect ^ ^0.2 ^1 air 0 tp @s ^ ^0.1 ^1 facing ^ ^ ^10
execute @p[tag=blink,scores={blinktime=10}] ~ ~ ~ detect ^ ^0.2 ^1 air 0 tp @s ^ ^0.1 ^1 facing ^ ^ ^10
execute @p[tag=blink,scores={blinktime=10}] ~ ~ ~ detect ^ ^0.2 ^1 air 0 tp @s ^ ^0.1 ^1 facing ^ ^ ^10
execute @p[tag=blink,scores={blinktime=10}] ~ ~ ~ detect ^ ^0.2 ^1 air 0 tp @s ^ ^0.1 ^1 facing ^ ^ ^10
execute @p[tag=blink,scores={blinktime=10}] ~ ~ ~ detect ^ ^0.2 ^1 air 0 tp @s ^ ^0.1 ^1 facing ^ ^ ^10
execute @p[tag=blink,scores={blinktime=10}] ~ ~ ~ detect ^ ^0.2 ^1 air 0 tp @s ^ ^0.1 ^1 facing ^ ^ ^10
execute @p[tag=blink,scores={blinktime=10}] ~ ~ ~ detect ^ ^0.2 ^1 air 0 tp @s ^ ^0.1 ^1 facing ^ ^ ^10
execute @p[tag=blink,scores={blinktime=10}] ~ ~ ~ detect ^ ^0.2 ^1 air 0 tp @s ^ ^0.1 ^1 facing ^ ^ ^10
execute @p[tag=blink,scores={blinktime=10}] ~ ~ ~ detect ^ ^0.2 ^1 air 0 tp @s ^ ^0.1 ^1 facing ^ ^ ^10
execute @p[tag=blink,scores={blinktime=10}] ~ ~ ~ detect ^ ^0.2 ^1 air 0 tp @s ^ ^0.1 ^1 facing ^ ^ ^10
execute @p[tag=blink,scores={blinktime=11}] ~ ~ ~ particle mes:necro_poof
execute @p[tag=blink,scores={blinktime=11}] ~ ~ ~ effect @s darkness 0
tag @p[tag=blink,scores={blinktime=40}] remove blink
scoreboard players set @p[r=1,scores={blinktime=40}] blinktime 0



scoreboard players add @p[r=1,tag=polymorph] polymorphtime 1
execute @p[tag=polymorph,scores={polymorphtime=16..149,book=2}] ~ ~ ~ event entity @s mes:cooldown_on
execute @p[tag=polymorph,scores={polymorphtime=1}] ~ ~ ~ playsound mob.chicken.say @a[r=15]
execute @p[tag=polymorph,scores={polymorphtime=1}] ~ ~ ~ particle mes:polymorph_launch ~ ~ ~
execute @p[tag=polymorph,scores={polymorphtime=1}] ~ ~ ~ execute @e[family=!inac,family=!npc,r=8,type=!wither,type=!ender_dragon,family=mob,type=!chicken] ~ ~ ~ particle mes:necro_poof ~ ~ ~
execute @p[tag=polymorph,scores={polymorphtime=1}] ~ ~ ~ execute @e[family=!inac,family=!npc,r=8,type=!wither,type=!ender_dragon,family=mob,type=!chicken] ~ ~ ~ tag @p[tag=polymorph] add yes
execute @p[tag=polymorph,scores={polymorphtime=1}] ~ ~ ~ titleraw @p[tag=polymorph,tag=!yes] actionbar { "rawtext" : [ { "translate" : "noone.text" } ] }
execute @p[tag=polymorph,scores={polymorphtime=1}] ~ ~ ~ scoreboard players set @p[tag=polymorph,tag=!yes] polymorphtime 4
execute @p[tag=polymorph,scores={polymorphtime=4}] ~ ~ ~ execute @e[family=!inac,family=!npc,r=8,type=!wither,type=!ender_dragon,family=mob,type=!chicken] ~ ~ ~ summon chicken
execute @p[tag=polymorph,scores={polymorphtime=4}] ~ ~ ~ execute @e[family=!inac,family=!npc,r=8,type=!wither,type=!ender_dragon,family=mob,type=!chicken] ~ ~ ~ tp @s ~ ~-1000 ~
execute @p[tag=polymorph,scores={polymorphtime=6}] ~ ~ ~ tag @a[tag=polymorph] remove yes
execute @p[tag=polymorph,scores={polymorphtime=150}] ~ ~ ~ event entity @s mes:cooldown_off
tag @p[tag=polymorph,scores={polymorphtime=150}] remove polymorph
scoreboard players set @p[r=1,scores={polymorphtime=150}] polymorphtime 0


scoreboard players add @p[r=1,tag=arcaneexpl] arcaneexptime 1
execute @p[tag=arcaneexpl,scores={arcaneexptime=16..200,book=3}] ~ ~ ~ event entity @s mes:cooldown_on
execute @p[tag=arcaneexpl,scores={arcaneexptime=1}] ~ ~ ~ playsound liquid.lava @a[r=20]
execute @p[tag=arcaneexpl,scores={arcaneexptime=1..60}] ~ ~ ~ particle mes:arcaneexpl_launch ~ ~ ~
execute @p[tag=arcaneexpl,scores={arcaneexptime=1}] ~ ~ ~ playanimation @s animation.evoker.casting f 3
execute @p[tag=arcaneexpl,scores={arcaneexptime=61}] ~ ~ ~ particle mes:arcaneexpl_explode
execute @p[tag=arcaneexpl,scores={arcaneexptime=61}] ~ ~ ~ particle mes:arcane_fire
execute @p[tag=arcaneexpl,scores={arcaneexptime=61}] ~ ~ ~ playsound cauldron.explode @a[r=15]
execute @p[tag=arcaneexpl,scores={arcaneexptime=63}] ~ ~ ~ effect @e[r=15,family=!inac,family=mob] instant_damage 1 2 true
execute @p[tag=arcaneexpl,scores={arcaneexptime=63}] ~ ~ ~ effect @e[r=15,family=!inac,family=mob] fatal_poison 3 255 true
execute @p[tag=arcaneexpl,scores={arcaneexptime=63..120}] ~ ~ ~ execute @e[family=!inac,family=mob,r=15] ~ ~ ~ particle mes:arcane_fire_ambient ~ ~1 ~
execute @p[tag=arcaneexpl,scores={arcaneexptime=200}] ~ ~ ~ event entity @s mes:cooldown_off
tag @p[tag=arcaneexpl,scores={arcaneexptime=200}] remove arcaneexpl
scoreboard players set @p[r=1,scores={arcaneexptime=200}] arcaneexptime 0


scoreboard players add @p[r=1,tag=arcaneward] wardtime 1
execute @p[tag=arcaneward,scores={wardtime=16..99,book=4}] ~ ~ ~ event entity @s mes:cooldown_on
execute @p[tag=arcaneward,scores={wardtime=1}] ~ ~ ~ playsound beacon.power @a[r=8] ~ ~ ~ 0.65
execute @p[tag=arcaneward,scores={wardtime=1}] ~ ~ ~ event entity @s sp:n_ward_shoot
execute @p[tag=arcaneward,scores={wardtime=9..98}] ~ ~ ~ execute @e[type=mes:ward] ~ ~ ~ particle mes:ward ~ ~ ~
execute @p[tag=arcaneward,scores={wardtime=9..88}] ~ ~ ~ execute @e[type=mes:ward] ~ ~ ~ effect @e[family=mob,family=!inac,r=3] slowness 1 255 true
execute @p[tag=arcaneward,scores={wardtime=2..98}] ~ ~ ~ execute @e[type=mes:ward] ~ ~ ~ particle mes:ward_explode ~ ~ ~
execute @p[tag=arcaneward,scores={wardtime=85}] ~ ~ ~ playsound beacon.activate @a[r=8] ~ ~ ~ 0.65
execute @p[tag=arcaneward,scores={wardtime=100}] ~ ~ ~ kill @e[type=mes:ward]
execute @p[tag=arcaneward,scores={wardtime=100}] ~ ~ ~ event entity @s mes:cooldown_off
tag @p[tag=arcaneward,scores={wardtime=100}] remove arcaneward
scoreboard players set @p[r=1,scores={wardtime=100}] wardtime 0


scoreboard players add @p[r=1,tag=zephyr] airtime 1
execute @p[tag=zephyr,scores={airtime=16..249,book=0}] ~ ~ ~ event entity @s mes:cooldown_on
execute @p[tag=zephyr,scores={airtime=1}] ~ ~ ~ effect @p resistance 16 255 true
execute @p[tag=zephyr,scores={airtime=1}] ~ ~ ~ playsound hit.big_dripleaf @a[r=5]
execute @p[tag=zephyr,scores={airtime=1}] ~ ~ ~ titleraw @p[tag=zephyr] actionbar { "rawtext" : [ { "translate" : "zephyr.jump" } ] }
execute @p[tag=zephyr,scores={airtime=250}] ~ ~ ~ event entity @s mes:cooldown_off
tag @p[tag=zephyr,scores={airtime=250}] add revaz
tag @p[tag=zephyr,scores={airtime=250}] remove zephyr
scoreboard players set @p[tag=revaz,scores={airtime=250}] airtime 0
tag @p remove revaz

scoreboard players add @p[tag=removejump] stonebodytime 1
effect @a[scores={stonebodytime=5..},tag=removejump] levitation 0
scoreboard players set @a[tag=removejump,scores={stonebodytime=5..}] stonebodytime 0
tag @a[tag=removejump,scores={stonebodytime=0}] remove removejump



scoreboard players add @p[r=1,tag=lightning] lightningtime 1
execute @p[tag=lightning,scores={lightningtime=16..79,book=4}] ~ ~ ~ event entity @s mes:cooldown_on
execute @p[tag=lightning,scores={lightningtime=1}] ~ ~ ~ playsound sw.music.lightning_ability @a[r=20]
execute @p[tag=lightning,scores={lightningtime=1}] ~ ~ ~ particle mes:lightning_launch ^ ^1.2 ^1
execute @p[tag=lightning,scores={lightningtime=1}] ~ ~ ~ particle mes:lightning_launch ^1.8 ^1. ^1
execute @p[tag=lightning,scores={lightningtime=1}] ~ ~ ~ particle mes:lightning_launch ^0.3 ^1.3 ^1
execute @p[tag=lightning,scores={lightningtime=1},tag=big] ~ ~ ~ particle mes:lightning_launch ^ ^1.2 ^1
execute @p[tag=lightning,scores={lightningtime=1},tag=big] ~ ~ ~ particle mes:lightning_launch ^1.8 ^1. ^1
execute @p[tag=lightning,scores={lightningtime=1},tag=big] ~ ~ ~ particle mes:lightning_launch ^0.3 ^1.3 ^1
execute @p[tag=lightning,scores={lightningtime=1}] ~ ~ ~ event entity @p[tag=lightning] sp:n_lightning_shoot
execute @p[tag=lightning,scores={lightningtime=3},tag=small] ~ ~ ~ tag @e[type=mes:lightning_shoot] add small
execute @p[tag=lightning,scores={lightningtime=3},tag=medium] ~ ~ ~ tag @e[type=mes:lightning_shoot] add medium
execute @p[tag=lightning,scores={lightningtime=3},tag=big] ~ ~ ~ tag @e[type=mes:lightning_shoot] add big
execute @p[tag=lightning,scores={lightningtime=80}] ~ ~ ~ event entity @s mes:cooldown_off
tag @p[tag=lightning,scores={lightningtime=80}] remove small
tag @p[tag=lightning,scores={lightningtime=80}] remove medium
tag @p[tag=lightning,scores={lightningtime=80}] remove big
tag @p[tag=lightning,scores={lightningtime=80}] remove lightning
scoreboard players set @p[r=1,scores={lightningtime=80}] lightningtime 0


scoreboard players add @e[type=mes:lightning_shoot] lightningtime 1
execute @e[type=mes:lightning_shoot] ~ ~ ~ particle mes:lightning_ball ~ ~ ~
execute @e[type=mes:lightning_shoot,scores={lightningtime=50},tag=small] ~ ~ ~ execute @e[r=5,type=!mes:lightning_shoot,c=1] ~ ~ ~ summon lightning_bolt
execute @e[type=mes:lightning_shoot,scores={lightningtime=50},tag=medium] ~ ~ ~ execute @e[r=5,type=!mes:lightning_shoot,c=2] ~ ~ ~ summon lightning_bolt
execute @e[type=mes:lightning_shoot,scores={lightningtime=50},tag=big] ~ ~ ~ execute @e[r=5,type=!mes:lightning_shoot,c=3] ~ ~ ~ summon lightning_bolt
execute @e[type=mes:lightning_shoot,scores={lightningtime=50}] ~ ~ ~ execute @e[r=5,type=!mes:lightning_shoot] ~ ~ ~ kill @e[type=mes:lightning_shoot,r=5]
execute @e[type=mes:lightning_shoot,scores={lightningtime=51}] ~ ~ ~ summon lightning_bolt
execute @e[type=mes:lightning_shoot,scores={lightningtime=51},tag=medium] ~ ~ ~ summon lightning_bolt ~3 ~ ~
execute @e[type=mes:lightning_shoot,scores={lightningtime=51},tag=big] ~ ~ ~ summon lightning_bolt ~3 ~ ~
execute @e[type=mes:lightning_shoot,scores={lightningtime=51},tag=big] ~ ~ ~ summon lightning_bolt ~-3 ~ ~
execute @e[type=mes:lightning_shoot,scores={lightningtime=51}] ~ ~ ~ kill @s

scoreboard players add @e[r=1,tag=defensive] defensivetime 1
execute @a[tag=defensive,scores={defensivetime=1}] ~ ~ ~ playsound sw.music.shoot_ability @a[r=10]
execute @a[tag=defensive,scores={defensivetime=1}] ~ ~ ~ particle mes:air_shockwave ~ ~ ~
execute @a[tag=defensive,scores={defensivetime=1}] ~ ~ ~ particle mes:air_visual ~ ~ ~
execute @a[tag=defensive,scores={defensivetime=1..16}] ~ ~ ~ execute @e[type=!player,family=!inac,family=!npc,type=!item,r=8,family=mob] ~ ~ ~ tp @s ^ ^0.1 ^-0.45 facing @p[tag=defensive] 
tag @a[tag=defensive,scores={defensivetime=34}] remove defensive
scoreboard players set @p[r=1,scores={defensivetime=34}] defensivetime 0



scoreboard players add @p[r=1,tag=blind] blindtime 1
execute @a[tag=blind,scores={blindtime=16..100,book=1}] ~ ~ ~ event entity @s mes:cooldown_on
execute @a[tag=blind,scores={blindtime=1}] ~ ~ ~ playsound sw.music.shoot_ability @a[r=10]
execute @a[tag=blind,scores={blindtime=1}] ~ ~ ~ execute @e[rm=1,family=!inac,family=!npc,type=!item,r=10,family=mob] ~ ~ ~ tag @p[tag=blind] add yes
execute @a[tag=blind,scores={blindtime=1}] ~ ~ ~ titleraw @p[tag=blind,tag=!yes] actionbar { "rawtext" : [ { "translate" : "noone.text" } ] }
execute @a[tag=blind,scores={blindtime=1}] ~ ~ ~ scoreboard players set @p[tag=blind,tag=!yes] blindtime 100
execute @a[tag=blind,scores={blindtime=1}] ~ ~ ~ execute @e[rm=1,family=!inac,family=!npc,type=!item,r=10,family=mob] ~ ~ ~ particle mes:dark_ring ^ ^0.1 ^0.1
execute @a[tag=blind,scores={blindtime=1}] ~ ~ ~ execute @e[rm=1,family=!inac,family=!npc,type=!item,r=10,family=mob] ~ ~ ~ particle mes:necro_poof ~ ~ ~
execute @a[tag=blind,scores={blindtime=1}] ~ ~ ~ effect @e[rm=1,family=!inac,family=!npc,type=!item,r=10,family=mob] darkness 5 255 true
execute @a[tag=blind,scores={blindtime=1}] ~ ~ ~ effect @e[rm=1,family=!inac,family=!npc,type=!item,r=10,family=mob] slowness 5 255 true
execute @a[tag=blind,scores={blindtime=100}] ~ ~ ~ execute @e[rm=1,family=!inac,family=!npc,type=!item,r=10,family=mob] ~ ~ ~ particle mes:necro_poof ~ ~ ~
execute @a[tag=blind,scores={blindtime=5}] ~ ~ ~ tag @a[tag=blind] remove yes
execute @a[tag=blind,scores={blindtime=100}] ~ ~ ~ event entity @s mes:cooldown_off
tag @a[tag=blind,scores={blindtime=101}] remove blind
scoreboard players set @p[r=1,scores={blindtime=101}] blindtime 0

scoreboard players add @p[r=1,tag=heat] necrotime 1
execute @p[tag=heat,scores={necrotime=16..80,book=2}] ~ ~ ~ event entity @s mes:cooldown_on
execute @p[tag=heat,scores={necrotime=1}] ~ ~ ~ tag @e[type=!player,family=!inac,family=!npc,type=!item,c=1,family=mob,tag=!victim] add victim
execute @p[tag=heat,scores={necrotime=1}] ~ ~ ~ summon mes:heat_shoot ^ ^ ^3
execute @p[tag=heat,scores={necrotime=2}] ~ ~ ~ tag @e[type=!player,family=!inac,family=!npc,type=!item,c=1,family=mob,tag=!victim,tag=!victimd] add victimd
execute @p[tag=heat,scores={necrotime=2}] ~ ~ ~ summon mes:heat_shoot ^1 ^ ^3
execute @p[tag=heat,scores={necrotime=3}] ~ ~ ~ tag @e[type=!player,family=!inac,family=!npc,type=!item,c=1,family=mob,tag=!victimd,tag=!victim,tag=!victimt] add victimt
execute @p[tag=heat,scores={necrotime=3}] ~ ~ ~ summon mes:heat_shoot ^-1 ^ ^3
execute @p[tag=heat,scores={necrotime=1}] ~ ~ ~ playsound sw.music.tp_ability @a[r=20]
execute @p[tag=heat,scores={necrotime=4}] ~ ~ ~ tag @e[type=mes:heat_shoot,tag=!one,tag=!two,tag=!three,c=1] add one
execute @p[tag=heat,scores={necrotime=4}] ~ ~ ~ tag @e[type=mes:heat_shoot,tag=!one,tag=!two,tag=!three,c=1] add two
execute @p[tag=heat,scores={necrotime=4}] ~ ~ ~ tag @e[type=mes:heat_shoot,tag=!one,tag=!two,tag=!three,c=1] add three
execute @p[tag=heat,scores={necrotime=80}] ~ ~ ~ kill @e[type=mes:heat_shoot]
execute @p[tag=heat,scores={necrotime=80}] ~ ~ ~ tag @e remove victim
execute @p[tag=heat,scores={necrotime=80}] ~ ~ ~ tag @e remove victimt
execute @p[tag=heat,scores={necrotime=80}] ~ ~ ~ tag @e remove victimd
execute @p[tag=heat,scores={necrotime=80}] ~ ~ ~ event entity @s mes:cooldown_off
tag @p[tag=heat,scores={necrotime=81}] add revheat
tag @p[tag=heat,scores={necrotime=81}] remove heat
scoreboard players set @p[tag=revheat,scores={necrotime=81}] necrotime 0
tag @p[r=1] remove revheat


execute @e[type=mes:heat_shoot,tag=one] ~ ~ ~ tp @s ^ ^0.05 ^0.39 facing @e[tag=victim] 
execute @e[type=mes:heat_shoot,tag=two] ~ ~ ~ tp @s ^ ^0.05 ^0.39 facing @e[tag=victimd] 
execute @e[type=mes:heat_shoot,tag=three] ~ ~ ~ tp @s ^ ^0.05 ^0.39 facing @e[tag=victimt] 
execute @e[type=mes:heat_shoot] ~ ~ ~ particle mes:shadow_ball ~ ~ ~


scoreboard players add @p[r=1,tag=ebon] necrotime 1
execute @p[tag=ebon,scores={necrotime=16..97,book=3}] ~ ~ ~ event entity @s mes:cooldown_on
execute @p[tag=ebon,scores={necrotime=1}] ~ ~ ~ effect @e[r=15,family=mob,tag=!ocelotdruid,tag=!spiderdruid,tag=!batdruid,family=!inac] slowness 6 255 true
execute @p[tag=ebon,scores={necrotime=1}] ~ ~ ~ execute @e[r=15,family=mob,tag=!ocelotdruid,tag=!spiderdruid,tag=!batdruid,family=!inac] ~ ~ ~ tag @p[tag=ebon] add yes
execute @p[tag=ebon,scores={necrotime=1}] ~ ~ ~ titleraw @p[tag=ebon,tag=!yes] actionbar { "rawtext" : [ { "translate" : "noone.text" } ] }
execute @p[tag=ebon,scores={necrotime=1}] ~ ~ ~ scoreboard players set @p[tag=ebon,tag=!yes] necrotime 100
execute @p[tag=ebon,scores={necrotime=1}] ~ ~ ~ playsound dig.azalea_leaves @a[r=10]
execute @p[tag=ebon,scores={necrotime=1}] ~ ~ ~ particle mes:ebon_launch ~ ~ ~
execute @p[tag=ebon,scores={necrotime=10}] ~ ~ ~ playsound block.chorusflower.death @a[r=10]
execute @p[tag=ebon,scores={necrotime=1}] ~ ~ ~ execute @e[r=15,family=mob,tag=!ocelotdruid,tag=!spiderdruid,tag=!batdruid,family=!inac] ~ ~ ~ summon mes:ebon
execute @p[tag=ebon,scores={necrotime=2}] ~ ~ ~ execute @e[r=15,family=mob,tag=!ocelotdruid,tag=!spiderdruid,tag=!batdruid,family=!inac] ~ ~ ~ particle mes:ebon
execute @p[tag=ebon,scores={necrotime=2}] ~ ~ ~ execute @e[r=15,family=mob,tag=!ocelotdruid,tag=!spiderdruid,tag=!batdruid,family=!inac] ~ ~ ~ particle mes:ebon_small ~ ~0.11 ~
execute @p[tag=ebon,scores={necrotime=3}] ~ ~ ~ playanimation @e[type=mes:ebon] animation.ebon.start f 100
execute @p[tag=ebon,scores={necrotime=15}] ~ ~ ~ execute @e[type=mes:ebon] ~ ~ ~ effect @e[r=3,family=mob] fatal_poison 6 255 true
execute @p[tag=ebon,scores={necrotime=96}] ~ ~ ~ execute @e[type=mes:ebon] ~ ~ ~ particle mes:ebon_explode ~ ~1 ~
execute @p[tag=ebon,scores={necrotime=96}] ~ ~ ~ playsound block.chorusflower.grow @a[r=10]
execute @p[tag=ebon,scores={necrotime=96}] ~ ~ ~ tp @e[type=mes:ebon] ~ ~-100 ~
execute @p[tag=ebon,scores={necrotime=99}] ~ ~ ~ kill @e[type=mes:ebon]
execute @p[tag=ebon,scores={necrotime=99}] ~ ~ ~ tag @a[tag=ebon] remove yes
execute @p[tag=ebon,scores={necrotime=110}] ~ ~ ~ event entity @s mes:cooldown_off
tag @p[tag=ebon,scores={necrotime=110}] add revdebon
tag @p[tag=ebon,scores={necrotime=110}] remove ebon
scoreboard players set @p[tag=revdebon,scores={necrotime=110}] necrotime 0
tag @p remove revdebon

scoreboard players add @p[r=1,tag=dash] necrotime 1
execute @p[tag=dash,scores={necrotime=16..99,book=4}] ~ ~ ~ event entity @s mes:cooldown_on
execute @p[tag=dash,scores={necrotime=1}] ~ ~ ~ playsound sw.music.necro_ability @a[r=15]
execute @p[tag=dash,scores={necrotime=1}] ~ ~ ~ summon mes:nwither_skeleton ^ ^ ^1
execute @p[tag=dash,scores={necrotime=1}] ~ ~ ~ tag @e[type=mes:nwither_skeleton,r=2.5,c=1] add dashw
execute @p[tag=dash,scores={necrotime=1}] ~ ~ ~ replaceitem entity @e[tag=dashw] slot.weapon.mainhand 0 stone_sword
execute @p[tag=dash,scores={necrotime=1}] ~ ~ ~ replaceitem entity @e[tag=dashw] slot.weapon.offhand 0 ender_pearl
execute @p[tag=dash,scores={necrotime=1}] ~ ~ ~ replaceitem entity @e[tag=dashw] slot.armor.head 0 netherite_helmet
execute @p[tag=dash,scores={necrotime=1}] ~ ~ ~ effect @e[tag=dashw] resistance 1000 255 true

execute @p[tag=dash,scores={necrotime=20}] ~ ~ ~ execute @e[tag=dashw] ~ ~ ~ playsound mob.endermen.portal @a[r=20]
execute @p[tag=dash,scores={necrotime=20}] ~ ~ ~ execute @e[tag=dashw] ~ ~ ~ particle mes:necro_poof ~ ~ ~
execute @p[tag=dash,scores={necrotime=20}] ~ ~ ~ execute @e[tag=dashw] ~ ~ ~ tp @s @e[type=!player,family=!inac,family=!npc,type=!item,c=1,family=mob,tag=!tempennemy,r=12]
execute @p[tag=dash,scores={necrotime=21}] ~ ~ ~ execute @e[tag=dashw] ~ ~ ~ effect @e[r=1,family=mob] instant_damage 1 1 true
execute @p[tag=dash,scores={necrotime=21}] ~ ~ ~ execute @e[tag=dashw] ~ ~ ~ effect @e[r=1,family=mob] wither 5 1 true
execute @p[tag=dash,scores={necrotime=21}] ~ ~ ~ execute @e[tag=dashw] ~ ~ ~ tag @e[type=!player,family=!inac,family=!npc,type=!item,c=1,family=mob,tag=!tempennemy,r=1.2] add tempennemy

execute @p[tag=dash,scores={necrotime=35}] ~ ~ ~ execute @e[tag=dashw] ~ ~ ~ playsound mob.endermen.portal @a[r=20]
execute @p[tag=dash,scores={necrotime=35}] ~ ~ ~ execute @e[tag=dashw] ~ ~ ~ particle mes:necro_poof ~ ~ ~
execute @p[tag=dash,scores={necrotime=35}] ~ ~ ~ execute @e[tag=dashw] ~ ~ ~ tp @s @e[type=!player,family=!inac,family=!npc,type=!item,c=1,family=mob,tag=!tempennemy,r=12]
execute @p[tag=dash,scores={necrotime=36}] ~ ~ ~ execute @e[tag=dashw] ~ ~ ~ effect @e[r=1,family=mob] instant_damage 1 1 true
execute @p[tag=dash,scores={necrotime=36}] ~ ~ ~ execute @e[tag=dashw] ~ ~ ~ effect @e[r=1,family=mob] wither 5 1 true
execute @p[tag=dash,scores={necrotime=36}] ~ ~ ~ execute @e[tag=dashw] ~ ~ ~ tag @e[type=!player,family=!inac,family=!npc,type=!item,c=1,family=mob,tag=!tempennemy,r=1.2] add tempennemy

execute @p[tag=dash,scores={necrotime=51}] ~ ~ ~ execute @e[tag=dashw] ~ ~ ~ playsound mob.endermen.portal @a[r=20]
execute @p[tag=dash,scores={necrotime=51}] ~ ~ ~ execute @e[tag=dashw] ~ ~ ~ particle mes:necro_poof ~ ~ ~
execute @p[tag=dash,scores={necrotime=51}] ~ ~ ~ execute @e[tag=dashw] ~ ~ ~ tp @s @e[type=!player,family=!inac,family=!npc,type=!item,c=1,family=mob,tag=!tempennemy,r=12]
execute @p[tag=dash,scores={necrotime=52}] ~ ~ ~ execute @e[tag=dashw] ~ ~ ~ effect @e[r=1,family=mob] instant_damage 1 1 true
execute @p[tag=dash,scores={necrotime=52}] ~ ~ ~ execute @e[tag=dashw] ~ ~ ~ effect @e[r=1,family=mob] wither 5 1 true
execute @p[tag=dash,scores={necrotime=52}] ~ ~ ~ execute @e[tag=dashw] ~ ~ ~ tag @e[type=!player,family=!inac,family=!npc,type=!item,c=1,family=mob,tag=!tempennemy,r=1.2] add tempennemy

execute @p[tag=dash,scores={necrotime=67}] ~ ~ ~ execute @e[tag=dashw] ~ ~ ~ playsound mob.endermen.portal @a[r=20]
execute @p[tag=dash,scores={necrotime=67}] ~ ~ ~ execute @e[tag=dashw] ~ ~ ~ particle mes:necro_poof ~ ~ ~
execute @p[tag=dash,scores={necrotime=67}] ~ ~ ~ execute @e[tag=dashw] ~ ~ ~ tp @s @e[type=!player,family=!inac,family=!npc,type=!item,c=1,family=mob,tag=!tempennemy,r=12]
execute @p[tag=dash,scores={necrotime=68}] ~ ~ ~ execute @e[tag=dashw] ~ ~ ~ effect @e[r=1,family=mob] instant_damage 1 1 true
execute @p[tag=dash,scores={necrotime=68}] ~ ~ ~ execute @e[tag=dashw] ~ ~ ~ effect @e[r=1,family=mob] wither 5 1 true
execute @p[tag=dash,scores={necrotime=68}] ~ ~ ~ execute @e[tag=dashw] ~ ~ ~ tag @e[type=!player,family=!inac,family=!npc,type=!item,c=1,family=mob,tag=!tempennemy,r=1.2] add tempennemy

execute @p[tag=dash,scores={necrotime=83}] ~ ~ ~ execute @e[tag=dashw] ~ ~ ~ playsound mob.endermen.portal @a[r=20]
execute @p[tag=dash,scores={necrotime=83}] ~ ~ ~ execute @e[tag=dashw] ~ ~ ~ particle mes:necro_poof ~ ~ ~
execute @p[tag=dash,scores={necrotime=83}] ~ ~ ~ execute @e[tag=dashw] ~ ~ ~ tp @s @e[type=!player,family=!inac,family=!npc,type=!item,c=1,family=mob,tag=!tempennemy,r=12]
execute @p[tag=dash,scores={necrotime=84}] ~ ~ ~ execute @e[tag=dashw] ~ ~ ~ effect @e[r=1,family=mob] instant_damage 1 1 true
execute @p[tag=dash,scores={necrotime=84}] ~ ~ ~ execute @e[tag=dashw] ~ ~ ~ effect @e[r=1,family=mob] wither 5 1 true
execute @p[tag=dash,scores={necrotime=84}] ~ ~ ~ execute @e[tag=dashw] ~ ~ ~ tag @e[type=!player,family=!inac,family=!npc,type=!item,c=1,family=mob,tag=!tempennemy,r=1.2] add tempennemy

execute @p[tag=dash,scores={necrotime=95}] ~ ~ ~ execute @e[tag=dashw] ~ ~ ~ tag @e[r=30] remove tempennemy
execute @p[tag=dash,scores={necrotime=95}] ~ ~ ~ execute @e[tag=dashw] ~ ~ ~ particle mes:poof ~ ~ ~
execute @p[tag=dash,scores={necrotime=95}] ~ ~ ~ execute @e[tag=dashw] ~ ~ ~ tp @s ~ ~-20 ~
execute @p[tag=dash,scores={necrotime=99}] ~ ~ ~ kill @e[tag=dashw]
execute @p[tag=dash,scores={necrotime=100}] ~ ~ ~ event entity @s mes:cooldown_off
tag @p[tag=dash,scores={necrotime=100}] add revsdash
tag @p[tag=dash,scores={necrotime=100}] remove dash
scoreboard players set @p[tag=revsdash,scores={necrotime=100}] necrotime 0
tag @p remove revsdash

