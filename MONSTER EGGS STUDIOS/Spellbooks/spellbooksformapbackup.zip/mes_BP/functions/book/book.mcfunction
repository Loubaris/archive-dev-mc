scoreboard players add @p[r=0.5] book 1

playsound item.book.page_turn @p[r=1] ~ ~ ~ 0.6

titleraw @p[r=0.5,scores={book=1,page=0}] actionbar { "rawtext" : [ { "translate" : "nounlock.text" } ] }
scoreboard players set @p[r=0.5,scores={book=1,page=0}] book 5
titleraw @p[r=0.5,scores={book=2,page=..1}] actionbar { "rawtext" : [ { "translate" : "nounlock.text" } ] }
scoreboard players set @p[r=0.5,scores={book=2,page=..1}] book 5
titleraw @p[r=0.5,scores={book=3,page=..2}] actionbar { "rawtext" : [ { "translate" : "nounlock.text" } ] }
scoreboard players set @p[r=0.5,scores={book=3,page=..2}] book 5
titleraw @p[r=0.5,scores={book=4,page=..3}] actionbar { "rawtext" : [ { "translate" : "nounlock.text" } ] }
scoreboard players set @p[r=0.5,scores={book=4,page=..3}] book 5

scoreboard players set @p[r=0.5,scores={book=5}] book 0
event entity @p[r=0.5,scores={book=4,page=4}] page_five
event entity @p[r=0.5,scores={book=3,page=3..}] page_four
event entity @p[r=0.5,scores={book=2,page=2..}] page_three
event entity @p[r=0.5,scores={book=1,page=1..}] page_two
event entity @p[r=0.5,scores={book=0}] page_one
event entity @s mes:cooldown_off