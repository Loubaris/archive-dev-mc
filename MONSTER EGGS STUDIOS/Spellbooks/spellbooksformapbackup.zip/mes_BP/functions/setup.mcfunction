gamerule showcoordinates false
gamerule commandblockoutput false
gamerule sendcommandfeedback false
gamerule mobgriefing false

scoreboard objectives add firetime dummy
scoreboard objectives add infernotime dummy
scoreboard objectives add volcanotime dummy
scoreboard objectives add bubbletime dummy
scoreboard objectives add lavatime dummy
scoreboard objectives add geysertime dummy
scoreboard objectives add maelstromtime dummy
scoreboard objectives add icelancetime dummy
scoreboard objectives add stonetime dummy
scoreboard objectives add earthquaketime dummy
scoreboard objectives add entombtime dummy
scoreboard objectives add avalanchetime dummy
scoreboard objectives add stonebodytime dummy
scoreboard objectives add necrotime dummy
scoreboard objectives add darktime dummy
scoreboard objectives add miniontime dummy
scoreboard objectives add totemtime dummy
scoreboard objectives add druidtime dummy
scoreboard objectives add vinestime dummy
scoreboard objectives add tballstime dummy
scoreboard objectives add blinktime dummy
scoreboard objectives add polymorphtime dummy
scoreboard objectives add arcaneexptime dummy
scoreboard objectives add wardtime dummy
scoreboard objectives add seedtime dummy
scoreboard objectives add wolftime dummy
scoreboard objectives add airtime dummy
scoreboard objectives add lightningtime dummy
scoreboard objectives add defensivetime dummy
scoreboard objectives add blindtime dummy
scoreboard objectives add page dummy

scoreboard objectives add tutorialtime dummy
scoreboard objectives add chargetime dummy
scoreboard objectives add book dummy
